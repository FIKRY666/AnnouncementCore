﻿using System;
using System.Net;
using System.Text.RegularExpressions;
using UnityEngine;

namespace AnnouncementCore.Utility
{
	// Token: 0x02000005 RID: 5
	public static class HtmlToTmpConverter
	{
		// Token: 0x0600003C RID: 60 RVA: 0x0000410C File Offset: 0x0000230C
		public static string Convert(string htmlContent)
		{
			bool flag = string.IsNullOrEmpty(htmlContent);
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				try
				{
					Debug.Log("原始HTML内容: " + htmlContent);
					string text = HtmlToTmpConverter.DecodeHtmlEntities(htmlContent);
					Debug.Log("解码HTML实体后: " + text);
					text = HtmlToTmpConverter.FixHtmlFormat(text);
					Debug.Log("修复HTML格式后: " + text);
					text = HtmlToTmpConverter.ProcessLineBreaks(text);
					Debug.Log("处理换行后: " + text.Replace("\n", "\\n"));
					text = HtmlToTmpConverter.ProcessParagraphs(text);
					Debug.Log("处理段落后: " + text.Replace("\n", "\\n"));
					text = HtmlToTmpConverter.ProcessHeadings(text);
					Debug.Log("处理标题后: " + text.Replace("\n", "\\n"));
					text = HtmlToTmpConverter.ProcessBlockquotes(text);
					Debug.Log("处理引用块后: " + text.Replace("\n", "\\n"));
					text = HtmlToTmpConverter.ProcessInlineStyles(text);
					Debug.Log("处理内联样式后: " + text.Replace("\n", "\\n"));
					text = HtmlToTmpConverter.ConvertSpecialLinksDirectly(text);
					Debug.Log("处理链接后: " + text.Replace("\n", "\\n"));
					text = HtmlToTmpConverter.ProcessLists(text);
					Debug.Log("处理列表后: " + text.Replace("\n", "\\n"));
					text = HtmlToTmpConverter.RemoveRemainingHtmlTags(text);
					Debug.Log("移除剩余HTML标签后: " + text.Replace("\n", "\\n"));
					text = HtmlToTmpConverter.CleanupFormatting(text);
					Debug.Log("清理格式后: " + text.Replace("\n", "\\n"));
					text = HtmlToTmpConverter.EnsureLineBreaks(text);
					Debug.Log("最终结果: " + text.Replace("\n", "\\n"));
					Debug.Log(string.Format("HTML转换完成，原长度: {0}, 转换后: {1}", htmlContent.Length, text.Length));
					result = text;
				}
				catch (Exception ex)
				{
					Debug.LogError("HTML富文本转换失败: " + ex.Message + "\nStackTrace: " + ex.StackTrace);
					result = htmlContent;
				}
			}
			return result;
		}

		// Token: 0x0600003D RID: 61 RVA: 0x00004368 File Offset: 0x00002568
		private static string EnsureLineBreaks(string text)
		{
			bool flag = string.IsNullOrEmpty(text);
			string result;
			if (flag)
			{
				result = text;
			}
			else
			{
				string text2 = text;
				bool flag2 = !text2.Contains("\n");
				if (flag2)
				{
					Debug.LogWarning("文本中未检测到换行符，尝试添加换行");
					bool flag3 = text2.Contains("。");
					if (flag3)
					{
						text2 = Regex.Replace(text2, "。\\s*", "。\n");
					}
					bool flag4 = text2.Contains("；");
					if (flag4)
					{
						text2 = Regex.Replace(text2, "；\\s*", "；\n");
					}
					bool flag5 = text2.Contains("•") || text2.Contains("·");
					if (flag5)
					{
						text2 = Regex.Replace(text2, "([•·])\\s*", "\n$1 ");
					}
				}
				text2 = Regex.Replace(text2, "\\n\\s*\\n", "\n\n");
				text2 = Regex.Replace(text2, "^\\n+", "");
				text2 = Regex.Replace(text2, "\\n+$", "");
				result = text2;
			}
			return result;
		}

		// Token: 0x0600003E RID: 62 RVA: 0x00004460 File Offset: 0x00002660
		private static string FixLineBreaks(string text)
		{
			bool flag = string.IsNullOrEmpty(text);
			string result;
			if (flag)
			{
				result = text;
			}
			else
			{
				string text2 = text.Replace("\r\n", "\n");
				text2 = text2.Replace("\r", "\n");
				text2 = Regex.Replace(text2, "\\n{3,}", "\n\n");
				bool flag2 = !text2.Contains("\n") && text2.Contains("。");
				if (flag2)
				{
					text2 = Regex.Replace(text2, "。\\s*", "。\n");
				}
				text2 = Regex.Replace(text2, "^\\s+", "", RegexOptions.Multiline);
				text2 = Regex.Replace(text2, "\\s+$", "", RegexOptions.Multiline);
				result = text2.Trim();
			}
			return result;
		}

		// Token: 0x0600003F RID: 63 RVA: 0x00004514 File Offset: 0x00002714
		private static string FixHtmlFormat(string html)
		{
			bool flag = string.IsNullOrEmpty(html);
			string result;
			if (flag)
			{
				result = html;
			}
			else
			{
				string text = Regex.Replace(html, "<a(\\w+)", "<a $1");
				text = Regex.Replace(text, "(\\w+)=\\\"", " $1=\"");
				text = text.Replace("target=\"_blank\"rel=", "target=\"_blank\" rel=");
				text = text.Replace("rel=\"noopenernoreferrernofollow\"", "rel=\"noopener noreferrer nofollow\"");
				result = text;
			}
			return result;
		}

		// Token: 0x06000040 RID: 64 RVA: 0x0000457C File Offset: 0x0000277C
		private static string ConvertSpecialLinksDirectly(string html)
		{
			bool flag = string.IsNullOrEmpty(html);
			string result;
			if (flag)
			{
				result = html;
			}
			else
			{
				Debug.Log("开始链接转换，输入: " + html);
				string pattern = "<a\\s+[^>]*?href\\s*=\\s*[\"']([^\"']*)[\"'][^>]*?>([^<]*?)\\\\([^<]+)</a>";
				try
				{
					string text = Regex.Replace(html, pattern, delegate(Match match)
					{
						string value = match.Groups[1].Value;
						string value2 = match.Groups[2].Value;
						string text2 = match.Groups[3].Value.Trim();
						Debug.Log("链接匹配: URL=" + value + ", 显示文本=" + text2);
						bool flag2 = string.IsNullOrEmpty(text2);
						if (flag2)
						{
							text2 = value2.Trim();
						}
						string text3 = string.Concat(new string[]
						{
							"<link=\"",
							value,
							"\">",
							text2,
							"</link>"
						});
						Debug.Log("转换为: " + text3);
						return text3;
					}, RegexOptions.IgnoreCase | RegexOptions.Singleline);
					Debug.Log("链接转换完成，结果: " + text);
					result = text;
				}
				catch (Exception ex)
				{
					Debug.LogError("链接转换失败: " + ex.Message);
					result = html;
				}
			}
			return result;
		}

		// Token: 0x06000041 RID: 65 RVA: 0x00004620 File Offset: 0x00002820
		public static string ConvertApiContent(string apiHtmlContent)
		{
			bool flag = string.IsNullOrEmpty(apiHtmlContent);
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				try
				{
					string text = apiHtmlContent.Replace("&lt;a ", "<a ").Replace("&lt;/a&gt;", "</a>").Replace("href=&quot;", "href=\"").Replace("&quot;&gt;", "\">");
					bool flag2 = text.Contains("href=\"<a");
					if (flag2)
					{
						text = Regex.Replace(text, "href=\"<a[^>]*href=\"([^\"]*)\"[^>]*>([^<]*)</a>\"", (Match match) => "href=\"" + match.Groups[1].Value + "\"");
					}
					result = HtmlToTmpConverter.Convert(text);
				}
				catch (Exception ex)
				{
					Debug.LogError("API内容转换失败: " + ex.Message);
					result = apiHtmlContent;
				}
			}
			return result;
		}

		// Token: 0x06000042 RID: 66 RVA: 0x000046FC File Offset: 0x000028FC
		private static string DecodeHtmlEntities(string text)
		{
			string result;
			try
			{
				string text2 = WebUtility.HtmlDecode(text);
				text2 = text2.Replace("&lt;", "<").Replace("&gt;", ">").Replace("&amp;", "&").Replace("&quot;", "\"").Replace("&#39;", "'").Replace("&nbsp;", " ");
				result = text2;
			}
			catch
			{
				result = text;
			}
			return result;
		}

		// Token: 0x06000043 RID: 67 RVA: 0x0000478C File Offset: 0x0000298C
		private static string ProcessParagraphs(string text)
		{
			bool flag = string.IsNullOrEmpty(text);
			string result;
			if (flag)
			{
				result = text;
			}
			else
			{
				Debug.Log("处理段落前: " + text);
				string text2 = Regex.Replace(text, "<p[^>]*>\\s*</p>", "\n", RegexOptions.IgnoreCase);
				text2 = Regex.Replace(text2, "<p\\b[^>]*>", "", RegexOptions.IgnoreCase);
				text2 = Regex.Replace(text2, "</p>", "\n", RegexOptions.IgnoreCase);
				text2 = text2.Replace("</p>", "\n");
				text2 = text2.Replace("</P>", "\n");
				text2 = text2.Replace("<p>", "");
				text2 = text2.Replace("<P>", "");
				Debug.Log("处理段落后: " + text2.Replace("\n", "\\n"));
				result = text2;
			}
			return result;
		}

		// Token: 0x06000044 RID: 68 RVA: 0x00004860 File Offset: 0x00002A60
		private static string ProcessHeadings(string text)
		{
			string text2 = Regex.Replace(text, "<h1[^>]*>", "<size=24><b>", RegexOptions.IgnoreCase);
			text2 = text2.Replace("</h1>", "</b></size>\n");
			text2 = Regex.Replace(text2, "<h2[^>]*>", "<size=20><b>", RegexOptions.IgnoreCase);
			text2 = text2.Replace("</h2>", "</b></size>\n");
			text2 = Regex.Replace(text2, "<h3[^>]*>", "<size=18><b>", RegexOptions.IgnoreCase);
			text2 = text2.Replace("</h3>", "</b></size>\n");
			text2 = Regex.Replace(text2, "<h4[^>]*>", "<size=16><b>", RegexOptions.IgnoreCase);
			return text2.Replace("</h4>", "</b></size>\n");
		}

		// Token: 0x06000045 RID: 69 RVA: 0x00004904 File Offset: 0x00002B04
		private static string ProcessLists(string text)
		{
			string text2 = text.Replace("<ul>", "");
			text2 = text2.Replace("</ul>", "");
			text2 = text2.Replace("<ol>", "");
			text2 = text2.Replace("</ol>", "");
			return Regex.Replace(text2, "<li[^>]*>(?!.*?<link)(.*?)</li>", "• $1\n", RegexOptions.IgnoreCase);
		}

		// Token: 0x06000046 RID: 70 RVA: 0x00004970 File Offset: 0x00002B70
		private static string ProcessBlockquotes(string text)
		{
			string text2 = text.Replace("<blockquote>", "<color=#888888><i>");
			return text2.Replace("</blockquote>", "</i></color>\n");
		}

		// Token: 0x06000047 RID: 71 RVA: 0x000049A8 File Offset: 0x00002BA8
		private static string ProcessInlineStyles(string text)
		{
			string text2 = text.Replace("<strong>", "<b>");
			text2 = text2.Replace("</strong>", "</b>");
			text2 = text2.Replace("<b>", "<b>");
			text2 = text2.Replace("</b>", "</b>");
			text2 = text2.Replace("<em>", "<i>");
			text2 = text2.Replace("</em>", "</i>");
			text2 = text2.Replace("<i>", "<i>");
			text2 = text2.Replace("</i>", "</i>");
			text2 = text2.Replace("<u>", "<u>");
			text2 = text2.Replace("</u>", "</u>");
			text2 = text2.Replace("<s>", "<s>");
			text2 = text2.Replace("</s>", "</s>");
			text2 = text2.Replace("<strike>", "<s>");
			return text2.Replace("</strike>", "</s>");
		}

		// Token: 0x06000048 RID: 72 RVA: 0x00004AAC File Offset: 0x00002CAC
		private static string ProcessLineBreaks(string text)
		{
			bool flag = string.IsNullOrEmpty(text);
			string result;
			if (flag)
			{
				result = text;
			}
			else
			{
				Debug.Log("处理换行前: " + text.Replace("\n", "\\n"));
				string text2 = Regex.Replace(text, "<br\\s*/?>", "\n", RegexOptions.IgnoreCase);
				text2 = text2.Replace("\r\n", "\n");
				text2 = text2.Replace("\r", "\n");
				Debug.Log("处理换行后: " + text2.Replace("\n", "\\n"));
				result = text2;
			}
			return result;
		}

		// Token: 0x06000049 RID: 73 RVA: 0x00004B44 File Offset: 0x00002D44
		private static string RemoveRemainingHtmlTags(string text)
		{
			string pattern = "<(?!/?(b|i|u|s|size|color|sup|sub|link=|link\\b))[^>]+>";
			string text2 = Regex.Replace(text, pattern, string.Empty);
			text2 = Regex.Replace(text2, "\\s+", " ");
			return text2.Trim();
		}

		// Token: 0x0600004A RID: 74 RVA: 0x00004B80 File Offset: 0x00002D80
		private static string CleanupFormatting(string text)
		{
			string text2 = HtmlToTmpConverter.FixUnclosedTags(text);
			text2 = Regex.Replace(text2, "\\n{3,}", "\n\n");
			text2 = Regex.Replace(text2, "^\\s+|\\s+$", "", RegexOptions.Multiline);
			text2 = text2.Trim();
			return HtmlToTmpConverter.FixLinkTags(text2);
		}

		// Token: 0x0600004B RID: 75 RVA: 0x00004BD0 File Offset: 0x00002DD0
		private static string FixLinkTags(string text)
		{
			string result;
			try
			{
				int count = Regex.Matches(text, "<link=[^>]+>").Count;
				int count2 = Regex.Matches(text, "</link>").Count;
				bool flag = count > count2;
				if (flag)
				{
					for (int i = 0; i < count - count2; i++)
					{
						text += "</link>";
					}
				}
				result = text;
			}
			catch (Exception ex)
			{
				Debug.LogError("修复链接标签失败: " + ex.Message);
				result = text;
			}
			return result;
		}

		// Token: 0x0600004C RID: 76 RVA: 0x00004C64 File Offset: 0x00002E64
		private static string FixUnclosedTags(string text)
		{
			string result;
			try
			{
				string[] array = new string[]
				{
					"b",
					"i",
					"u",
					"s",
					"size",
					"color",
					"link"
				};
				foreach (string text2 in array)
				{
					int count = Regex.Matches(text, "<" + text2 + "[^>]*>").Count;
					int count2 = Regex.Matches(text, "</" + text2 + ">").Count;
					bool flag = count > count2;
					if (flag)
					{
						for (int j = 0; j < count - count2; j++)
						{
							text = text + "</" + text2 + ">";
						}
					}
				}
				result = text;
			}
			catch (Exception ex)
			{
				Debug.LogError("修复未闭合标签失败: " + ex.Message);
				result = text;
			}
			return result;
		}

		// Token: 0x0600004D RID: 77 RVA: 0x00004D7C File Offset: 0x00002F7C
		public static string ConvertApiExample(string htmlContent)
		{
			bool flag = string.IsNullOrEmpty(htmlContent);
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				try
				{
					string text = HtmlToTmpConverter.Convert(htmlContent);
					text = Regex.Replace(text, "^\\s*$\\n", "", RegexOptions.Multiline);
					text = Regex.Replace(text, "\\n{3,}", "\n\n");
					result = text.Trim();
				}
				catch (Exception ex)
				{
					Debug.LogError("API示例HTML转换失败: " + ex.Message);
					result = htmlContent;
				}
			}
			return result;
		}

		// Token: 0x0600004E RID: 78 RVA: 0x00004E00 File Offset: 0x00003000
		public static string ConvertForJsonExample(string htmlContent)
		{
			bool flag = string.IsNullOrEmpty(htmlContent);
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				try
				{
					Debug.Log("JSON示例原始内容: " + htmlContent);
					string text = HtmlToTmpConverter.DecodeHtmlEntities(htmlContent);
					text = Regex.Replace(text, "<p\\b[^>]*>", "", RegexOptions.IgnoreCase);
					text = Regex.Replace(text, "</p>", "\n\n", RegexOptions.IgnoreCase);
					text = HtmlToTmpConverter.ProcessHeadings(text);
					text = HtmlToTmpConverter.ProcessLists(text);
					text = HtmlToTmpConverter.ProcessBlockquotes(text);
					text = HtmlToTmpConverter.ProcessInlineStyles(text);
					text = HtmlToTmpConverter.ProcessLineBreaks(text);
					text = HtmlToTmpConverter.ConvertSpecialLinksDirectly(text);
					text = HtmlToTmpConverter.RemoveRemainingHtmlTags(text);
					text = HtmlToTmpConverter.CleanupFormatting(text);
					text = HtmlToTmpConverter.FixLineBreaks(text);
					Debug.Log("JSON示例转换完成: " + text);
					result = text;
				}
				catch (Exception ex)
				{
					Debug.LogError("JSON示例转换失败: " + ex.Message);
					result = htmlContent;
				}
			}
			return result;
		}
	}
}
