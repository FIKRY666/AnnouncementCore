﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;

namespace AnnouncementCore.Utility
{
	// Token: 0x02000006 RID: 6
	public static class ResourceLoader
	{
		// Token: 0x0600004F RID: 79 RVA: 0x00004EE4 File Offset: 0x000030E4
		public static Sprite LoadSprite(string resourceName)
		{
			Sprite result;
			try
			{
				Sprite sprite;
				bool flag = ResourceLoader._spriteCache.TryGetValue(resourceName, out sprite);
				if (flag)
				{
					result = sprite;
				}
				else
				{
					Assembly executingAssembly = Assembly.GetExecutingAssembly();
					string[] manifestResourceNames = executingAssembly.GetManifestResourceNames();
					int i = 0;
					while (i < manifestResourceNames.Length)
					{
						string text = manifestResourceNames[i];
						bool flag2 = text.Contains(resourceName);
						if (flag2)
						{
							using (Stream manifestResourceStream = executingAssembly.GetManifestResourceStream(text))
							{
								bool flag3 = manifestResourceStream == null;
								if (!flag3)
								{
									byte[] array = new byte[manifestResourceStream.Length];
									manifestResourceStream.Read(array, 0, array.Length);
									Texture2D texture2D = new Texture2D(2, 2);
									bool flag4 = !ImageConversion.LoadImage(texture2D, array);
									if (!flag4)
									{
										Sprite sprite2 = Sprite.Create(texture2D, new Rect(0f, 0f, (float)texture2D.width, (float)texture2D.height), new Vector2(0.5f, 0.5f), 100f);
										ResourceLoader._spriteCache[resourceName] = sprite2;
										return sprite2;
									}
								}
							}
						}
						IL_FE:
						i++;
						continue;
						goto IL_FE;
					}
					Debug.LogWarning("找不到资源: " + resourceName);
					result = null;
				}
			}
			catch (Exception ex)
			{
				Debug.LogError("加载资源失败: " + resourceName + ", 错误: " + ex.Message);
				result = null;
			}
			return result;
		}

		// Token: 0x06000050 RID: 80 RVA: 0x00005070 File Offset: 0x00003270
		public static void PreloadSprites()
		{
			string[] array = new string[]
			{
				"panel_background",
				"sidebar_bg",
				"content_bg",
				"info_bg",
				"close_button",
				"refresh_button",
				"prev_button",
				"next_button",
				"feedback_button",
				"left_arrow",
				"right_arrow",
				"update_popup_steam_bg2",
				"list_item_normal",
				"list_item_selected",
				"list_item_unread",
				"update_popup_background",
				"update_popup_announcement_bg",
				"update_popup_steam_bg",
				"update_popup_btn_bg",
				"notification_badge",
				"notification_button",
				"update_panel_bg",
				"panel_collapse",
				"panel_expand",
				"panel_empty"
			};
			foreach (string resourceName in array)
			{
				ResourceLoader.LoadSprite(resourceName);
			}
		}

		// Token: 0x06000051 RID: 81 RVA: 0x0000517C File Offset: 0x0000337C
		public static void ClearCache()
		{
			ResourceLoader._spriteCache.Clear();
		}

		// Token: 0x0400000E RID: 14
		private static readonly Dictionary<string, Sprite> _spriteCache = new Dictionary<string, Sprite>();
	}
}
