﻿using System;
using Duckov;
using UnityEngine;

namespace AnnouncementCore.Utility
{
	// Token: 0x02000004 RID: 4
	public static class AudioUtility
	{
		// Token: 0x0600003A RID: 58 RVA: 0x00003FAC File Offset: 0x000021AC
		public static void PlayHoverSound()
		{
			try
			{
				string[] array = new string[]
				{
					"UI/hover",
					"UI/Button/Hover",
					"SFX/UI/Hover",
					"UI/Menu/Hover"
				};
				foreach (string text in array)
				{
					try
					{
						bool flag = AudioManager.Post(text) != null;
						if (flag)
						{
							break;
						}
					}
					catch
					{
					}
				}
			}
			catch (Exception ex)
			{
				Debug.LogWarning("播放悬停音效失败: " + ex.Message);
			}
		}

		// Token: 0x0600003B RID: 59 RVA: 0x00004058 File Offset: 0x00002258
		public static void PlayClickSound()
		{
			try
			{
				string[] array = new string[]
				{
					"UI/click",
					"UI/Button/Click",
					"SFX/UI/Click",
					"UI/Menu/Click",
					"UI/Button/Press"
				};
				foreach (string text in array)
				{
					try
					{
						bool flag = AudioManager.Post(text) != null;
						if (flag)
						{
							break;
						}
					}
					catch
					{
					}
				}
			}
			catch (Exception ex)
			{
				Debug.LogWarning("播放点击音效失败: " + ex.Message);
			}
		}
	}
}
