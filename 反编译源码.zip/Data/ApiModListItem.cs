﻿using System;

namespace AnnouncementCore.Data
{
	// Token: 0x02000013 RID: 19
	[Serializable]
	public class ApiModListItem
	{
		// Token: 0x040000A7 RID: 167
		public string id;

		// Token: 0x040000A8 RID: 168
		public string name;
	}
}
