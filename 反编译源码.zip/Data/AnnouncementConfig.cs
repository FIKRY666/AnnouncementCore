﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using UnityEngine;

namespace AnnouncementCore.Data
{
	// Token: 0x02000015 RID: 21
	[Serializable]
	public class AnnouncementConfig
	{
		// Token: 0x17000010 RID: 16
		// (get) Token: 0x06000155 RID: 341 RVA: 0x0000DB15 File Offset: 0x0000BD15
		public bool HasNewVersionAvailable
		{
			get
			{
				return this.HasPermanentUpdate;
			}
		}

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x06000156 RID: 342 RVA: 0x0000DB1D File Offset: 0x0000BD1D
		public string LatestVersion
		{
			get
			{
				return this.GetLatestVersion();
			}
		}

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x06000157 RID: 343 RVA: 0x0000DB25 File Offset: 0x0000BD25
		public string SteamWorkshopUrl
		{
			get
			{
				return (!string.IsNullOrEmpty(this.SteamWorkshopId)) ? ("https://steamcommunity.com/sharedfiles/filedetails/?id=" + this.SteamWorkshopId) : null;
			}
		}

		// Token: 0x06000158 RID: 344 RVA: 0x0000DB48 File Offset: 0x0000BD48
		public static AnnouncementConfig LoadFromFolder(string modFolderPath)
		{
			AnnouncementConfig result;
			try
			{
				AnnouncementConfig announcementConfig = AnnouncementConfig.LoadFromInfoIni(modFolderPath) ?? AnnouncementConfig.LoadFromAnnouncementConfigJson(modFolderPath);
				bool flag = announcementConfig == null;
				if (flag)
				{
					result = null;
				}
				else
				{
					announcementConfig.ModDirectory = modFolderPath;
					announcementConfig.LoadLocalChangelog();
					result = announcementConfig;
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("加载配置失败 {0}: {1}", modFolderPath, arg));
				result = null;
			}
			return result;
		}

		// Token: 0x06000159 RID: 345 RVA: 0x0000DBB0 File Offset: 0x0000BDB0
		private void LoadLocalChangelog()
		{
			try
			{
				string path = Path.Combine(this.ModDirectory, "changelog.md");
				bool flag = File.Exists(path);
				if (flag)
				{
					this.ChangelogContent = File.ReadAllText(path);
				}
			}
			catch (Exception arg)
			{
				Debug.LogWarning(string.Format("加载本地changelog失败: {0}", arg));
			}
		}

		// Token: 0x0600015A RID: 346 RVA: 0x0000DC14 File Offset: 0x0000BE14
		private static AnnouncementConfig LoadFromInfoIni(string modFolderPath)
		{
			AnnouncementConfig result;
			try
			{
				string path = Path.Combine(modFolderPath, "info.ini");
				bool flag = !File.Exists(path);
				if (flag)
				{
					result = null;
				}
				else
				{
					AnnouncementConfig announcementConfig = new AnnouncementConfig();
					string[] array = File.ReadAllLines(path);
					foreach (string text in array)
					{
						bool flag2 = string.IsNullOrWhiteSpace(text) || text.Trim().StartsWith(";") || text.Trim().StartsWith("#");
						if (!flag2)
						{
							int num = text.IndexOf('=');
							bool flag3 = num <= 0;
							if (!flag3)
							{
								string key = text.Substring(0, num).Trim().ToLower();
								string text2 = text.Substring(num + 1).Trim();
								bool flag4 = text2.StartsWith("\"") && text2.EndsWith("\"");
								if (flag4)
								{
									text2 = text2.Substring(1, text2.Length - 2);
								}
								AnnouncementConfig.ParseIniKeyValue(announcementConfig, key, text2);
							}
						}
					}
					bool flag5 = string.IsNullOrEmpty(announcementConfig.ModId);
					if (flag5)
					{
						result = null;
					}
					else
					{
						bool flag6 = string.IsNullOrEmpty(announcementConfig.DisplayName);
						if (flag6)
						{
							announcementConfig.DisplayName = announcementConfig.ModId;
						}
						Debug.Log("从 info.ini 加载配置成功: " + announcementConfig.ModId);
						result = announcementConfig;
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("读取 info.ini 失败: {0}", arg));
				result = null;
			}
			return result;
		}

		// Token: 0x0600015B RID: 347 RVA: 0x0000DDC0 File Offset: 0x0000BFC0
		private static void ParseIniKeyValue(AnnouncementConfig config, string key, string value)
		{
			uint num = <PrivateImplementationDetails>.ComputeStringHash(key);
			if (num <= 1181855383U)
			{
				if (num != 325168066U)
				{
					if (num != 879704937U)
					{
						if (num == 1181855383U)
						{
							if (key == "version")
							{
								config.Version = value;
							}
						}
					}
					else if (key == "description")
					{
						bool flag = string.IsNullOrEmpty(config.Author);
						if (flag)
						{
							config.Author = value;
						}
					}
				}
				else if (key == "publishedfileid")
				{
					config.SteamWorkshopId = value;
				}
			}
			else if (num <= 1339365942U)
			{
				if (num != 1333443158U)
				{
					if (num == 1339365942U)
					{
						if (key == "displayname")
						{
							config.DisplayName = value;
						}
					}
				}
				else if (key == "author")
				{
					config.Author = value;
				}
			}
			else if (num != 2369371622U)
			{
				if (num == 3921242667U)
				{
					if (key == "feedbackurl")
					{
						config.FeedbackUrl = value;
					}
				}
			}
			else if (key == "name")
			{
				config.ModId = value;
			}
		}

		// Token: 0x0600015C RID: 348 RVA: 0x0000DF00 File Offset: 0x0000C100
		private static AnnouncementConfig LoadFromAnnouncementConfigJson(string modFolderPath)
		{
			AnnouncementConfig result;
			try
			{
				string path = Path.Combine(modFolderPath, "announcement_config.json");
				bool flag = !File.Exists(path);
				if (flag)
				{
					result = null;
				}
				else
				{
					string text = File.ReadAllText(path);
					result = JsonUtility.FromJson<AnnouncementConfig>(text);
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("读取 JSON 配置失败: {0}", arg));
				result = null;
			}
			return result;
		}

		// Token: 0x0600015D RID: 349 RVA: 0x0000DF68 File Offset: 0x0000C168
		[DebuggerStepThrough]
		public Task FetchAnnouncementsFromApiAsync()
		{
			AnnouncementConfig.<FetchAnnouncementsFromApiAsync>d__25 <FetchAnnouncementsFromApiAsync>d__ = new AnnouncementConfig.<FetchAnnouncementsFromApiAsync>d__25();
			<FetchAnnouncementsFromApiAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<FetchAnnouncementsFromApiAsync>d__.<>4__this = this;
			<FetchAnnouncementsFromApiAsync>d__.<>1__state = -1;
			<FetchAnnouncementsFromApiAsync>d__.<>t__builder.Start<AnnouncementConfig.<FetchAnnouncementsFromApiAsync>d__25>(ref <FetchAnnouncementsFromApiAsync>d__);
			return <FetchAnnouncementsFromApiAsync>d__.<>t__builder.Task;
		}

		// Token: 0x0600015E RID: 350 RVA: 0x0000DFAC File Offset: 0x0000C1AC
		private bool CheckNewVersionAvailable()
		{
			bool flag = this.ApiAnnouncements == null || this.ApiAnnouncements.Count == 0;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				ApiAnnouncementData apiAnnouncementData = this.ApiAnnouncements[0];
				bool flag2 = string.IsNullOrEmpty(apiAnnouncementData.version);
				result = (!flag2 && this.IsNewerVersion(apiAnnouncementData.version, this.Version));
			}
			return result;
		}

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x0600015F RID: 351 RVA: 0x0000E014 File Offset: 0x0000C214
		public bool HasPermanentUpdate
		{
			get
			{
				bool result;
				try
				{
					bool flag = this.ApiAnnouncements == null || this.ApiAnnouncements.Count == 0;
					if (flag)
					{
						result = false;
					}
					else
					{
						ApiAnnouncementData apiAnnouncementData = this.ApiAnnouncements[0];
						bool flag2 = string.IsNullOrEmpty(apiAnnouncementData.version);
						if (flag2)
						{
							result = false;
						}
						else
						{
							result = this.IsNewerVersion(apiAnnouncementData.version, this.Version);
						}
					}
				}
				catch (Exception arg)
				{
					Debug.LogError(string.Format("计算HasPermanentUpdate失败: {0}", arg));
					result = false;
				}
				return result;
			}
		}

		// Token: 0x06000160 RID: 352 RVA: 0x0000E0A4 File Offset: 0x0000C2A4
		public string GetLatestCloudVersion()
		{
			bool flag = this.ApiAnnouncements == null || this.ApiAnnouncements.Count == 0;
			string result;
			if (flag)
			{
				result = this.Version;
			}
			else
			{
				ApiAnnouncementData apiAnnouncementData = this.ApiAnnouncements[0];
				result = ((!string.IsNullOrEmpty(apiAnnouncementData.version)) ? apiAnnouncementData.version : this.Version);
			}
			return result;
		}

		// Token: 0x06000161 RID: 353 RVA: 0x0000E104 File Offset: 0x0000C304
		private string GetLatestVersion()
		{
			bool flag = this.ApiAnnouncements == null || this.ApiAnnouncements.Count == 0;
			string result;
			if (flag)
			{
				result = this.Version;
			}
			else
			{
				ApiAnnouncementData apiAnnouncementData = this.ApiAnnouncements[0];
				result = ((!string.IsNullOrEmpty(apiAnnouncementData.version)) ? apiAnnouncementData.version : this.Version);
			}
			return result;
		}

		// Token: 0x06000162 RID: 354 RVA: 0x0000E164 File Offset: 0x0000C364
		private bool IsNewerVersion(string version1, string version2)
		{
			bool result;
			try
			{
				string text = version1.Trim().TrimStart(new char[]
				{
					'v',
					'V',
					' '
				});
				string text2 = version2.Trim().TrimStart(new char[]
				{
					'v',
					'V',
					' '
				});
				bool flag = string.IsNullOrEmpty(text) || string.IsNullOrEmpty(text2);
				if (flag)
				{
					result = false;
				}
				else
				{
					string[] array = text.Split('.', StringSplitOptions.None);
					string[] array2 = text2.Split('.', StringSplitOptions.None);
					int num = Math.Max(array.Length, array2.Length);
					for (int i = 0; i < num; i++)
					{
						int num3;
						int num2 = (i < array.Length && int.TryParse(array[i], out num3)) ? num3 : 0;
						int num5;
						int num4 = (i < array2.Length && int.TryParse(array2[i], out num5)) ? num5 : 0;
						bool flag2 = num2 > num4;
						if (flag2)
						{
							return true;
						}
						bool flag3 = num2 < num4;
						if (flag3)
						{
							return false;
						}
					}
					result = false;
				}
			}
			catch
			{
				result = (string.Compare(version1, version2, StringComparison.OrdinalIgnoreCase) > 0);
			}
			return result;
		}

		// Token: 0x06000163 RID: 355 RVA: 0x0000E288 File Offset: 0x0000C488
		public string GetDisplayContent()
		{
			bool flag = this.ApiAnnouncements != null && this.ApiAnnouncements.Count > 0;
			if (flag)
			{
				ApiAnnouncementData apiAnnouncementData = this.ApiAnnouncements[0];
				bool flag2 = !string.IsNullOrWhiteSpace(apiAnnouncementData.content_text);
				if (flag2)
				{
					return apiAnnouncementData.content_text;
				}
				bool flag3 = !string.IsNullOrWhiteSpace(apiAnnouncementData.content_html);
				if (flag3)
				{
					return apiAnnouncementData.content_html;
				}
			}
			bool flag4 = !string.IsNullOrWhiteSpace(this.ChangelogContent);
			string result;
			if (flag4)
			{
				result = this.ChangelogContent;
			}
			else
			{
				result = "暂无更新内容";
			}
			return result;
		}

		// Token: 0x06000164 RID: 356 RVA: 0x0000E320 File Offset: 0x0000C520
		private bool TryParseAnnouncementJson(string json, out List<ApiAnnouncementData> announcementList)
		{
			announcementList = new List<ApiAnnouncementData>();
			bool result;
			try
			{
				string text = json.Replace("\n", "").Replace("\r", "").Replace("\t", "").Replace(" ", "");
				bool flag = !text.Contains("\"success\":true");
				if (flag)
				{
					result = false;
				}
				else
				{
					int num = text.IndexOf("\"data\":[");
					bool flag2 = num < 0;
					if (flag2)
					{
						result = false;
					}
					else
					{
						num += 8;
						int num2 = text.IndexOf("]", num);
						bool flag3 = num2 < 0;
						if (flag3)
						{
							result = false;
						}
						else
						{
							string text2 = text.Substring(num, num2 - num);
							bool flag4 = string.IsNullOrWhiteSpace(text2) || text2 == "}";
							if (flag4)
							{
								result = true;
							}
							else
							{
								string[] array = text2.Split(new string[]
								{
									"},{"
								}, StringSplitOptions.RemoveEmptyEntries);
								foreach (string text3 in array)
								{
									string text4 = text3.Trim(new char[]
									{
										'{',
										'}',
										' ',
										'\r',
										'\n',
										'\t'
									});
									bool flag5 = string.IsNullOrWhiteSpace(text4);
									if (!flag5)
									{
										ApiAnnouncementData apiAnnouncementData = this.ParseAnnouncementItem(text4);
										bool flag6 = apiAnnouncementData != null;
										if (flag6)
										{
											announcementList.Add(apiAnnouncementData);
										}
									}
								}
								result = true;
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				Debug.LogError("解析公告JSON失败: " + ex.Message);
				result = false;
			}
			return result;
		}

		// Token: 0x06000165 RID: 357 RVA: 0x0000E4C4 File Offset: 0x0000C6C4
		private ApiAnnouncementData ParseAnnouncementItem(string jsonObject)
		{
			ApiAnnouncementData result;
			try
			{
				string text = this.ExtractJsonValue(jsonObject, "id");
				string text2 = this.ExtractJsonValue(jsonObject, "modId");
				bool flag = string.IsNullOrEmpty(text) || string.IsNullOrEmpty(text2);
				if (flag)
				{
					Debug.LogWarning("解析公告项失败: id或modId为空");
					result = null;
				}
				else
				{
					string title = this.ExtractJsonValue(jsonObject, "title");
					string text3 = this.ExtractJsonValue(jsonObject, "content_html");
					string content_text = this.ExtractJsonValue(jsonObject, "content_text");
					string author = this.ExtractJsonValue(jsonObject, "author");
					string version = this.ExtractJsonValue(jsonObject, "version");
					bool flag2 = !string.IsNullOrEmpty(text3) && text3.Length < 10;
					if (flag2)
					{
					}
					long num;
					result = new ApiAnnouncementData
					{
						id = text,
						modId = text2,
						title = title,
						content_html = text3,
						content_text = content_text,
						author = author,
						timestamp = (long.TryParse(this.ExtractJsonValue(jsonObject, "timestamp"), out num) ? num : 0L),
						version = version
					};
				}
			}
			catch (Exception ex)
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000166 RID: 358 RVA: 0x0000E600 File Offset: 0x0000C800
		private string ExtractJsonValue(string jsonObject, string key)
		{
			string result;
			try
			{
				string text = "\"" + key + "\":\"";
				int num = jsonObject.IndexOf(text);
				bool flag = num >= 0;
				if (flag)
				{
					num += text.Length;
					int i = num;
					bool flag2 = false;
					while (i < jsonObject.Length)
					{
						char c = jsonObject[i];
						bool flag3 = flag2;
						if (flag3)
						{
							flag2 = false;
						}
						else
						{
							bool flag4 = c == '\\';
							if (flag4)
							{
								flag2 = true;
							}
							else
							{
								bool flag5 = c == '"';
								if (flag5)
								{
									break;
								}
							}
						}
						i++;
					}
					bool flag6 = i < jsonObject.Length;
					if (flag6)
					{
						string jsonString = jsonObject.Substring(num, i - num);
						return this.DecodeJsonString(jsonString);
					}
				}
				text = "\"" + key + "\":";
				num = jsonObject.IndexOf(text);
				bool flag7 = num < 0;
				if (flag7)
				{
					result = null;
				}
				else
				{
					num += text.Length;
					int num2 = jsonObject.Length;
					int num3 = jsonObject.IndexOf(",", num);
					int num4 = jsonObject.IndexOf("}", num);
					int num5 = jsonObject.IndexOf("]", num);
					bool flag8 = num3 >= 0;
					if (flag8)
					{
						num2 = Math.Min(num2, num3);
					}
					bool flag9 = num4 >= 0;
					if (flag9)
					{
						num2 = Math.Min(num2, num4);
					}
					bool flag10 = num5 >= 0;
					if (flag10)
					{
						num2 = Math.Min(num2, num5);
					}
					bool flag11 = num2 == jsonObject.Length;
					if (flag11)
					{
						result = null;
					}
					else
					{
						string text2 = jsonObject.Substring(num, num2 - num).Trim();
						bool flag12 = text2.StartsWith("\"") && text2.EndsWith("\"");
						if (flag12)
						{
							text2 = text2.Substring(1, text2.Length - 2);
							text2 = this.DecodeJsonString(text2);
						}
						result = text2;
					}
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000167 RID: 359 RVA: 0x0000E808 File Offset: 0x0000CA08
		private string DecodeJsonString(string jsonString)
		{
			bool flag = string.IsNullOrEmpty(jsonString);
			string result;
			if (flag)
			{
				result = jsonString;
			}
			else
			{
				try
				{
					string text = jsonString.Replace("\\\"", "\"").Replace("\\\\", "\\").Replace("\\/", "/").Replace("\\b", "\b").Replace("\\f", "\f").Replace("\\n", "\n").Replace("\\r", "\r").Replace("\\t", "\t");
					text = Regex.Replace(text, "\\\\u([0-9a-fA-F]{4})", delegate(Match match)
					{
						string result2;
						try
						{
							string value = match.Groups[1].Value;
							int utf = Convert.ToInt32(value, 16);
							result2 = char.ConvertFromUtf32(utf);
						}
						catch
						{
							result2 = match.Value;
						}
						return result2;
					});
					result = text;
				}
				catch
				{
					result = jsonString;
				}
			}
			return result;
		}

		// Token: 0x06000168 RID: 360 RVA: 0x0000E8EC File Offset: 0x0000CAEC
		public override string ToString()
		{
			return string.Concat(new string[]
			{
				this.DisplayName,
				" (",
				this.ModId,
				") v",
				this.Version
			});
		}

		// Token: 0x040000B1 RID: 177
		public string ModId;

		// Token: 0x040000B2 RID: 178
		public string DisplayName;

		// Token: 0x040000B3 RID: 179
		public string Version = "1.0.0";

		// Token: 0x040000B4 RID: 180
		public string Author;

		// Token: 0x040000B5 RID: 181
		public string SteamWorkshopId;

		// Token: 0x040000B6 RID: 182
		public bool AutoShowUpdates = true;

		// Token: 0x040000B7 RID: 183
		[NonSerialized]
		public string ModDirectory;

		// Token: 0x040000B8 RID: 184
		[NonSerialized]
		public string ChangelogContent;

		// Token: 0x040000B9 RID: 185
		[NonSerialized]
		public List<ApiAnnouncementData> ApiAnnouncements = new List<ApiAnnouncementData>();

		// Token: 0x040000BA RID: 186
		[NonSerialized]
		public DateTime LastApiFetchTime = DateTime.MinValue;

		// Token: 0x040000BB RID: 187
		[NonSerialized]
		public bool IsFetchingApi = false;

		// Token: 0x040000BC RID: 188
		public string FeedbackUrl;

		// Token: 0x040000BD RID: 189
		private const int CACHE_DURATION_MINUTES = 10;

		// Token: 0x040000BE RID: 190
		private const string API_BASE_URL = "https://duckov.guducat.cc/api";
	}
}
