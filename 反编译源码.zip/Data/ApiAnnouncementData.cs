﻿using System;

namespace AnnouncementCore.Data
{
	// Token: 0x02000014 RID: 20
	[Serializable]
	public class ApiAnnouncementData
	{
		// Token: 0x040000A9 RID: 169
		public string id;

		// Token: 0x040000AA RID: 170
		public string modId;

		// Token: 0x040000AB RID: 171
		public string title;

		// Token: 0x040000AC RID: 172
		public string content_html;

		// Token: 0x040000AD RID: 173
		public string content_text;

		// Token: 0x040000AE RID: 174
		public string author;

		// Token: 0x040000AF RID: 175
		public long timestamp;

		// Token: 0x040000B0 RID: 176
		public string version;
	}
}
