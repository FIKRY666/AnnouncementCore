﻿using System;
using AnnouncementCore.Core;
using Duckov.Modding;
using UnityEngine;

namespace AnnouncementCore
{
	// Token: 0x02000003 RID: 3
	public class ModBehaviour : ModBehaviour
	{
		// Token: 0x06000037 RID: 55 RVA: 0x00003F10 File Offset: 0x00002110
		private void OnEnable()
		{
			try
			{
				Debug.Log("AnnouncementCore Mod已启用");
				AnnouncementManager.WakeUp();
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("AnnouncementCore Mod启用异常: {0}", arg));
			}
		}

		// Token: 0x06000038 RID: 56 RVA: 0x00003F5C File Offset: 0x0000215C
		private void OnDisable()
		{
			try
			{
				Debug.Log("AnnouncementCore Mod被禁用");
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("AnnouncementCore Mod禁用异常: {0}", arg));
			}
		}
	}
}
