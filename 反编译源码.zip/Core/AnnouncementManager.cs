﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using AnnouncementCore.Data;
using AnnouncementCore.UI;
using Duckov.Modding;
using UnityEngine;
using UnityEngine.UI;

namespace AnnouncementCore.Core
{
	// Token: 0x02000016 RID: 22
	[Serializable]
	public class AnnouncementManager : MonoBehaviour
	{
		// Token: 0x0600016A RID: 362 RVA: 0x0000E95C File Offset: 0x0000CB5C
		public static void WakeUp()
		{
			try
			{
				Debug.Log("AnnouncementCore: WakeUp被调用");
				bool flag = AnnouncementManager._isInitialized && AnnouncementManager._instance != null;
				if (flag)
				{
					Debug.Log("AnnouncementCore: 已经初始化，跳过");
				}
				else
				{
					bool flag2 = AnnouncementManager._instance == null;
					if (flag2)
					{
						GameObject gameObject = GameObject.Find("AnnouncementCore_Manager");
						bool flag3 = gameObject != null;
						if (flag3)
						{
							AnnouncementManager._instance = gameObject.GetComponent<AnnouncementManager>();
							Debug.Log("AnnouncementCore: 使用现有管理器");
						}
						else
						{
							AnnouncementManager.CreateManager();
							Debug.Log("AnnouncementCore: 创建新管理器");
						}
					}
					Debug.Log("AnnouncementCore: WakeUp完成，等待Start()初始化");
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("AnnouncementCore唤醒失败: {0}", arg));
			}
		}

		// Token: 0x0600016B RID: 363 RVA: 0x0000EA28 File Offset: 0x0000CC28
		private static void CreateManager()
		{
			try
			{
				GameObject gameObject = new GameObject("AnnouncementCore_Manager");
				Object.DontDestroyOnLoad(gameObject);
				AnnouncementManager._instance = gameObject.AddComponent<AnnouncementManager>();
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("创建管理器失败: {0}", arg));
			}
		}

		// Token: 0x0600016C RID: 364 RVA: 0x0000EA80 File Offset: 0x0000CC80
		private void Awake()
		{
			bool flag = AnnouncementManager._instance != null && AnnouncementManager._instance != this;
			if (flag)
			{
				Debug.LogWarning("AnnouncementCore: 检测到重复管理器，销毁新实例");
				Object.Destroy(base.gameObject);
			}
			else
			{
				AnnouncementManager._instance = this;
				Object.DontDestroyOnLoad(base.gameObject);
			}
		}

		// Token: 0x0600016D RID: 365 RVA: 0x0000EADC File Offset: 0x0000CCDC
		[DebuggerStepThrough]
		private void Start()
		{
			AnnouncementManager.<Start>d__18 <Start>d__ = new AnnouncementManager.<Start>d__18();
			<Start>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Start>d__.<>4__this = this;
			<Start>d__.<>1__state = -1;
			<Start>d__.<>t__builder.Start<AnnouncementManager.<Start>d__18>(ref <Start>d__);
		}

		// Token: 0x0600016E RID: 366 RVA: 0x0000EB18 File Offset: 0x0000CD18
		[DebuggerStepThrough]
		public Task InitializeAsync(bool force = false)
		{
			AnnouncementManager.<InitializeAsync>d__19 <InitializeAsync>d__ = new AnnouncementManager.<InitializeAsync>d__19();
			<InitializeAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<InitializeAsync>d__.<>4__this = this;
			<InitializeAsync>d__.force = force;
			<InitializeAsync>d__.<>1__state = -1;
			<InitializeAsync>d__.<>t__builder.Start<AnnouncementManager.<InitializeAsync>d__19>(ref <InitializeAsync>d__);
			return <InitializeAsync>d__.<>t__builder.Task;
		}

		// Token: 0x0600016F RID: 367 RVA: 0x0000EB64 File Offset: 0x0000CD64
		private void SubscribeToEvents()
		{
			ModManager.OnModActivated += this.OnModActivated;
			MainMenu.OnMainMenuAwake = (Action)Delegate.Combine(MainMenu.OnMainMenuAwake, new Action(this.OnMainMenuAwake));
			MainMenu.OnMainMenuDestroy = (Action)Delegate.Combine(MainMenu.OnMainMenuDestroy, new Action(this.OnMainMenuDestroy));
		}

		// Token: 0x06000170 RID: 368 RVA: 0x0000EBC4 File Offset: 0x0000CDC4
		private void UnsubscribeFromEvents()
		{
			ModManager.OnModActivated -= this.OnModActivated;
			MainMenu.OnMainMenuAwake = (Action)Delegate.Remove(MainMenu.OnMainMenuAwake, new Action(this.OnMainMenuAwake));
			MainMenu.OnMainMenuDestroy = (Action)Delegate.Remove(MainMenu.OnMainMenuDestroy, new Action(this.OnMainMenuDestroy));
		}

		// Token: 0x06000171 RID: 369 RVA: 0x0000EC24 File Offset: 0x0000CE24
		public void Initialize(bool force = false)
		{
			this.InitializeAsync(force);
		}

		// Token: 0x06000172 RID: 370 RVA: 0x0000EC30 File Offset: 0x0000CE30
		[DebuggerStepThrough]
		private Task InitializeWithModListAsync()
		{
			AnnouncementManager.<InitializeWithModListAsync>d__23 <InitializeWithModListAsync>d__ = new AnnouncementManager.<InitializeWithModListAsync>d__23();
			<InitializeWithModListAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<InitializeWithModListAsync>d__.<>4__this = this;
			<InitializeWithModListAsync>d__.<>1__state = -1;
			<InitializeWithModListAsync>d__.<>t__builder.Start<AnnouncementManager.<InitializeWithModListAsync>d__23>(ref <InitializeWithModListAsync>d__);
			return <InitializeWithModListAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000173 RID: 371 RVA: 0x0000EC74 File Offset: 0x0000CE74
		private void ScanActiveModsForAnnouncements()
		{
			try
			{
				this._configs.Clear();
				Debug.Log(string.Format("AnnouncementCore: 开始扫描Mods，API列表中有 {0} 个Mod", this._apiModList.Count));
				bool flag = this._apiModList.Count == 0;
				if (flag)
				{
					Debug.LogWarning("AnnouncementCore: API Mod 列表为空，将不显示任何公告");
				}
				else
				{
					List<string> list = new List<string>();
					string text = Path.Combine(Directory.GetCurrentDirectory(), "Duckov_Data", "Mods");
					bool flag2 = Directory.Exists(text);
					if (flag2)
					{
						string[] directories = Directory.GetDirectories(text);
						list.AddRange(directories);
						Debug.Log(string.Format("找到游戏本体 Mod 文件夹: {0}，包含 {1} 个子文件夹", text, directories.Length));
					}
					string text2 = "D:\\steam\\steamapps\\workshop\\content\\3167020";
					bool flag3 = Directory.Exists(text2);
					if (flag3)
					{
						string[] directories2 = Directory.GetDirectories(text2);
						list.AddRange(directories2);
						Debug.Log(string.Format("找到 Steam 创意工坊文件夹: {0}，包含 {1} 个子文件夹", text2, directories2.Length));
					}
					int num = 0;
					int num2 = 0;
					foreach (string text3 in list)
					{
						num++;
						try
						{
							AnnouncementConfig config = AnnouncementConfig.LoadFromFolder(text3);
							bool flag4 = config == null || string.IsNullOrEmpty(config.ModId);
							if (!flag4)
							{
								bool flag5 = this._apiModList.Any((ApiModListItem mod) => mod != null && !string.IsNullOrEmpty(mod.id) && mod.id == config.ModId);
								bool flag6 = flag5;
								if (flag6)
								{
									ApiModListItem apiModListItem = this._apiModList.FirstOrDefault((ApiModListItem mod) => mod != null && mod.id == config.ModId);
									bool flag7 = apiModListItem != null && !string.IsNullOrEmpty(apiModListItem.name);
									if (flag7)
									{
										config.DisplayName = apiModListItem.name;
									}
									bool flag8 = string.IsNullOrEmpty(config.DisplayName);
									if (flag8)
									{
										config.DisplayName = config.ModId;
									}
									bool flag9 = string.IsNullOrEmpty(config.Version);
									if (flag9)
									{
										config.Version = "1.0.0";
									}
									this._configs[config.ModId] = config;
									num2++;
									Debug.Log(string.Concat(new string[]
									{
										"找到启用的 Mod: ",
										config.ModId,
										" (",
										config.DisplayName,
										") v",
										config.Version
									}));
								}
							}
						}
						catch (Exception ex)
						{
							Debug.LogError("扫描 Mod 目录 " + text3 + " 失败: " + ex.Message);
						}
					}
					this.CleanInvalidConfigs();
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("扫描 Mods 失败: {0}", arg));
				this._configs.Clear();
			}
		}

		// Token: 0x06000174 RID: 372 RVA: 0x0000EFD0 File Offset: 0x0000D1D0
		private void CleanInvalidConfigs()
		{
			try
			{
				List<string> list = new List<string>();
				foreach (KeyValuePair<string, AnnouncementConfig> keyValuePair in this._configs)
				{
					bool flag = string.IsNullOrEmpty(keyValuePair.Key) || keyValuePair.Value == null;
					if (flag)
					{
						list.Add(keyValuePair.Key);
					}
				}
				foreach (string text in list)
				{
					this._configs.Remove(text);
					Debug.LogWarning("移除无效配置: " + text);
				}
				bool flag2 = list.Count > 0;
				if (flag2)
				{
					Debug.Log(string.Format("清理了 {0} 个无效配置", list.Count));
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("清理无效配置失败: {0}", arg));
			}
		}

		// Token: 0x06000175 RID: 373 RVA: 0x0000F108 File Offset: 0x0000D308
		[DebuggerStepThrough]
		private Task<bool> FetchModListFromApiAsync()
		{
			AnnouncementManager.<FetchModListFromApiAsync>d__26 <FetchModListFromApiAsync>d__ = new AnnouncementManager.<FetchModListFromApiAsync>d__26();
			<FetchModListFromApiAsync>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<FetchModListFromApiAsync>d__.<>4__this = this;
			<FetchModListFromApiAsync>d__.<>1__state = -1;
			<FetchModListFromApiAsync>d__.<>t__builder.Start<AnnouncementManager.<FetchModListFromApiAsync>d__26>(ref <FetchModListFromApiAsync>d__);
			return <FetchModListFromApiAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000176 RID: 374 RVA: 0x0000F14C File Offset: 0x0000D34C
		private bool TryParseModListJson(string json, out List<ApiModListItem> modList)
		{
			modList = new List<ApiModListItem>();
			bool result;
			try
			{
				string text = json.Replace("\n", "").Replace("\r", "").Replace("\t", "").Replace(" ", "");
				bool flag = !text.Contains("\"success\":true");
				if (flag)
				{
					Debug.LogWarning("API 响应中 success 不为 true");
					result = false;
				}
				else
				{
					int num = text.IndexOf("\"data\":[");
					bool flag2 = num < 0;
					if (flag2)
					{
						Debug.LogWarning("未找到 data 数组");
						result = false;
					}
					else
					{
						num += 8;
						int num2 = text.IndexOf("]", num);
						bool flag3 = num2 < 0;
						if (flag3)
						{
							Debug.LogWarning("未找到 data 数组结束");
							result = false;
						}
						else
						{
							string text2 = text.Substring(num, num2 - num);
							bool flag4 = string.IsNullOrWhiteSpace(text2) || text2 == "}";
							if (flag4)
							{
								Debug.Log("data 数组为空");
								result = true;
							}
							else
							{
								string[] array = text2.Split(new string[]
								{
									"},{"
								}, StringSplitOptions.RemoveEmptyEntries);
								foreach (string text3 in array)
								{
									string text4 = text3.Trim(new char[]
									{
										'{',
										'}',
										' ',
										'\r',
										'\n',
										'\t'
									});
									bool flag5 = string.IsNullOrWhiteSpace(text4);
									if (!flag5)
									{
										string text5 = this.ExtractJsonValue(text4, "id");
										string text6 = this.ExtractJsonValue(text4, "name");
										bool flag6 = !string.IsNullOrEmpty(text5);
										if (flag6)
										{
											modList.Add(new ApiModListItem
											{
												id = text5,
												name = (string.IsNullOrEmpty(text6) ? text5 : text6)
											});
										}
										else
										{
											Debug.LogWarning("无法从 JSON 项解析 id: " + text4);
										}
									}
								}
								Debug.Log(string.Format("解析成功，找到 {0} 个 Mod", modList.Count));
								result = true;
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000177 RID: 375 RVA: 0x0000F37C File Offset: 0x0000D57C
		private string ExtractJsonValue(string jsonObject, string key)
		{
			string result;
			try
			{
				string text = "\"" + key + "\":\"";
				int num = jsonObject.IndexOf(text);
				bool flag = num < 0;
				if (flag)
				{
					text = "\"" + key + "\":";
					num = jsonObject.IndexOf(text);
					bool flag2 = num < 0;
					if (flag2)
					{
						result = null;
					}
					else
					{
						num += text.Length;
						int num2 = jsonObject.IndexOf(",", num);
						bool flag3 = num2 < 0;
						if (flag3)
						{
							num2 = jsonObject.IndexOf("}", num);
						}
						bool flag4 = num2 < 0;
						if (flag4)
						{
							result = null;
						}
						else
						{
							string text2 = jsonObject.Substring(num, num2 - num).Trim();
							text2 = text2.Trim('"');
							result = text2;
						}
					}
				}
				else
				{
					num += text.Length;
					int num3 = jsonObject.IndexOf("\"", num);
					bool flag5 = num3 < 0;
					if (flag5)
					{
						result = null;
					}
					else
					{
						result = jsonObject.Substring(num, num3 - num);
					}
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000178 RID: 376 RVA: 0x0000F48C File Offset: 0x0000D68C
		private void TryParseJsonManually(string json)
		{
			try
			{
				Debug.Log("尝试手动解析 JSON...");
				bool flag = json.Contains("\"success\":true") && json.Contains("\"data\":");
				if (flag)
				{
					int num = json.IndexOf("\"data\":") + 7;
					int num2 = json.LastIndexOf("]") + 1;
					bool flag2 = num > 7 && num2 > num;
					if (flag2)
					{
						string text = json.Substring(num, num2 - num);
						bool flag3 = text.Contains("DuckovCustomSounds") && text.Contains("ItemLevelAndSearchSoundMod");
						if (flag3)
						{
						}
					}
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x06000179 RID: 377 RVA: 0x0000F540 File Offset: 0x0000D740
		[DebuggerStepThrough]
		private Task FetchAllModAnnouncementsAsync()
		{
			AnnouncementManager.<FetchAllModAnnouncementsAsync>d__30 <FetchAllModAnnouncementsAsync>d__ = new AnnouncementManager.<FetchAllModAnnouncementsAsync>d__30();
			<FetchAllModAnnouncementsAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<FetchAllModAnnouncementsAsync>d__.<>4__this = this;
			<FetchAllModAnnouncementsAsync>d__.<>1__state = -1;
			<FetchAllModAnnouncementsAsync>d__.<>t__builder.Start<AnnouncementManager.<FetchAllModAnnouncementsAsync>d__30>(ref <FetchAllModAnnouncementsAsync>d__);
			return <FetchAllModAnnouncementsAsync>d__.<>t__builder.Task;
		}

		// Token: 0x0600017A RID: 378 RVA: 0x0000F584 File Offset: 0x0000D784
		private void CheckForVersionUpdates()
		{
			try
			{
				bool flag = this._uiManager == null;
				if (flag)
				{
					Debug.Log("AnnouncementManager: UI管理器未初始化，跳过版本更新检查");
				}
				else
				{
					bool flag2 = false;
					int num = 0;
					foreach (AnnouncementConfig announcementConfig in this._configs.Values)
					{
						bool hasNewVersionAvailable = announcementConfig.HasNewVersionAvailable;
						if (hasNewVersionAvailable)
						{
							flag2 = true;
							num++;
							Debug.Log(string.Concat(new string[]
							{
								"检测到版本更新: ",
								announcementConfig.ModId,
								" (当前: ",
								announcementConfig.Version,
								", 最新: ",
								announcementConfig.LatestVersion,
								")"
							}));
						}
					}
					bool flag3 = flag2;
					if (flag3)
					{
						Debug.Log(string.Format("AnnouncementManager: 检测到 {0} 个版本更新，通知UI显示弹窗", num));
						this._uiManager.CheckAndShowUpdatePopup();
					}
					else
					{
						Debug.Log("AnnouncementManager: 没有检测到版本更新");
						UIManager uiManager = this._uiManager;
						if (uiManager != null)
						{
							uiManager.CheckAndShowUpdatePopup();
						}
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("检查版本更新失败: {0}", arg));
			}
		}

		// Token: 0x0600017B RID: 379 RVA: 0x0000F6F0 File Offset: 0x0000D8F0
		private void Update()
		{
			bool flag = !AnnouncementManager._isInitialized;
			if (!flag)
			{
				this._refreshTimer += Time.deltaTime;
				bool flag2 = this._refreshTimer >= 600f;
				if (flag2)
				{
					this._refreshTimer = 0f;
					this.RefreshAllAnnouncementsAsync();
				}
				this._updateCheckTimer += Time.deltaTime;
				bool flag3 = this._updateCheckTimer >= 600f;
				if (flag3)
				{
					this._updateCheckTimer = 0f;
					bool flag4 = this._uiManager != null && !this._hasAutoShownUpdates;
					if (flag4)
					{
						this.CheckForVersionUpdates();
					}
				}
			}
		}

		// Token: 0x0600017C RID: 380 RVA: 0x0000F7A4 File Offset: 0x0000D9A4
		[DebuggerStepThrough]
		private Task RefreshAllAnnouncementsAsync()
		{
			AnnouncementManager.<RefreshAllAnnouncementsAsync>d__34 <RefreshAllAnnouncementsAsync>d__ = new AnnouncementManager.<RefreshAllAnnouncementsAsync>d__34();
			<RefreshAllAnnouncementsAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<RefreshAllAnnouncementsAsync>d__.<>4__this = this;
			<RefreshAllAnnouncementsAsync>d__.<>1__state = -1;
			<RefreshAllAnnouncementsAsync>d__.<>t__builder.Start<AnnouncementManager.<RefreshAllAnnouncementsAsync>d__34>(ref <RefreshAllAnnouncementsAsync>d__);
			return <RefreshAllAnnouncementsAsync>d__.<>t__builder.Task;
		}

		// Token: 0x0600017D RID: 381 RVA: 0x0000F7E8 File Offset: 0x0000D9E8
		[DebuggerStepThrough]
		public Task<bool> RegisterModAnnouncementAsync(string modFolderPath)
		{
			AnnouncementManager.<RegisterModAnnouncementAsync>d__35 <RegisterModAnnouncementAsync>d__ = new AnnouncementManager.<RegisterModAnnouncementAsync>d__35();
			<RegisterModAnnouncementAsync>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<RegisterModAnnouncementAsync>d__.<>4__this = this;
			<RegisterModAnnouncementAsync>d__.modFolderPath = modFolderPath;
			<RegisterModAnnouncementAsync>d__.<>1__state = -1;
			<RegisterModAnnouncementAsync>d__.<>t__builder.Start<AnnouncementManager.<RegisterModAnnouncementAsync>d__35>(ref <RegisterModAnnouncementAsync>d__);
			return <RegisterModAnnouncementAsync>d__.<>t__builder.Task;
		}

		// Token: 0x0600017E RID: 382 RVA: 0x0000F834 File Offset: 0x0000DA34
		public bool RegisterModAnnouncement(string modFolderPath)
		{
			this.RegisterModAnnouncementAsync(modFolderPath);
			return true;
		}

		// Token: 0x0600017F RID: 383 RVA: 0x0000F850 File Offset: 0x0000DA50
		[DebuggerStepThrough]
		private void OnModActivated(ModInfo modInfo, ModBehaviour modBehaviour)
		{
			AnnouncementManager.<OnModActivated>d__37 <OnModActivated>d__ = new AnnouncementManager.<OnModActivated>d__37();
			<OnModActivated>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<OnModActivated>d__.<>4__this = this;
			<OnModActivated>d__.modInfo = modInfo;
			<OnModActivated>d__.modBehaviour = modBehaviour;
			<OnModActivated>d__.<>1__state = -1;
			<OnModActivated>d__.<>t__builder.Start<AnnouncementManager.<OnModActivated>d__37>(ref <OnModActivated>d__);
		}

		// Token: 0x06000180 RID: 384 RVA: 0x0000F898 File Offset: 0x0000DA98
		private void OnMainMenuAwake()
		{
			try
			{
				Debug.Log(string.Format("AnnouncementManager: 主菜单唤醒，初始化状态: {0}, Mod 数量: {1}", AnnouncementManager._isInitialized, this._configs.Count));
				bool flag = AnnouncementManager._isInitialized && this._configs.Count > 0;
				if (flag)
				{
					Debug.Log("AnnouncementManager: 主菜单唤醒，创建UI");
					this.SetupUIManager();
				}
				else
				{
					bool flag2 = AnnouncementManager._isInitialized && this._configs.Count == 0;
					if (flag2)
					{
						Debug.Log("AnnouncementManager: 没有公告配置，不创建UI");
					}
					else
					{
						Debug.Log("AnnouncementManager: 等待初始化完成...");
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("处理主菜单唤醒事件失败: {0}", arg));
			}
		}

		// Token: 0x06000181 RID: 385 RVA: 0x0000F964 File Offset: 0x0000DB64
		private void CheckAndSetupUI()
		{
			bool flag = AnnouncementManager._isInitialized && this._configs.Count > 0;
			if (flag)
			{
				GameObject gameObject = GameObject.Find("MainMenu(Clone)") ?? GameObject.Find("MainMenu");
				bool flag2 = gameObject != null && gameObject.activeInHierarchy;
				if (flag2)
				{
					Debug.Log("主菜单处于活动状态，现在创建 UI");
					Debug.Log(string.Format("配置数量: {0}, 状态: {1}", this._configs.Count, this._state != null));
					this.SetupUIManager();
				}
				else
				{
					Debug.Log("主菜单未处于活动状态，等待主菜单唤醒事件");
				}
			}
		}

		// Token: 0x06000182 RID: 386 RVA: 0x0000FA14 File Offset: 0x0000DC14
		private void SetupUIManager()
		{
			bool flag = this._state == null;
			if (!flag)
			{
				bool flag2 = this._uiManager != null;
				if (flag2)
				{
					this._uiManager.Cleanup();
					Object.Destroy(this._uiManager);
					this._uiManager = null;
				}
				this._uiManager = base.gameObject.AddComponent<UIManager>();
				Transform transform = this.FindUIRoot();
				bool flag3 = transform == null;
				if (flag3)
				{
					transform = this.CreateUIRoot();
				}
				this._uiManager.Initialize(this._state, transform);
			}
		}

		// Token: 0x06000183 RID: 387 RVA: 0x0000FAA4 File Offset: 0x0000DCA4
		private Transform FindUIRoot()
		{
			Transform result;
			try
			{
				Canvas[] array = Object.FindObjectsOfType<Canvas>();
				foreach (Canvas canvas in array)
				{
				}
				GameObject gameObject = GameObject.Find("AnnouncementCanvas");
				bool flag = gameObject != null;
				if (flag)
				{
					Canvas component = gameObject.GetComponent<Canvas>();
					bool flag2 = !component.gameObject.activeSelf;
					if (flag2)
					{
						component.gameObject.SetActive(true);
					}
					result = gameObject.transform;
				}
				else
				{
					result = this.CreateAnnouncementCanvas();
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("查找UI根对象异常: {0}", arg));
				result = this.CreateAnnouncementCanvas();
			}
			return result;
		}

		// Token: 0x06000184 RID: 388 RVA: 0x0000FB5C File Offset: 0x0000DD5C
		private Transform CreateAnnouncementCanvas()
		{
			Transform result;
			try
			{
				GameObject gameObject = new GameObject("AnnouncementCanvas");
				Canvas canvas = gameObject.AddComponent<Canvas>();
				canvas.renderMode = 0;
				canvas.sortingOrder = 10001;
				CanvasScaler canvasScaler = gameObject.AddComponent<CanvasScaler>();
				canvasScaler.uiScaleMode = 1;
				canvasScaler.referenceResolution = new Vector2(1920f, 1080f);
				canvasScaler.screenMatchMode = 0;
				canvasScaler.matchWidthOrHeight = 0.5f;
				gameObject.AddComponent<GraphicRaycaster>();
				Object.DontDestroyOnLoad(gameObject);
				Debug.Log(string.Format("创建AnnouncementCanvas: {0}, SortingOrder: {1}, ScaleMode: ScaleWithScreenSize", gameObject.name, canvas.sortingOrder));
				result = gameObject.transform;
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("创建Canvas异常: {0}", arg));
				result = null;
			}
			return result;
		}

		// Token: 0x06000185 RID: 389 RVA: 0x0000FC2C File Offset: 0x0000DE2C
		private Transform CreateUIRoot()
		{
			Transform result;
			try
			{
				GameObject gameObject = new GameObject("AnnouncementCanvas_Debug");
				Canvas canvas = gameObject.AddComponent<Canvas>();
				canvas.renderMode = 0;
				canvas.sortingOrder = 1000;
				CanvasScaler canvasScaler = gameObject.AddComponent<CanvasScaler>();
				canvasScaler.uiScaleMode = 1;
				canvasScaler.referenceResolution = new Vector2(1920f, 1080f);
				canvasScaler.screenMatchMode = 0;
				canvasScaler.matchWidthOrHeight = 0.5f;
				gameObject.AddComponent<GraphicRaycaster>();
				Image image = gameObject.AddComponent<Image>();
				image.color = new Color(0f, 0f, 0f, 0.3f);
				Debug.Log(string.Format("创建调试Canvas: {0}, 尺寸: {1}", gameObject.name, canvasScaler.referenceResolution));
				result = gameObject.transform;
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("创建Canvas异常: {0}", arg));
				result = null;
			}
			return result;
		}

		// Token: 0x06000186 RID: 390 RVA: 0x0000FD20 File Offset: 0x0000DF20
		private void OnMainMenuDestroy()
		{
			try
			{
				bool flag = this._uiManager != null;
				if (flag)
				{
					this._uiManager.HideMainPanelOnly();
				}
				Debug.Log("AnnouncementManager: 主菜单销毁，保持UI管理器运行");
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("处理主菜单销毁事件失败: {0}", arg));
			}
		}

		// Token: 0x06000187 RID: 391 RVA: 0x0000FD84 File Offset: 0x0000DF84
		public static void ManualWakeUp()
		{
			AnnouncementManager.WakeUp();
		}

		// Token: 0x06000188 RID: 392 RVA: 0x0000FD90 File Offset: 0x0000DF90
		public static bool IsAwake()
		{
			return AnnouncementManager._isInitialized && AnnouncementManager._instance != null;
		}

		// Token: 0x06000189 RID: 393 RVA: 0x0000FDB8 File Offset: 0x0000DFB8
		public static void Reinitialize()
		{
			bool flag = AnnouncementManager._instance != null;
			if (flag)
			{
				AnnouncementManager._instance.Initialize(true);
			}
			else
			{
				AnnouncementManager.WakeUp();
			}
		}

		// Token: 0x0600018A RID: 394 RVA: 0x0000FDF0 File Offset: 0x0000DFF0
		public static void CleanupMod(string modId)
		{
			bool flag = !AnnouncementManager._isInitialized || AnnouncementManager._instance == null;
			if (!flag)
			{
				bool flag2 = string.IsNullOrEmpty(modId);
				if (flag2)
				{
					Debug.LogError("ModId不能为空");
				}
				else
				{
					try
					{
						AnnouncementState state = AnnouncementManager._instance._state;
						if (state != null)
						{
							state.CleanMod(modId);
						}
						AnnouncementManager._instance._configs.Remove(modId);
						string key = "Announcement_PopupShown_" + modId;
						string key2 = "Announcement_HiddenPopup_" + modId;
						PlayerPrefs.DeleteKey(key);
						PlayerPrefs.DeleteKey(key2);
						PlayerPrefs.Save();
						bool flag3 = AnnouncementManager._instance._uiManager != null;
						if (flag3)
						{
							AnnouncementManager._instance.SetupUIManager();
						}
					}
					catch (Exception ex)
					{
					}
				}
			}
		}

		// Token: 0x0600018B RID: 395 RVA: 0x0000FECC File Offset: 0x0000E0CC
		public static void CleanupAll()
		{
			bool flag = !AnnouncementManager._isInitialized || AnnouncementManager._instance == null;
			if (flag)
			{
				Debug.LogWarning("AnnouncementCore: 未初始化，无法清理");
				Debug.LogWarning("提示：请先调用 AnnouncementManager.WakeUp()");
			}
			else
			{
				try
				{
					bool flag2 = AnnouncementManager._instance._uiManager != null;
					if (flag2)
					{
						AnnouncementManager._instance._uiManager.Cleanup();
						AnnouncementManager._instance._uiManager = null;
					}
					AnnouncementState state = AnnouncementManager._instance._state;
					if (state != null)
					{
						state.CleanAll();
					}
					AnnouncementManager._instance._configs.Clear();
				}
				catch (Exception ex)
				{
				}
			}
		}

		// Token: 0x0600018C RID: 396 RVA: 0x0000FF80 File Offset: 0x0000E180
		public static void Rescan()
		{
			bool flag = !AnnouncementManager._isInitialized || AnnouncementManager._instance == null;
			if (flag)
			{
				Debug.LogWarning("AnnouncementCore: 未初始化，无法重新扫描");
			}
			else
			{
				AnnouncementManager._instance.ScanActiveModsForAnnouncements();
				AnnouncementManager._instance._state = new AnnouncementState(AnnouncementManager._instance._configs);
				bool flag2 = AnnouncementManager._instance._uiManager != null;
				if (flag2)
				{
					AnnouncementManager._instance.SetupUIManager();
				}
				Debug.Log("重新扫描完成");
			}
		}

		// Token: 0x040000BF RID: 191
		private const string MANAGER_NAME = "AnnouncementCore_Manager";

		// Token: 0x040000C0 RID: 192
		private static AnnouncementManager _instance;

		// Token: 0x040000C1 RID: 193
		private static bool _isInitialized;

		// Token: 0x040000C2 RID: 194
		private readonly Dictionary<string, AnnouncementConfig> _configs = new Dictionary<string, AnnouncementConfig>();

		// Token: 0x040000C3 RID: 195
		private AnnouncementState _state;

		// Token: 0x040000C4 RID: 196
		private UIManager _uiManager;

		// Token: 0x040000C5 RID: 197
		private List<ApiModListItem> _apiModList = new List<ApiModListItem>();

		// Token: 0x040000C6 RID: 198
		private DateTime _lastModListFetchTime = DateTime.MinValue;

		// Token: 0x040000C7 RID: 199
		private const int MOD_LIST_CACHE_DURATION_MINUTES = 30;

		// Token: 0x040000C8 RID: 200
		private bool _isFetchingModList = false;

		// Token: 0x040000C9 RID: 201
		private bool _isInitializing = false;

		// Token: 0x040000CA RID: 202
		private float _refreshTimer = 0f;

		// Token: 0x040000CB RID: 203
		private const float REFRESH_INTERVAL = 600f;

		// Token: 0x040000CC RID: 204
		private float _updateCheckTimer = 0f;

		// Token: 0x040000CD RID: 205
		private const float UPDATE_CHECK_INTERVAL = 600f;

		// Token: 0x040000CE RID: 206
		private bool _hasAutoShownUpdates = false;
	}
}
