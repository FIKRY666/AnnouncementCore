﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using AnnouncementCore.Data;
using UnityEngine;

namespace AnnouncementCore
{
	// Token: 0x02000002 RID: 2
	public class AnnouncementState
	{
		// Token: 0x14000001 RID: 1
		// (add) Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
		// (remove) Token: 0x06000002 RID: 2 RVA: 0x00002084 File Offset: 0x00000284
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public static event Action<string> OnAnnouncementSelected;

		// Token: 0x14000002 RID: 2
		// (add) Token: 0x06000003 RID: 3 RVA: 0x000020B8 File Offset: 0x000002B8
		// (remove) Token: 0x06000004 RID: 4 RVA: 0x000020EC File Offset: 0x000002EC
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public static event Action<string> OnAnnouncementRead;

		// Token: 0x14000003 RID: 3
		// (add) Token: 0x06000005 RID: 5 RVA: 0x00002120 File Offset: 0x00000320
		// (remove) Token: 0x06000006 RID: 6 RVA: 0x00002154 File Offset: 0x00000354
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public static event Action OnUnreadStatusChanged;

		// Token: 0x14000004 RID: 4
		// (add) Token: 0x06000007 RID: 7 RVA: 0x00002188 File Offset: 0x00000388
		// (remove) Token: 0x06000008 RID: 8 RVA: 0x000021BC File Offset: 0x000003BC
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public static event Action OnPanelStateChanged;

		// Token: 0x14000005 RID: 5
		// (add) Token: 0x06000009 RID: 9 RVA: 0x000021F0 File Offset: 0x000003F0
		// (remove) Token: 0x0600000A RID: 10 RVA: 0x00002224 File Offset: 0x00000424
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public static event Action<string> OnPopupShouldHide;

		// Token: 0x0600000B RID: 11 RVA: 0x00002258 File Offset: 0x00000458
		public AnnouncementState(Dictionary<string, AnnouncementConfig> configs)
		{
			try
			{
				this._configs = (configs ?? new Dictionary<string, AnnouncementConfig>());
				this._readVersions = new Dictionary<string, string>();
				this._popupShownIds = new HashSet<string>();
				this.ValidateConfigs();
				this.LoadReadStatus();
				this.LoadPopupStatus();
				Debug.Log(string.Format("AnnouncementState 初始化完成，共 {0} 个配置", this._configs.Count));
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("AnnouncementState 初始化失败: {0}", arg));
				this._configs = new Dictionary<string, AnnouncementConfig>();
				this._readVersions = new Dictionary<string, string>();
				this._popupShownIds = new HashSet<string>();
			}
		}

		// Token: 0x0600000C RID: 12 RVA: 0x00002330 File Offset: 0x00000530
		public void MarkPopupAsHidden(string modId)
		{
			try
			{
				bool flag = string.IsNullOrEmpty(modId);
				if (!flag)
				{
					AnnouncementConfig configById = this.GetConfigById(modId);
					bool flag2 = configById == null;
					if (!flag2)
					{
						bool flag3 = !configById.HasPermanentUpdate;
						if (flag3)
						{
							this._hiddenPopupIds.Add(modId);
							bool flag4 = !this._popupShownIds.Contains(modId);
							if (flag4)
							{
								this._popupShownIds.Add(modId);
							}
							this.SavePopupStatus();
							Debug.Log("标记弹窗为已隐藏: " + modId);
						}
						else
						{
							Debug.Log("版本更新弹窗不记录隐藏状态: " + modId);
						}
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("标记弹窗隐藏失败: {0}", arg));
			}
		}

		// Token: 0x0600000D RID: 13 RVA: 0x000023FC File Offset: 0x000005FC
		public bool IsPopupHidden(string modId)
		{
			bool result;
			try
			{
				result = (!string.IsNullOrEmpty(modId) && this._hiddenPopupIds.Contains(modId));
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("检查弹窗隐藏状态失败: {0}", arg));
				result = false;
			}
			return result;
		}

		// Token: 0x0600000E RID: 14 RVA: 0x00002450 File Offset: 0x00000650
		public bool ShouldShowPopup(string modId)
		{
			bool result;
			try
			{
				bool flag = string.IsNullOrEmpty(modId) || !this._configs.ContainsKey(modId);
				if (flag)
				{
					result = false;
				}
				else
				{
					AnnouncementConfig announcementConfig = this._configs[modId];
					bool flag2 = announcementConfig == null;
					if (flag2)
					{
						result = false;
					}
					else
					{
						bool flag3 = this.IsPopupHidden(modId);
						if (flag3)
						{
							Debug.Log("弹窗已隐藏，不显示: " + modId);
							result = false;
						}
						else
						{
							bool flag4 = announcementConfig.HasPermanentUpdate && !this.IsRead(modId);
							if (flag4)
							{
								result = true;
							}
							else
							{
								bool flag5 = !announcementConfig.HasPermanentUpdate && !this.IsRead(modId) && !this._popupShownIds.Contains(modId);
								if (flag5)
								{
									result = true;
								}
								else
								{
									result = false;
								}
							}
						}
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("ShouldShowPopup异常: {0}", arg));
				result = false;
			}
			return result;
		}

		// Token: 0x0600000F RID: 15 RVA: 0x00002540 File Offset: 0x00000740
		private void SavePopupStatus()
		{
			try
			{
				string value = string.Join(";", this._popupShownIds);
				PlayerPrefs.SetString("Announcement_PopupShown", value);
				string value2 = string.IsNullOrEmpty(value) ? "" : string.Join(";", this._hiddenPopupIds);
				PlayerPrefs.SetString("Announcement_HiddenPopups", value2);
				PlayerPrefs.Save();
				Debug.Log(string.Format("保存弹窗状态: 已弹窗{0}个, 已隐藏{1}个", this._popupShownIds.Count, this._hiddenPopupIds.Count));
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("保存弹窗状态失败: {0}", arg));
			}
		}

		// Token: 0x06000010 RID: 16 RVA: 0x000025F8 File Offset: 0x000007F8
		private void LoadPopupStatus()
		{
			try
			{
				string @string = PlayerPrefs.GetString("Announcement_PopupShown", "");
				bool flag = !string.IsNullOrEmpty(@string);
				if (flag)
				{
					string[] array = @string.Split(';', StringSplitOptions.None);
					foreach (string text in array)
					{
						bool flag2 = !string.IsNullOrEmpty(text);
						if (flag2)
						{
							this._popupShownIds.Add(text);
						}
					}
				}
				string string2 = PlayerPrefs.GetString("Announcement_HiddenPopups", "");
				bool flag3 = !string.IsNullOrEmpty(string2);
				if (flag3)
				{
					string[] array3 = string2.Split(';', StringSplitOptions.None);
					foreach (string text2 in array3)
					{
						bool flag4 = !string.IsNullOrEmpty(text2);
						if (flag4)
						{
							this._hiddenPopupIds.Add(text2);
						}
					}
				}
				Debug.Log(string.Format("加载弹窗状态: 已弹窗{0}个, 已隐藏{1}个", this._popupShownIds.Count, this._hiddenPopupIds.Count));
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("加载弹窗状态失败: {0}", arg));
			}
		}

		// Token: 0x06000011 RID: 17 RVA: 0x00002740 File Offset: 0x00000940
		private void ValidateConfigs()
		{
			bool flag = this._configs == null;
			if (!flag)
			{
				List<string> list = new List<string>();
				foreach (KeyValuePair<string, AnnouncementConfig> keyValuePair in this._configs)
				{
					bool flag2 = keyValuePair.Value == null || string.IsNullOrEmpty(keyValuePair.Value.ModId);
					if (flag2)
					{
						list.Add(keyValuePair.Key);
						Debug.LogWarning("发现无效配置: key=" + keyValuePair.Key + ", value=" + ((keyValuePair.Value == null) ? "null" : "empty ModId"));
					}
				}
				foreach (string key in list)
				{
					this._configs.Remove(key);
				}
				bool flag3 = list.Count > 0;
				if (flag3)
				{
					Debug.Log(string.Format("移除了 {0} 个无效配置", list.Count));
				}
			}
		}

		// Token: 0x06000012 RID: 18 RVA: 0x00002884 File Offset: 0x00000A84
		public void ClearPopupStatus()
		{
			try
			{
				this._popupShownIds.Clear();
				Debug.Log("已清理弹窗状态");
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("清理弹窗状态失败: {0}", arg));
			}
		}

		// Token: 0x17000001 RID: 1
		// (get) Token: 0x06000013 RID: 19 RVA: 0x000028D4 File Offset: 0x00000AD4
		public string SelectedModId
		{
			get
			{
				return this._selectedModId;
			}
		}

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x06000014 RID: 20 RVA: 0x000028DC File Offset: 0x00000ADC
		public AnnouncementConfig SelectedConfig
		{
			get
			{
				return (this._selectedModId != null && this._configs.ContainsKey(this._selectedModId)) ? this._configs[this._selectedModId] : null;
			}
		}

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x06000015 RID: 21 RVA: 0x00002910 File Offset: 0x00000B10
		public bool HasUnread
		{
			get
			{
				bool result;
				try
				{
					bool flag = this._configs == null || this._configs.Count == 0;
					if (flag)
					{
						result = false;
					}
					else
					{
						foreach (string text in this._configs.Keys)
						{
							bool flag2 = string.IsNullOrEmpty(text);
							if (!flag2)
							{
								bool flag3 = !this.IsRead(text);
								if (flag3)
								{
									return true;
								}
							}
						}
						result = false;
					}
				}
				catch (Exception arg)
				{
					Debug.LogError(string.Format("HasUnread 属性异常: {0}", arg));
					result = false;
				}
				return result;
			}
		}

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x06000016 RID: 22 RVA: 0x000029D8 File Offset: 0x00000BD8
		public int UnreadCount
		{
			get
			{
				int result;
				try
				{
					bool flag = this._configs == null || this._configs.Count == 0;
					if (flag)
					{
						result = 0;
					}
					else
					{
						int num = 0;
						foreach (string text in this._configs.Keys)
						{
							bool flag2 = string.IsNullOrEmpty(text);
							if (!flag2)
							{
								bool flag3 = !this.IsRead(text);
								if (flag3)
								{
									num++;
								}
							}
						}
						result = num;
					}
				}
				catch (Exception arg)
				{
					Debug.LogError(string.Format("UnreadCount 属性异常: {0}", arg));
					result = 0;
				}
				return result;
			}
		}

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x06000017 RID: 23 RVA: 0x00002AA4 File Offset: 0x00000CA4
		public bool AllRead
		{
			get
			{
				bool result;
				try
				{
					bool flag = this._configs == null || this._configs.Count == 0;
					if (flag)
					{
						result = true;
					}
					else
					{
						foreach (KeyValuePair<string, AnnouncementConfig> keyValuePair in this._configs)
						{
							string key = keyValuePair.Key;
							AnnouncementConfig value = keyValuePair.Value;
							bool flag2 = value == null;
							if (!flag2)
							{
								bool hasPermanentUpdate = value.HasPermanentUpdate;
								if (hasPermanentUpdate)
								{
									return false;
								}
								bool flag3 = !this.IsRead(key);
								if (flag3)
								{
									return false;
								}
							}
						}
						result = true;
					}
				}
				catch (Exception arg)
				{
					Debug.LogError(string.Format("AllRead 属性异常: {0}", arg));
					result = true;
				}
				return result;
			}
		}

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x06000018 RID: 24 RVA: 0x00002B8C File Offset: 0x00000D8C
		public int TotalCount
		{
			get
			{
				return this._configs.Count;
			}
		}

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000019 RID: 25 RVA: 0x00002B99 File Offset: 0x00000D99
		public bool IsPanelOpen
		{
			get
			{
				return this._isPanelOpen;
			}
		}

		// Token: 0x0600001A RID: 26 RVA: 0x00002BA4 File Offset: 0x00000DA4
		public List<AnnouncementConfig> GetAllConfigsSorted()
		{
			List<AnnouncementConfig> result;
			try
			{
				bool flag = this._configs == null || this._configs.Count == 0;
				if (flag)
				{
					result = new List<AnnouncementConfig>();
				}
				else
				{
					result = (from config in this._configs.Values
					where config != null
					select config).OrderBy(delegate(AnnouncementConfig config)
					{
						int result2;
						try
						{
							result2 = (this.IsRead(config.ModId) ? 1 : 0);
						}
						catch (Exception ex2)
						{
							Debug.LogError("排序时检查已读状态失败: " + ex2.Message);
							result2 = 1;
						}
						return result2;
					}).ThenBy((AnnouncementConfig config) => ((config != null) ? config.DisplayName : null) ?? string.Empty).ToList<AnnouncementConfig>();
				}
			}
			catch (Exception ex)
			{
				Debug.LogError("获取排序配置列表失败: " + ex.Message);
				result = new List<AnnouncementConfig>();
			}
			return result;
		}

		// Token: 0x0600001B RID: 27 RVA: 0x00002C78 File Offset: 0x00000E78
		public AnnouncementConfig GetConfigById(string modId)
		{
			AnnouncementConfig result;
			try
			{
				bool flag = string.IsNullOrEmpty(modId) || this._configs == null || !this._configs.ContainsKey(modId);
				if (flag)
				{
					result = null;
				}
				else
				{
					result = this._configs[modId];
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("GetConfigById异常: {0}", arg));
				result = null;
			}
			return result;
		}

		// Token: 0x0600001C RID: 28 RVA: 0x00002CE8 File Offset: 0x00000EE8
		public List<AnnouncementConfig> GetPopupConfigs()
		{
			List<AnnouncementConfig> result;
			try
			{
				List<AnnouncementConfig> list = new List<AnnouncementConfig>();
				bool flag = this._configs == null;
				if (flag)
				{
					result = list;
				}
				else
				{
					List<AnnouncementConfig> permanentUpdateConfigs = this.GetPermanentUpdateConfigs();
					list.AddRange(permanentUpdateConfigs);
					List<AnnouncementConfig> unreadConfigs = this.GetUnreadConfigs();
					using (List<AnnouncementConfig>.Enumerator enumerator = unreadConfigs.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							AnnouncementConfig config = enumerator.Current;
							bool flag2 = !list.Any((AnnouncementConfig c) => c.ModId == config.ModId);
							if (flag2)
							{
								list.Add(config);
							}
						}
					}
					Debug.Log(string.Format("获取弹窗配置: 永久更新 {0} 个, 未读 {1} 个, 总计 {2} 个", permanentUpdateConfigs.Count, unreadConfigs.Count, list.Count));
					result = list;
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("GetPopupConfigs 异常: {0}", arg));
				result = new List<AnnouncementConfig>();
			}
			return result;
		}

		// Token: 0x0600001D RID: 29 RVA: 0x00002E04 File Offset: 0x00001004
		private List<AnnouncementConfig> GetPermanentUpdateConfigs()
		{
			List<AnnouncementConfig> list = new List<AnnouncementConfig>();
			foreach (KeyValuePair<string, AnnouncementConfig> keyValuePair in this._configs)
			{
				AnnouncementConfig value = keyValuePair.Value;
				bool flag = value == null;
				if (!flag)
				{
					bool hasPermanentUpdate = value.HasPermanentUpdate;
					if (hasPermanentUpdate)
					{
						list.Add(value);
						Debug.Log(string.Concat(new string[]
						{
							"永久更新弹窗: ",
							value.ModId,
							" (本地: ",
							value.Version,
							", 云端: ",
							value.GetLatestCloudVersion(),
							")"
						}));
					}
				}
			}
			return list;
		}

		// Token: 0x0600001E RID: 30 RVA: 0x00002EE0 File Offset: 0x000010E0
		private List<AnnouncementConfig> GetUnreadConfigs()
		{
			List<AnnouncementConfig> list = new List<AnnouncementConfig>();
			foreach (KeyValuePair<string, AnnouncementConfig> keyValuePair in this._configs)
			{
				string key = keyValuePair.Key;
				AnnouncementConfig value = keyValuePair.Value;
				bool flag = value == null;
				if (!flag)
				{
					bool flag2 = this._popupShownIds.Contains(key);
					bool flag3 = !value.HasPermanentUpdate && !this.IsRead(key) && !flag2;
					if (flag3)
					{
						list.Add(value);
						this._popupShownIds.Add(key);
						Debug.Log(string.Concat(new string[]
						{
							"未读弹窗: ",
							value.ModId,
							" (本地==云端: ",
							value.Version,
							")"
						}));
					}
				}
			}
			return list;
		}

		// Token: 0x0600001F RID: 31 RVA: 0x00002FE8 File Offset: 0x000011E8
		private bool ShouldShowPopup(AnnouncementConfig config, AnnouncementState state)
		{
			bool result;
			try
			{
				bool flag = config == null || state == null;
				if (flag)
				{
					Debug.LogWarning("ShouldShowPopup: 配置或状态为空");
					result = false;
				}
				else
				{
					bool hasPermanentUpdate = config.HasPermanentUpdate;
					if (hasPermanentUpdate)
					{
						Debug.Log(string.Concat(new string[]
						{
							"永久更新弹窗显示: ",
							config.ModId,
							" (本地: ",
							config.Version,
							", 云端: ",
							config.GetLatestCloudVersion(),
							")"
						}));
						result = true;
					}
					else
					{
						bool flag2 = !state.IsRead(config.ModId);
						bool flag3 = flag2;
						if (flag3)
						{
							Debug.Log(string.Concat(new string[]
							{
								"未读弹窗显示: ",
								config.ModId,
								" (本地==云端: ",
								config.Version,
								")"
							}));
							result = true;
						}
						else
						{
							Debug.Log("已读，跳过弹窗: " + config.ModId);
							result = false;
						}
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("ShouldShowPopup 异常: {0}", arg));
				result = false;
			}
			return result;
		}

		// Token: 0x06000020 RID: 32 RVA: 0x00003114 File Offset: 0x00001314
		public void SelectAnnouncement(string modId, bool autoMarkRead = true)
		{
			try
			{
				bool flag = string.IsNullOrEmpty(modId) || this._configs == null || !this._configs.ContainsKey(modId);
				if (flag)
				{
					Debug.LogWarning("SelectAnnouncement: 无效的ModId或配置不存在: " + modId);
				}
				else
				{
					AnnouncementConfig announcementConfig = this._configs[modId];
					bool flag2 = announcementConfig == null;
					if (flag2)
					{
						Debug.LogError("SelectAnnouncement: 配置为空: " + modId);
					}
					else
					{
						bool flag3 = this._configs.ContainsKey(modId);
						if (flag3)
						{
							this._currentAnnouncementIndex[modId] = 0;
						}
						bool flag4 = !this._configs.ContainsKey(modId);
						if (!flag4)
						{
							this._selectedModId = modId;
							Action<string> onAnnouncementSelected = AnnouncementState.OnAnnouncementSelected;
							if (onAnnouncementSelected != null)
							{
								onAnnouncementSelected(modId);
							}
							bool flag5 = autoMarkRead && !this.IsRead(modId);
							if (flag5)
							{
								this.MarkAsRead(modId, null);
							}
						}
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("SelectAnnouncement 异常: {0}", arg));
			}
		}

		// Token: 0x06000021 RID: 33 RVA: 0x00003228 File Offset: 0x00001428
		public void MarkAsRead(string modId, string version = null)
		{
			try
			{
				bool flag = string.IsNullOrEmpty(modId) || !this._configs.ContainsKey(modId);
				if (!flag)
				{
					AnnouncementConfig announcementConfig = this._configs[modId];
					bool flag2 = announcementConfig == null;
					if (!flag2)
					{
						string text = version ?? announcementConfig.Version;
						string latestCloudVersion = announcementConfig.GetLatestCloudVersion();
						bool flag3 = !string.Equals(announcementConfig.Version, latestCloudVersion, StringComparison.OrdinalIgnoreCase);
						if (flag3)
						{
							Debug.Log(string.Concat(new string[]
							{
								"版本不匹配，不能标记为已读: ",
								modId,
								" (本地: ",
								announcementConfig.Version,
								", 云端最新: ",
								latestCloudVersion,
								")"
							}));
							this._popupShownIds.Remove(modId);
						}
						else
						{
							int currentAnnouncementIndex = this.GetCurrentAnnouncementIndex(modId);
							bool flag4 = announcementConfig.ApiAnnouncements != null && announcementConfig.ApiAnnouncements.Count > currentAnnouncementIndex;
							if (flag4)
							{
								ApiAnnouncementData apiAnnouncementData = announcementConfig.ApiAnnouncements[currentAnnouncementIndex];
								bool flag5 = !string.IsNullOrEmpty(apiAnnouncementData.version);
								if (flag5)
								{
									text = apiAnnouncementData.version;
								}
							}
							this._readVersions[modId] = text;
							this.SaveReadStatus();
							this._popupShownIds.Remove(modId);
							Action<string> onAnnouncementRead = AnnouncementState.OnAnnouncementRead;
							if (onAnnouncementRead != null)
							{
								onAnnouncementRead(modId);
							}
							Action onUnreadStatusChanged = AnnouncementState.OnUnreadStatusChanged;
							if (onUnreadStatusChanged != null)
							{
								onUnreadStatusChanged();
							}
							Action<string> onPopupShouldHide = AnnouncementState.OnPopupShouldHide;
							if (onPopupShouldHide != null)
							{
								onPopupShouldHide(modId);
							}
							Debug.Log("已标记为已读: " + modId + " v" + text);
						}
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("MarkAsRead 异常: {0}", arg));
			}
		}

		// Token: 0x06000022 RID: 34 RVA: 0x000033F4 File Offset: 0x000015F4
		public void OpenPanel()
		{
			bool isPanelOpen = this._isPanelOpen;
			if (!isPanelOpen)
			{
				this._isPanelOpen = true;
				Action onPanelStateChanged = AnnouncementState.OnPanelStateChanged;
				if (onPanelStateChanged != null)
				{
					onPanelStateChanged();
				}
			}
		}

		// Token: 0x06000023 RID: 35 RVA: 0x00003428 File Offset: 0x00001628
		public void ClosePanel()
		{
			bool flag = !this._isPanelOpen;
			if (!flag)
			{
				this._isPanelOpen = false;
				Action onPanelStateChanged = AnnouncementState.OnPanelStateChanged;
				if (onPanelStateChanged != null)
				{
					onPanelStateChanged();
				}
			}
		}

		// Token: 0x06000024 RID: 36 RVA: 0x00003460 File Offset: 0x00001660
		public string GetNextAnnouncement()
		{
			List<AnnouncementConfig> allConfigsSorted = this.GetAllConfigsSorted();
			bool flag = allConfigsSorted.Count == 0;
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				int num = (this._selectedModId != null) ? allConfigsSorted.FindIndex((AnnouncementConfig c) => c.ModId == this._selectedModId) : -1;
				result = allConfigsSorted[(num + 1) % allConfigsSorted.Count].ModId;
			}
			return result;
		}

		// Token: 0x06000025 RID: 37 RVA: 0x000034C0 File Offset: 0x000016C0
		public string GetPrevVersion()
		{
			bool flag = this._selectedModId == null || !this._configs.ContainsKey(this._selectedModId);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				AnnouncementConfig announcementConfig = this._configs[this._selectedModId];
				bool flag2 = announcementConfig.ApiAnnouncements == null || announcementConfig.ApiAnnouncements.Count <= 1;
				if (flag2)
				{
					result = null;
				}
				else
				{
					int num = this._currentAnnouncementIndex.ContainsKey(this._selectedModId) ? this._currentAnnouncementIndex[this._selectedModId] : 0;
					bool flag3 = num < announcementConfig.ApiAnnouncements.Count - 1;
					if (flag3)
					{
						this._currentAnnouncementIndex[this._selectedModId] = num + 1;
						result = this._selectedModId;
					}
					else
					{
						result = null;
					}
				}
			}
			return result;
		}

		// Token: 0x06000026 RID: 38 RVA: 0x00003594 File Offset: 0x00001794
		public string GetNextVersion()
		{
			bool flag = this._selectedModId == null || !this._configs.ContainsKey(this._selectedModId);
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				AnnouncementConfig announcementConfig = this._configs[this._selectedModId];
				bool flag2 = announcementConfig.ApiAnnouncements == null || announcementConfig.ApiAnnouncements.Count <= 1;
				if (flag2)
				{
					result = null;
				}
				else
				{
					int num = this._currentAnnouncementIndex.ContainsKey(this._selectedModId) ? this._currentAnnouncementIndex[this._selectedModId] : 0;
					bool flag3 = num > 0;
					if (flag3)
					{
						this._currentAnnouncementIndex[this._selectedModId] = num - 1;
						result = this._selectedModId;
					}
					else
					{
						result = null;
					}
				}
			}
			return result;
		}

		// Token: 0x06000027 RID: 39 RVA: 0x0000365C File Offset: 0x0000185C
		public string GetCurrentAnnouncementTitle()
		{
			bool flag = this._selectedModId == null || !this._configs.ContainsKey(this._selectedModId);
			string result;
			if (flag)
			{
				result = (this._configs.ContainsKey(this._selectedModId) ? this._configs[this._selectedModId].DisplayName : "");
			}
			else
			{
				AnnouncementConfig announcementConfig = this._configs[this._selectedModId];
				int currentAnnouncementIndex = this.GetCurrentAnnouncementIndex(null);
				bool flag2 = announcementConfig.ApiAnnouncements != null && announcementConfig.ApiAnnouncements.Count > currentAnnouncementIndex;
				if (flag2)
				{
					ApiAnnouncementData apiAnnouncementData = announcementConfig.ApiAnnouncements[currentAnnouncementIndex];
					result = ((!string.IsNullOrEmpty(apiAnnouncementData.title)) ? apiAnnouncementData.title : announcementConfig.DisplayName);
				}
				else
				{
					result = announcementConfig.DisplayName;
				}
			}
			return result;
		}

		// Token: 0x06000028 RID: 40 RVA: 0x00003734 File Offset: 0x00001934
		public int GetCurrentAnnouncementIndex(string modId = null)
		{
			modId = (modId ?? this._selectedModId);
			bool flag = modId == null || !this._currentAnnouncementIndex.ContainsKey(modId);
			int result;
			if (flag)
			{
				result = 0;
			}
			else
			{
				result = this._currentAnnouncementIndex[modId];
			}
			return result;
		}

		// Token: 0x06000029 RID: 41 RVA: 0x0000377C File Offset: 0x0000197C
		public int GetTotalAnnouncements(string modId = null)
		{
			modId = (modId ?? this._selectedModId);
			bool flag = modId == null || !this._configs.ContainsKey(modId);
			int result;
			if (flag)
			{
				result = 0;
			}
			else
			{
				List<ApiAnnouncementData> apiAnnouncements = this._configs[modId].ApiAnnouncements;
				result = ((apiAnnouncements != null) ? apiAnnouncements.Count : 0);
			}
			return result;
		}

		// Token: 0x0600002A RID: 42 RVA: 0x000037D8 File Offset: 0x000019D8
		public string GetCurrentAnnouncementVersion()
		{
			bool flag = this._selectedModId == null || !this._configs.ContainsKey(this._selectedModId);
			string result;
			if (flag)
			{
				result = (this._configs.ContainsKey(this._selectedModId) ? this._configs[this._selectedModId].Version : "1.0.0");
			}
			else
			{
				AnnouncementConfig announcementConfig = this._configs[this._selectedModId];
				int currentAnnouncementIndex = this.GetCurrentAnnouncementIndex(null);
				bool flag2 = announcementConfig.ApiAnnouncements != null && announcementConfig.ApiAnnouncements.Count > currentAnnouncementIndex;
				if (flag2)
				{
					ApiAnnouncementData apiAnnouncementData = announcementConfig.ApiAnnouncements[currentAnnouncementIndex];
					result = ((!string.IsNullOrEmpty(apiAnnouncementData.version)) ? apiAnnouncementData.version : announcementConfig.Version);
				}
				else
				{
					result = announcementConfig.Version;
				}
			}
			return result;
		}

		// Token: 0x0600002B RID: 43 RVA: 0x000038B0 File Offset: 0x00001AB0
		public string GetPrevAnnouncement()
		{
			List<AnnouncementConfig> allConfigsSorted = this.GetAllConfigsSorted();
			bool flag = allConfigsSorted.Count == 0;
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				int num = (this._selectedModId != null) ? allConfigsSorted.FindIndex((AnnouncementConfig c) => c.ModId == this._selectedModId) : -1;
				int num2 = num - 1;
				bool flag2 = num2 < 0;
				if (flag2)
				{
					num2 = allConfigsSorted.Count - 1;
				}
				result = allConfigsSorted[num2].ModId;
			}
			return result;
		}

		// Token: 0x0600002C RID: 44 RVA: 0x00003920 File Offset: 0x00001B20
		public bool IsRead(string modId)
		{
			bool result;
			try
			{
				bool flag = string.IsNullOrEmpty(modId) || !this._configs.ContainsKey(modId);
				if (flag)
				{
					result = false;
				}
				else
				{
					AnnouncementConfig announcementConfig = this._configs[modId];
					bool flag2 = announcementConfig == null;
					if (flag2)
					{
						result = false;
					}
					else
					{
						bool hasPermanentUpdate = announcementConfig.HasPermanentUpdate;
						if (hasPermanentUpdate)
						{
							result = false;
						}
						else
						{
							bool flag3 = !this._readVersions.ContainsKey(modId);
							if (flag3)
							{
								result = false;
							}
							else
							{
								string a = this._readVersions[modId];
								string currentAnnouncementVersionForReading = this.GetCurrentAnnouncementVersionForReading(modId);
								result = string.Equals(a, currentAnnouncementVersionForReading, StringComparison.OrdinalIgnoreCase);
							}
						}
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("IsRead 异常: {0}", arg));
				result = false;
			}
			return result;
		}

		// Token: 0x0600002D RID: 45 RVA: 0x000039EC File Offset: 0x00001BEC
		private string GetCurrentAnnouncementVersionForReading(string modId)
		{
			AnnouncementConfig announcementConfig = this._configs[modId];
			bool flag = announcementConfig == null;
			string result;
			if (flag)
			{
				result = (((announcementConfig != null) ? announcementConfig.Version : null) ?? "1.0.0");
			}
			else
			{
				int currentAnnouncementIndex = this.GetCurrentAnnouncementIndex(modId);
				bool flag2 = announcementConfig.ApiAnnouncements != null && announcementConfig.ApiAnnouncements.Count > currentAnnouncementIndex;
				if (flag2)
				{
					ApiAnnouncementData apiAnnouncementData = announcementConfig.ApiAnnouncements[currentAnnouncementIndex];
					bool flag3 = !string.IsNullOrEmpty(apiAnnouncementData.version);
					if (flag3)
					{
						return apiAnnouncementData.version;
					}
				}
				result = announcementConfig.Version;
			}
			return result;
		}

		// Token: 0x0600002E RID: 46 RVA: 0x00003A88 File Offset: 0x00001C88
		public bool ContainsMod(string modId)
		{
			bool result;
			try
			{
				result = (!string.IsNullOrEmpty(modId) && this._configs != null && this._configs.ContainsKey(modId));
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("ContainsMod 异常: {0}", arg));
				result = false;
			}
			return result;
		}

		// Token: 0x0600002F RID: 47 RVA: 0x00003AE4 File Offset: 0x00001CE4
		private void SaveReadStatus()
		{
			try
			{
				List<string> list = new List<string>();
				foreach (KeyValuePair<string, string> keyValuePair in this._readVersions)
				{
					string key = keyValuePair.Key;
					string value = keyValuePair.Value;
					bool flag = !string.IsNullOrEmpty(key) && !string.IsNullOrEmpty(value);
					if (flag)
					{
						string text = "Announcement_Read_" + key;
						PlayerPrefs.SetString(text, value);
						list.Add(text);
					}
				}
				PlayerPrefs.SetString("Announcement_ReadKeys", string.Join(";", list));
				PlayerPrefs.Save();
				Debug.Log(string.Format("已保存 {0} 个已读记录", list.Count));
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("保存已读状态失败: {0}", arg));
			}
		}

		// Token: 0x06000030 RID: 48 RVA: 0x00003BE8 File Offset: 0x00001DE8
		private void LoadReadStatus()
		{
			try
			{
				this._readVersions.Clear();
				string @string = PlayerPrefs.GetString("Announcement_ReadKeys", "");
				bool flag = !string.IsNullOrEmpty(@string);
				if (flag)
				{
					string[] array = @string.Split(';', StringSplitOptions.None);
					foreach (string text in array)
					{
						bool flag2 = string.IsNullOrEmpty(text);
						if (!flag2)
						{
							string string2 = PlayerPrefs.GetString(text, "");
							bool flag3 = !string.IsNullOrEmpty(string2);
							if (flag3)
							{
								string text2 = text.Replace("Announcement_Read_", "");
								bool flag4 = this._configs.ContainsKey(text2);
								if (flag4)
								{
									this._readVersions[text2] = string2;
								}
								else
								{
									Debug.LogWarning("跳过不存在的已读记录: " + text2);
								}
							}
						}
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("加载已读状态失败: {0}", arg));
				this._readVersions.Clear();
			}
		}

		// Token: 0x06000031 RID: 49 RVA: 0x00003D08 File Offset: 0x00001F08
		public void CleanMod(string modId)
		{
			try
			{
				bool flag = string.IsNullOrEmpty(modId) || !this._configs.ContainsKey(modId);
				if (!flag)
				{
					this._configs.Remove(modId);
					this._readVersions.Remove(modId);
					this._popupShownIds.Remove(modId);
					string key = "Announcement_Read_" + modId;
					PlayerPrefs.DeleteKey(key);
					PlayerPrefs.Save();
					bool flag2 = this._selectedModId == modId;
					if (flag2)
					{
						this._selectedModId = null;
					}
					Debug.Log("已清理Mod弹窗状态: " + modId);
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("CleanMod 异常: {0}", arg));
			}
		}

		// Token: 0x06000032 RID: 50 RVA: 0x00003DCC File Offset: 0x00001FCC
		public void CleanAll()
		{
			foreach (string str in this._configs.Keys)
			{
				string key = "Announcement_Read_" + str;
				PlayerPrefs.DeleteKey(key);
			}
			PlayerPrefs.Save();
			this._configs.Clear();
			this._readModIds.Clear();
			this._popupShownIds.Clear();
			this._selectedModId = null;
		}

		// Token: 0x06000033 RID: 51 RVA: 0x00003E68 File Offset: 0x00002068
		public void Clear()
		{
			this._readModIds.Clear();
			this._popupShownIds.Clear();
			this._selectedModId = null;
			this._isPanelOpen = false;
		}

		// Token: 0x04000006 RID: 6
		private readonly Dictionary<string, AnnouncementConfig> _configs;

		// Token: 0x04000007 RID: 7
		private readonly Dictionary<string, string> _readVersions;

		// Token: 0x04000008 RID: 8
		private readonly HashSet<string> _popupShownIds;

		// Token: 0x04000009 RID: 9
		private readonly HashSet<string> _readModIds;

		// Token: 0x0400000A RID: 10
		private string _selectedModId;

		// Token: 0x0400000B RID: 11
		private bool _isPanelOpen = false;

		// Token: 0x0400000C RID: 12
		private Dictionary<string, int> _currentAnnouncementIndex = new Dictionary<string, int>();

		// Token: 0x0400000D RID: 13
		private HashSet<string> _hiddenPopupIds = new HashSet<string>();
	}
}
