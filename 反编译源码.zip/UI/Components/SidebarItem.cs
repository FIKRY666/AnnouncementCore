﻿using System;
using System.Collections;
using AnnouncementCore.Data;
using AnnouncementCore.UI.Effects;
using AnnouncementCore.Utility;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace AnnouncementCore.UI.Components
{
	// Token: 0x0200000F RID: 15
	public class SidebarItem : MonoBehaviour
	{
		// Token: 0x060000FE RID: 254 RVA: 0x0000AC0C File Offset: 0x00008E0C
		public void Initialize(AnnouncementConfig config, AnnouncementState state, Action<string> onClick)
		{
			this._config = config;
			this._state = state;
			this._modId = config.ModId;
			this._isUnread = !state.IsRead(this._modId);
			this.InitializeBadge();
			this.UpdateUI();
			this.Button.onClick.AddListener(delegate()
			{
				AudioUtility.PlayClickSound();
				this.StartCoroutine(this.PlayClickAnimation());
				Action<string> onClick2 = onClick;
				if (onClick2 != null)
				{
					onClick2(this._modId);
				}
			});
			ButtonHoverEffect buttonHoverEffect = base.gameObject.AddComponent<ButtonHoverEffect>();
			buttonHoverEffect.ButtonImage = this.Background;
			buttonHoverEffect.ButtonComponent = this.Button;
			buttonHoverEffect.ConfigureForSidebarItem();
		}

		// Token: 0x060000FF RID: 255 RVA: 0x0000ACB4 File Offset: 0x00008EB4
		private void InitializeBadge()
		{
			try
			{
				bool flag = this.UnreadBadge == null;
				if (!flag)
				{
					this.BadgeImage = this.UnreadBadge.GetComponent<Image>();
					bool flag2 = this.BadgeImage == null;
					if (flag2)
					{
						this.BadgeImage = this.UnreadBadge.AddComponent<Image>();
					}
					Sprite sprite = this.LoadSprite("unread_badge");
					bool flag3 = sprite != null;
					if (flag3)
					{
						this.BadgeImage.sprite = sprite;
						this.BadgeImage.type = 0;
						this.BadgeImage.preserveAspect = true;
					}
					else
					{
						Debug.LogWarning("未找到未读角标素材，使用默认样式");
						this.BadgeImage.color = SidebarItem.UNREAD_TEXT_COLOR;
					}
					this._originalBadgeScale = this.UnreadBadge.transform.localScale;
					this.UnreadBadge.SetActive(false);
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("初始化角标失败: {0}", arg));
			}
		}

		// Token: 0x06000100 RID: 256 RVA: 0x0000ADBC File Offset: 0x00008FBC
		private IEnumerator PlayClickAnimation()
		{
			SidebarItem.<PlayClickAnimation>d__20 <PlayClickAnimation>d__ = new SidebarItem.<PlayClickAnimation>d__20(0);
			<PlayClickAnimation>d__.<>4__this = this;
			return <PlayClickAnimation>d__;
		}

		// Token: 0x06000101 RID: 257 RVA: 0x0000ADCC File Offset: 0x00008FCC
		private float ElasticEaseOut(float t)
		{
			bool flag = t >= 1f;
			float result;
			if (flag)
			{
				result = 1f;
			}
			else
			{
				float num = 0.3f;
				float num2 = num / 4f;
				result = Mathf.Pow(2f, -10f * t) * Mathf.Sin((t - num2) * 6.2831855f / num) + 1f;
			}
			return result;
		}

		// Token: 0x06000102 RID: 258 RVA: 0x0000AE2B File Offset: 0x0000902B
		public void SetSelected(bool selected)
		{
			this._isSelected = selected;
			this.UpdateUI();
		}

		// Token: 0x06000103 RID: 259 RVA: 0x0000AE3C File Offset: 0x0000903C
		public void UpdateReadStatus()
		{
			bool isUnread = this._isUnread;
			this._isUnread = !this._state.IsRead(this._modId);
			bool flag = isUnread && !this._isUnread;
			if (flag)
			{
				this.StopBadgeAnimation();
				this.HideBadge();
			}
			this.UpdateUI();
		}

		// Token: 0x06000104 RID: 260 RVA: 0x0000AE98 File Offset: 0x00009098
		private void UpdateUI()
		{
			try
			{
				bool isSelected = this._isSelected;
				if (isSelected)
				{
					this.Background.sprite = this.LoadSprite("list_item_selected");
					bool flag = this.Background.sprite == null;
					if (flag)
					{
						this.Background.color = SidebarItem.SELECTED_COLOR;
					}
				}
				else
				{
					bool isUnread = this._isUnread;
					if (isUnread)
					{
						this.Background.sprite = this.LoadSprite("list_item_unread");
						bool flag2 = this.Background.sprite == null;
						if (flag2)
						{
							this.Background.color = SidebarItem.UNREAD_COLOR;
						}
						this.ShowBadgeAndStartAnimation();
					}
					else
					{
						this.Background.sprite = this.LoadSprite("list_item_normal");
						bool flag3 = this.Background.sprite == null;
						if (flag3)
						{
							this.Background.color = SidebarItem.READ_COLOR;
						}
						this.HideBadge();
					}
				}
				bool flag4 = this.NameText != null;
				if (flag4)
				{
					this.NameText.text = this._config.DisplayName;
					this.NameText.color = (this._isUnread ? Color.white : SidebarItem.READ_TEXT_COLOR);
				}
				bool flag5 = this.VersionText != null;
				if (flag5)
				{
					this.VersionText.text = "v" + this._config.Version;
					this.VersionText.color = (this._isUnread ? SidebarItem.UNREAD_TEXT_COLOR : SidebarItem.READ_TEXT_COLOR);
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("更新UI失败: {0}", arg));
			}
		}

		// Token: 0x06000105 RID: 261 RVA: 0x0000B068 File Offset: 0x00009268
		private void ShowBadgeAndStartAnimation()
		{
			bool flag = this.UnreadBadge == null || this.BadgeImage == null;
			if (!flag)
			{
				try
				{
					this.UnreadBadge.SetActive(true);
					Sprite sprite = this.LoadSprite("unread_badge");
					bool flag2 = sprite != null;
					if (flag2)
					{
						this.BadgeImage.sprite = sprite;
					}
					this.BadgeImage.color = Color.white;
					bool flag3 = this._badgeAnimationCoroutine == null;
					if (flag3)
					{
						this._badgeAnimationCoroutine = base.StartCoroutine(this.BadgePulseAnimation());
					}
					Debug.Log("显示角标: " + this._modId);
				}
				catch (Exception arg)
				{
					Debug.LogError(string.Format("显示角标失败: {0}", arg));
				}
			}
		}

		// Token: 0x06000106 RID: 262 RVA: 0x0000B144 File Offset: 0x00009344
		private void HideBadge()
		{
			bool flag = this.UnreadBadge == null;
			if (!flag)
			{
				try
				{
					this.UnreadBadge.SetActive(false);
					this.StopBadgeAnimation();
					this.UnreadBadge.transform.localScale = this._originalBadgeScale;
					Debug.Log("隐藏角标: " + this._modId);
				}
				catch (Exception arg)
				{
					Debug.LogError(string.Format("隐藏角标失败: {0}", arg));
				}
			}
		}

		// Token: 0x06000107 RID: 263 RVA: 0x0000B1D0 File Offset: 0x000093D0
		private IEnumerator BadgePulseAnimation()
		{
			SidebarItem.<BadgePulseAnimation>d__27 <BadgePulseAnimation>d__ = new SidebarItem.<BadgePulseAnimation>d__27(0);
			<BadgePulseAnimation>d__.<>4__this = this;
			return <BadgePulseAnimation>d__;
		}

		// Token: 0x06000108 RID: 264 RVA: 0x0000B1E0 File Offset: 0x000093E0
		private void StopBadgeAnimation()
		{
			bool flag = this._badgeAnimationCoroutine != null;
			if (flag)
			{
				base.StopCoroutine(this._badgeAnimationCoroutine);
				this._badgeAnimationCoroutine = null;
			}
			bool flag2 = this.UnreadBadge != null;
			if (flag2)
			{
				this.UnreadBadge.transform.localScale = this._originalBadgeScale;
				this.UnreadBadge.transform.localRotation = Quaternion.identity;
			}
		}

		// Token: 0x06000109 RID: 265 RVA: 0x0000B250 File Offset: 0x00009450
		private Sprite LoadSprite(string spriteName)
		{
			Sprite result;
			try
			{
				bool flag = string.IsNullOrEmpty(spriteName);
				if (flag)
				{
					result = null;
				}
				else
				{
					Sprite sprite = ResourceLoader.LoadSprite(spriteName);
					bool flag2 = sprite == null;
					if (flag2)
					{
						string resourceName = spriteName.ToLower().Replace("_", "");
						sprite = ResourceLoader.LoadSprite(resourceName);
						bool flag3 = sprite == null;
						if (flag3)
						{
							string resourceName2 = spriteName.Replace("_", "").Replace("-", "");
							sprite = ResourceLoader.LoadSprite(resourceName2);
						}
					}
					result = sprite;
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("加载素材图片失败 {0}: {1}", spriteName, arg));
				result = null;
			}
			return result;
		}

		// Token: 0x0600010A RID: 266 RVA: 0x0000B30C File Offset: 0x0000950C
		private void OnDestroy()
		{
			this.StopBadgeAnimation();
			bool flag = this.Button != null;
			if (flag)
			{
				this.Button.onClick.RemoveAllListeners();
			}
		}

		// Token: 0x04000073 RID: 115
		[Header("组件引用")]
		public Image Background;

		// Token: 0x04000074 RID: 116
		public Button Button;

		// Token: 0x04000075 RID: 117
		public TextMeshProUGUI NameText;

		// Token: 0x04000076 RID: 118
		public TextMeshProUGUI VersionText;

		// Token: 0x04000077 RID: 119
		public GameObject UnreadBadge;

		// Token: 0x04000078 RID: 120
		public Image BadgeImage;

		// Token: 0x04000079 RID: 121
		private AnnouncementConfig _config;

		// Token: 0x0400007A RID: 122
		private AnnouncementState _state;

		// Token: 0x0400007B RID: 123
		private string _modId;

		// Token: 0x0400007C RID: 124
		private bool _isSelected = false;

		// Token: 0x0400007D RID: 125
		private bool _isUnread = false;

		// Token: 0x0400007E RID: 126
		private Coroutine _badgeAnimationCoroutine;

		// Token: 0x0400007F RID: 127
		private Vector3 _originalBadgeScale;

		// Token: 0x04000080 RID: 128
		private static readonly Color SELECTED_COLOR = new Color(0.2f, 0.2f, 0.3f, 1f);

		// Token: 0x04000081 RID: 129
		private static readonly Color UNREAD_COLOR = new Color(0.3f, 0.3f, 0.4f, 1f);

		// Token: 0x04000082 RID: 130
		private static readonly Color READ_COLOR = new Color(0.1f, 0.1f, 0.15f, 0.8f);

		// Token: 0x04000083 RID: 131
		private static readonly Color UNREAD_TEXT_COLOR = new Color(1f, 0.9176471f, 0.5803922f, 1f);

		// Token: 0x04000084 RID: 132
		private static readonly Color READ_TEXT_COLOR = new Color(0.8f, 0.8f, 0.8f, 1f);
	}
}
