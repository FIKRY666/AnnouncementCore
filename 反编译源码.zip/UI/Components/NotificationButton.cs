﻿using System;
using System.Collections;
using AnnouncementCore.UI.Effects;
using AnnouncementCore.Utility;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace AnnouncementCore.UI.Components
{
	// Token: 0x0200000E RID: 14
	public class NotificationButton : MonoBehaviour
	{
		// Token: 0x1700000D RID: 13
		// (get) Token: 0x060000EB RID: 235 RVA: 0x0000A37E File Offset: 0x0000857E
		public bool IsInitialized
		{
			get
			{
				return this._isInitialized;
			}
		}

		// Token: 0x060000EC RID: 236 RVA: 0x0000A388 File Offset: 0x00008588
		public void HideButton()
		{
			try
			{
				bool flag = this._buttonObject != null && this._buttonObject.activeSelf;
				if (flag)
				{
					this._buttonObject.SetActive(false);
					Debug.Log("通知按钮已隐藏");
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("隐藏通知按钮失败: {0}", arg));
			}
		}

		// Token: 0x060000ED RID: 237 RVA: 0x0000A3FC File Offset: 0x000085FC
		public void ShowButton()
		{
			try
			{
				bool flag = this._buttonObject != null && !this._buttonObject.activeSelf;
				if (flag)
				{
					this._buttonObject.SetActive(true);
					Debug.Log("通知按钮已显示");
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("显示通知按钮失败: {0}", arg));
			}
		}

		// Token: 0x060000EE RID: 238 RVA: 0x0000A474 File Offset: 0x00008674
		public void Initialize(Transform parent, Action onClick)
		{
			try
			{
				bool flag = parent == null;
				if (flag)
				{
					Debug.LogError("NotificationButton: 父对象为空");
				}
				else
				{
					this._onClickCallback = onClick;
					this.CreateButtonObject(parent);
					this.ConfigureButtonComponents();
					this.SetupHoverEffect();
					this._isInitialized = true;
					this._originalButtonScale = this._buttonObject.transform.localScale;
					this._originalButtonRotation = this._buttonObject.transform.localEulerAngles;
					Debug.Log("NotificationButton: 初始化完成");
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("NotificationButton 初始化异常: {0}", arg));
				this._isInitialized = false;
			}
		}

		// Token: 0x060000EF RID: 239 RVA: 0x0000A528 File Offset: 0x00008728
		private void CreateButtonObject(Transform parent)
		{
			this._buttonObject = new GameObject("NotificationButton");
			this._buttonObject.transform.SetParent(parent, false);
			RectTransform rectTransform = this._buttonObject.AddComponent<RectTransform>();
			rectTransform.anchorMin = new Vector2(1f, 1f);
			rectTransform.anchorMax = new Vector2(1f, 1f);
			rectTransform.pivot = new Vector2(0.5f, 0.5f);
			rectTransform.anchoredPosition = new Vector2(-60f, -60f);
			rectTransform.sizeDelta = new Vector2(60f, 60f);
			this._buttonImage = this._buttonObject.AddComponent<Image>();
			this._buttonImage.sprite = this.LoadSprite("notification_button");
			bool flag = this._buttonImage.sprite == null;
			if (flag)
			{
				this._buttonImage.color = new Color(0.9f, 0.9f, 0.9f, 0.9f);
			}
			this._buttonImage.type = 1;
		}

		// Token: 0x060000F0 RID: 240 RVA: 0x0000A644 File Offset: 0x00008844
		private void ConfigureButtonComponents()
		{
			this._buttonComponent = this._buttonObject.AddComponent<Button>();
			this._buttonComponent.onClick.AddListener(new UnityAction(this.OnButtonClicked));
		}

		// Token: 0x060000F1 RID: 241 RVA: 0x0000A678 File Offset: 0x00008878
		private void SetupHoverEffect()
		{
			this._hoverEffect = this._buttonObject.AddComponent<ConsolidatedHoverEffect>();
			this._hoverEffect.ButtonImage = this._buttonImage;
			this._hoverEffect.ButtonComponent = this._buttonComponent;
			this._hoverEffect.SetEffectType(ConsolidatedHoverEffect.EffectType.NotificationButton);
		}

		// Token: 0x060000F2 RID: 242 RVA: 0x0000A6C8 File Offset: 0x000088C8
		private void OnButtonClicked()
		{
			AudioUtility.PlayClickSound();
			base.StartCoroutine(this.PlayButtonClickAnimation(this._buttonObject.transform));
			Action onClickCallback = this._onClickCallback;
			if (onClickCallback != null)
			{
				onClickCallback();
			}
		}

		// Token: 0x060000F3 RID: 243 RVA: 0x0000A6FB File Offset: 0x000088FB
		private IEnumerator PlayButtonClickAnimation(Transform buttonTransform)
		{
			NotificationButton.<PlayButtonClickAnimation>d__33 <PlayButtonClickAnimation>d__ = new NotificationButton.<PlayButtonClickAnimation>d__33(0);
			<PlayButtonClickAnimation>d__.<>4__this = this;
			<PlayButtonClickAnimation>d__.buttonTransform = buttonTransform;
			return <PlayButtonClickAnimation>d__;
		}

		// Token: 0x060000F4 RID: 244 RVA: 0x0000A714 File Offset: 0x00008914
		private float ElasticEaseOut(float t)
		{
			bool flag = t >= 1f;
			float result;
			if (flag)
			{
				result = 1f;
			}
			else
			{
				float num = 0.3f;
				float num2 = num / 4f;
				result = Mathf.Pow(2f, -10f * t) * Mathf.Sin((t - num2) * 6.2831855f / num) + 1f;
			}
			return result;
		}

		// Token: 0x060000F5 RID: 245 RVA: 0x0000A774 File Offset: 0x00008974
		public void UpdateUnreadIndicator(int unreadCount)
		{
			this._currentUnreadCount = unreadCount;
			bool flag = unreadCount > 0;
			if (flag)
			{
				this.EnsureUnreadBadgeExists();
				this._badgeText.text = unreadCount.ToString();
				this._badgeObject.SetActive(true);
				this.StartBreathingAnimation();
				Debug.Log(string.Format("通知按钮: {0} 个未读公告", unreadCount));
			}
			else
			{
				bool flag2 = this._badgeObject != null;
				if (flag2)
				{
					this._badgeObject.SetActive(false);
				}
				this.StopBreathingAnimation();
			}
		}

		// Token: 0x060000F6 RID: 246 RVA: 0x0000A804 File Offset: 0x00008A04
		private void EnsureUnreadBadgeExists()
		{
			bool flag = this._badgeObject != null;
			if (!flag)
			{
				this._badgeObject = new GameObject("UnreadBadge");
				RectTransform rectTransform = this._badgeObject.AddComponent<RectTransform>();
				rectTransform.SetParent(this._buttonObject.transform, false);
				rectTransform.anchorMin = new Vector2(1f, 1f);
				rectTransform.anchorMax = new Vector2(1f, 1f);
				rectTransform.pivot = new Vector2(1f, 1f);
				rectTransform.anchoredPosition = new Vector2(5f, -5f);
				rectTransform.sizeDelta = new Vector2(22f, 22f);
				this._badgeImage = this._badgeObject.AddComponent<Image>();
				this._badgeImage.sprite = this.LoadSprite("notification_badge");
				bool flag2 = this._badgeImage.sprite == null;
				if (flag2)
				{
					this._badgeImage.color = new Color(1f, 0.3f, 0.3f, 1f);
				}
				this._badgeImage.type = 0;
				this._badgeImage.preserveAspect = true;
				GameObject gameObject = new GameObject("BadgeText");
				RectTransform rectTransform2 = gameObject.AddComponent<RectTransform>();
				rectTransform2.SetParent(rectTransform, false);
				rectTransform2.anchorMin = Vector2.zero;
				rectTransform2.anchorMax = Vector2.one;
				rectTransform2.pivot = new Vector2(0.5f, 0.5f);
				rectTransform2.offsetMin = Vector2.zero;
				rectTransform2.offsetMax = Vector2.zero;
				this._badgeText = gameObject.AddComponent<TextMeshProUGUI>();
				this._badgeText.text = "1";
				this._badgeText.fontSize = 14f;
				this._badgeText.color = Color.white;
				this._badgeText.alignment = 514;
				this._badgeText.fontStyle = 1;
				this._badgeText.raycastTarget = false;
				this._badgeText.verticalAlignment = 512;
				this._badgeText.horizontalAlignment = 2;
				this._badgeObject.SetActive(false);
			}
		}

		// Token: 0x060000F7 RID: 247 RVA: 0x0000AA3A File Offset: 0x00008C3A
		private void StartBreathingAnimation()
		{
			this.StopBreathingAnimation();
			this._breathingAnimationCoroutine = base.StartCoroutine(this.BreathingAnimation());
		}

		// Token: 0x060000F8 RID: 248 RVA: 0x0000AA58 File Offset: 0x00008C58
		private void StopBreathingAnimation()
		{
			bool flag = this._breathingAnimationCoroutine != null;
			if (flag)
			{
				base.StopCoroutine(this._breathingAnimationCoroutine);
				this._breathingAnimationCoroutine = null;
				this.ResetAllAnimationStates();
			}
		}

		// Token: 0x060000F9 RID: 249 RVA: 0x0000AA90 File Offset: 0x00008C90
		private void ResetAllAnimationStates()
		{
			bool flag = this._buttonObject != null;
			if (flag)
			{
				this._buttonObject.transform.localScale = this._originalButtonScale;
				this._buttonObject.transform.localEulerAngles = this._originalButtonRotation;
			}
			bool flag2 = this._badgeObject != null;
			if (flag2)
			{
				this._badgeObject.transform.localScale = Vector3.one;
				this._badgeObject.transform.localEulerAngles = Vector3.zero;
			}
		}

		// Token: 0x060000FA RID: 250 RVA: 0x0000AB1C File Offset: 0x00008D1C
		private IEnumerator BreathingAnimation()
		{
			NotificationButton.<BreathingAnimation>d__40 <BreathingAnimation>d__ = new NotificationButton.<BreathingAnimation>d__40(0);
			<BreathingAnimation>d__.<>4__this = this;
			return <BreathingAnimation>d__;
		}

		// Token: 0x060000FB RID: 251 RVA: 0x0000AB2C File Offset: 0x00008D2C
		private Sprite LoadSprite(string spriteName)
		{
			Sprite result;
			try
			{
				result = ResourceLoader.LoadSprite(spriteName);
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x060000FC RID: 252 RVA: 0x0000AB5C File Offset: 0x00008D5C
		public void Cleanup()
		{
			try
			{
				this.StopBreathingAnimation();
				bool flag = this._buttonObject != null;
				if (flag)
				{
					Object.Destroy(this._buttonObject);
					this._buttonObject = null;
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("NotificationButton清理异常: {0}", arg));
			}
			this._buttonImage = null;
			this._badgeImage = null;
			this._badgeText = null;
			this._badgeObject = null;
			this._hoverEffect = null;
			this._buttonComponent = null;
			this._isInitialized = false;
		}

		// Token: 0x0400005B RID: 91
		private GameObject _buttonObject;

		// Token: 0x0400005C RID: 92
		private Image _buttonImage;

		// Token: 0x0400005D RID: 93
		private GameObject _badgeObject;

		// Token: 0x0400005E RID: 94
		private Image _badgeImage;

		// Token: 0x0400005F RID: 95
		private TextMeshProUGUI _badgeText;

		// Token: 0x04000060 RID: 96
		private ConsolidatedHoverEffect _hoverEffect;

		// Token: 0x04000061 RID: 97
		private Button _buttonComponent;

		// Token: 0x04000062 RID: 98
		private bool _isInitialized = false;

		// Token: 0x04000063 RID: 99
		private int _currentUnreadCount = 0;

		// Token: 0x04000064 RID: 100
		private Action _onClickCallback;

		// Token: 0x04000065 RID: 101
		private Coroutine _breathingAnimationCoroutine;

		// Token: 0x04000066 RID: 102
		private Vector3 _originalButtonScale;

		// Token: 0x04000067 RID: 103
		private Vector3 _originalButtonRotation;

		// Token: 0x04000068 RID: 104
		private const float BUTTON_ROTATION_AMPLITUDE = 3f;

		// Token: 0x04000069 RID: 105
		private const float BUTTON_ROTATION_SPEED = 1.5f;

		// Token: 0x0400006A RID: 106
		private const float BUTTON_SCALE_AMPLITUDE = 0.05f;

		// Token: 0x0400006B RID: 107
		private const float BUTTON_SCALE_SPEED = 2f;

		// Token: 0x0400006C RID: 108
		private const float BADGE_SCALE_AMPLITUDE = 0.15f;

		// Token: 0x0400006D RID: 109
		private const float BADGE_SCALE_SPEED = 2.2f;

		// Token: 0x0400006E RID: 110
		private const float BADGE_ROTATION_AMPLITUDE = 2f;

		// Token: 0x0400006F RID: 111
		private const float BADGE_ROTATION_SPEED = 1.8f;

		// Token: 0x04000070 RID: 112
		private const float BUTTON_SCALE_PHASE_OFFSET = 0.3f;

		// Token: 0x04000071 RID: 113
		private const float BADGE_SCALE_PHASE_OFFSET = 0.7f;

		// Token: 0x04000072 RID: 114
		private const float BADGE_ROTATION_PHASE_OFFSET = 0.5f;
	}
}
