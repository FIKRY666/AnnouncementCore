﻿using System;
using System.Collections;
using System.Collections.Generic;
using AnnouncementCore.Data;
using AnnouncementCore.UI.Effects;
using AnnouncementCore.Utility;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace AnnouncementCore.UI.Components
{
	// Token: 0x0200000D RID: 13
	public class MainPanel : MonoBehaviour
	{
		// Token: 0x1700000C RID: 12
		// (get) Token: 0x060000C8 RID: 200 RVA: 0x00009133 File Offset: 0x00007333
		public bool IsInitialized
		{
			get
			{
				return this._isInitialized;
			}
		}

		// Token: 0x060000C9 RID: 201 RVA: 0x0000913C File Offset: 0x0000733C
		public void Initialize(Transform parent, AnnouncementState state, UIAnimator animator)
		{
			try
			{
				this._state = state;
				this._animator = animator;
				this.CreatePanel(parent);
				this.CreateSubComponents();
				this._isInitialized = true;
				Debug.Log("MainPanel: 初始化完成");
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("MainPanel 初始化异常: {0}", arg));
				this._isInitialized = false;
			}
		}

		// Token: 0x060000CA RID: 202 RVA: 0x000091AC File Offset: 0x000073AC
		private void CreatePanel(Transform parent)
		{
			try
			{
				this._panelObject = new GameObject("MainPanel");
				this._panelObject.transform.SetParent(parent, false);
				RectTransform rectTransform = this._panelObject.AddComponent<RectTransform>();
				rectTransform.anchorMin = Vector2.zero;
				rectTransform.anchorMax = Vector2.one;
				rectTransform.offsetMin = Vector2.zero;
				rectTransform.offsetMax = Vector2.zero;
				this._canvasGroup = this._panelObject.AddComponent<CanvasGroup>();
				this._canvasGroup.alpha = 0f;
				GameObject gameObject = this.CreateContentContainer();
				this.CreateBackground(gameObject.transform);
				this.CreateHeader(gameObject.transform);
				this.CreateSidebarArea(gameObject.transform);
				this.CreateContentArea(gameObject.transform);
				this.CreateBottomArea(gameObject.transform);
				this._panelObject.SetActive(false);
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("创建面板异常: {0}", arg));
			}
		}

		// Token: 0x060000CB RID: 203 RVA: 0x000092BC File Offset: 0x000074BC
		private GameObject CreateContentContainer()
		{
			GameObject gameObject = new GameObject("ContentContainer");
			gameObject.transform.SetParent(this._panelObject.transform, false);
			RectTransform rectTransform = gameObject.AddComponent<RectTransform>();
			rectTransform.anchorMin = new Vector2(0.5f, 0.5f);
			rectTransform.anchorMax = new Vector2(0.5f, 0.5f);
			rectTransform.pivot = new Vector2(0.5f, 0.5f);
			rectTransform.anchoredPosition = Vector2.zero;
			rectTransform.sizeDelta = new Vector2(800f, 650f);
			return gameObject;
		}

		// Token: 0x060000CC RID: 204 RVA: 0x00009360 File Offset: 0x00007560
		private void CreateBackground(Transform parent)
		{
			GameObject gameObject = new GameObject("Background", new Type[]
			{
				typeof(RectTransform),
				typeof(Image)
			});
			gameObject.transform.SetParent(parent, false);
			RectTransform component = gameObject.GetComponent<RectTransform>();
			component.anchorMin = Vector2.zero;
			component.anchorMax = Vector2.one;
			component.offsetMin = Vector2.zero;
			component.offsetMax = Vector2.zero;
			Image component2 = gameObject.GetComponent<Image>();
			component2.sprite = this.LoadSprite("panel_background");
			bool flag = component2.sprite == null;
			if (flag)
			{
				component2.color = new Color(0.05f, 0.05f, 0.08f, 0.85f);
			}
			else
			{
				component2.type = 1;
			}
		}

		// Token: 0x060000CD RID: 205 RVA: 0x00009438 File Offset: 0x00007638
		private void CreateHeader(Transform parent)
		{
			this.CreateTextElement(parent, "LeftTitle", new Vector2(-280f, 280f), new Vector2(120f, 30f), "更新公告", 20, 513);
			GameObject gameObject = new GameObject("MainTitleContainer");
			gameObject.transform.SetParent(parent, false);
			RectTransform rectTransform = gameObject.AddComponent<RectTransform>();
			rectTransform.anchorMin = new Vector2(0.5f, 0.5f);
			rectTransform.anchorMax = new Vector2(0.5f, 0.5f);
			rectTransform.pivot = new Vector2(0.5f, 0.5f);
			rectTransform.anchoredPosition = new Vector2(0f, 280f);
			rectTransform.sizeDelta = new Vector2(400f, 30f);
			this.CreateTextElement(gameObject.transform, "MainTitle", new Vector2(100f, 0f), new Vector2(400f, 30f), "", 20, 513);
			GameObject gameObject2 = new GameObject("RightContainer");
			gameObject2.transform.SetParent(parent, false);
			RectTransform rectTransform2 = gameObject2.AddComponent<RectTransform>();
			rectTransform2.anchorMin = new Vector2(0.5f, 0.5f);
			rectTransform2.anchorMax = new Vector2(0.5f, 0.5f);
			rectTransform2.pivot = new Vector2(0.5f, 0.5f);
			rectTransform2.anchoredPosition = new Vector2(100f, 280f);
			rectTransform2.sizeDelta = new Vector2(270f, 30f);
			this.CreateVersionText(gameObject2.transform);
			this.CreateCloseButton(parent);
			this.CreateAnnouncementIndex(parent);
		}

		// Token: 0x060000CE RID: 206 RVA: 0x000095F4 File Offset: 0x000077F4
		private void CreateVersionText(Transform parent)
		{
			GameObject gameObject = new GameObject("Version", new Type[]
			{
				typeof(RectTransform),
				typeof(TextMeshProUGUI)
			});
			gameObject.transform.SetParent(parent, false);
			RectTransform component = gameObject.GetComponent<RectTransform>();
			component.anchorMin = new Vector2(1f, 0.5f);
			component.anchorMax = new Vector2(1f, 0.5f);
			component.pivot = new Vector2(1f, 0.5f);
			component.anchoredPosition = new Vector2(80f, 0f);
			component.sizeDelta = new Vector2(80f, 30f);
			TextMeshProUGUI component2 = gameObject.GetComponent<TextMeshProUGUI>();
			component2.text = "v1.0.0";
			component2.fontSize = 20f;
			component2.color = Color.white;
			component2.alignment = 516;
			component2.fontStyle = 1;
		}

		// Token: 0x060000CF RID: 207 RVA: 0x000096F0 File Offset: 0x000078F0
		private void CreateAnnouncementIndex(Transform parent)
		{
			GameObject gameObject = new GameObject("AnnouncementIndex");
			gameObject.transform.SetParent(parent, false);
			RectTransform rectTransform = gameObject.AddComponent<RectTransform>();
			rectTransform.anchoredPosition = new Vector2(350f, 210f);
			rectTransform.sizeDelta = new Vector2(60f, 20f);
			TextMeshProUGUI textMeshProUGUI = gameObject.AddComponent<TextMeshProUGUI>();
			textMeshProUGUI.text = "1/1";
			textMeshProUGUI.fontSize = 16f;
			textMeshProUGUI.color = new Color(0.9f, 0.9f, 0.9f, 1f);
			textMeshProUGUI.alignment = 514;
		}

		// Token: 0x060000D0 RID: 208 RVA: 0x00009798 File Offset: 0x00007998
		private void CreateCloseButton(Transform parent)
		{
			GameObject gameObject = this.CreateButton(parent, "Close_Button", new Vector2(350f, 280f), new Vector2(30f, 30f));
			Image component = gameObject.GetComponent<Image>();
			component.sprite = ResourceLoader.LoadSprite("close_button");
			bool flag = component.sprite == null;
			if (flag)
			{
				component.color = new Color(0.97f, 0.33f, 0.4f, 1f);
			}
			else
			{
				component.type = 1;
			}
			Button component2 = gameObject.GetComponent<Button>();
			component2.onClick.AddListener(delegate()
			{
				AudioUtility.PlayClickSound();
				Action onCloseClicked = this._onCloseClicked;
				if (onCloseClicked != null)
				{
					onCloseClicked();
				}
			});
			ButtonHoverEffect buttonHoverEffect = gameObject.AddComponent<ButtonHoverEffect>();
			buttonHoverEffect.ButtonImage = gameObject.GetComponent<Image>();
			buttonHoverEffect.ButtonComponent = component2;
			buttonHoverEffect.ConfigureForPopupButton();
		}

		// Token: 0x060000D1 RID: 209 RVA: 0x0000986C File Offset: 0x00007A6C
		private void CreateSidebarArea(Transform parent)
		{
			try
			{
				GameObject gameObject = new GameObject("SidebarBackground");
				gameObject.transform.SetParent(parent, false);
				RectTransform rectTransform = gameObject.AddComponent<RectTransform>();
				rectTransform.anchorMin = new Vector2(0f, 0f);
				rectTransform.anchorMax = new Vector2(0f, 0f);
				rectTransform.pivot = new Vector2(0f, 0f);
				rectTransform.anchoredPosition = new Vector2(15f, 15f);
				rectTransform.sizeDelta = new Vector2(240f, 546f);
				this._sidebarList = gameObject.AddComponent<SidebarList>();
				bool flag = this._state != null;
				if (flag)
				{
					this._sidebarList.Initialize(this._state, new Action<string>(this.OnSidebarItemClicked));
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x060000D2 RID: 210 RVA: 0x00009960 File Offset: 0x00007B60
		private void CreateContentArea(Transform parent)
		{
			GameObject gameObject = new GameObject("ContentBackground", new Type[]
			{
				typeof(RectTransform),
				typeof(Image)
			});
			gameObject.transform.SetParent(parent, false);
			RectTransform component = gameObject.GetComponent<RectTransform>();
			component.anchorMin = new Vector2(0f, 0f);
			component.anchorMax = new Vector2(0f, 0f);
			component.pivot = new Vector2(0f, 0f);
			component.anchoredPosition = new Vector2(270f, 15f);
			component.sizeDelta = new Vector2(513f, 546f);
			Image component2 = gameObject.GetComponent<Image>();
			component2.sprite = this.LoadSprite("content_bg");
			bool flag = component2.sprite == null;
			if (flag)
			{
				component2.color = new Color(0.1f, 0.1f, 0.15f, 0.8f);
			}
			component2.type = 1;
			this._contentArea = gameObject.AddComponent<ContentArea>();
			this._contentArea.Initialize();
		}

		// Token: 0x060000D3 RID: 211 RVA: 0x00009A88 File Offset: 0x00007C88
		private void CreateBottomArea(Transform parent)
		{
			this._bottomNavigation = parent.gameObject.AddComponent<BottomNavigation>();
			this._bottomNavigation.Initialize(null, new Action(this.RefreshPanel), delegate
			{
				Action onPrevClicked = this._onPrevClicked;
				if (onPrevClicked != null)
				{
					onPrevClicked();
				}
			}, delegate
			{
				Action onNextClicked = this._onNextClicked;
				if (onNextClicked != null)
				{
					onNextClicked();
				}
			}, delegate
			{
				Action onFeedbackClicked = this._onFeedbackClicked;
				if (onFeedbackClicked != null)
				{
					onFeedbackClicked();
				}
			}, this._state);
		}

		// Token: 0x060000D4 RID: 212 RVA: 0x00009AEA File Offset: 0x00007CEA
		private void CreateSubComponents()
		{
			this.RefreshPanel();
		}

		// Token: 0x060000D5 RID: 213 RVA: 0x00009AF4 File Offset: 0x00007CF4
		private void OnSidebarItemClicked(string modId)
		{
			this._state.SelectAnnouncement(modId, true);
		}

		// Token: 0x060000D6 RID: 214 RVA: 0x00009B08 File Offset: 0x00007D08
		private GameObject CreateTextElement(Transform parent, string name, Vector2 position, Vector2 size, string text, int fontSize = 16, TextAlignmentOptions alignment = 513)
		{
			GameObject gameObject = new GameObject(name, new Type[]
			{
				typeof(RectTransform),
				typeof(TextMeshProUGUI)
			});
			gameObject.transform.SetParent(parent, false);
			RectTransform component = gameObject.GetComponent<RectTransform>();
			component.anchorMin = new Vector2(0.5f, 0.5f);
			component.anchorMax = new Vector2(0.5f, 0.5f);
			component.pivot = new Vector2(0.5f, 0.5f);
			component.anchoredPosition = position;
			component.sizeDelta = size;
			TextMeshProUGUI component2 = gameObject.GetComponent<TextMeshProUGUI>();
			component2.text = text;
			component2.fontSize = (float)fontSize;
			component2.color = Color.white;
			component2.alignment = alignment;
			component2.fontStyle = 1;
			return gameObject;
		}

		// Token: 0x060000D7 RID: 215 RVA: 0x00009BE4 File Offset: 0x00007DE4
		private GameObject CreateButton(Transform parent, string name, Vector2 position, Vector2 size)
		{
			GameObject gameObject = new GameObject(name, new Type[]
			{
				typeof(RectTransform),
				typeof(Image),
				typeof(Button)
			});
			gameObject.transform.SetParent(parent, false);
			RectTransform component = gameObject.GetComponent<RectTransform>();
			component.anchorMin = new Vector2(0.5f, 0.5f);
			component.anchorMax = new Vector2(0.5f, 0.5f);
			component.pivot = new Vector2(0.5f, 0.5f);
			component.anchoredPosition = position;
			component.sizeDelta = size;
			Image component2 = gameObject.GetComponent<Image>();
			component2.sprite = this.LoadSprite(name.ToLower());
			bool flag = component2.sprite == null;
			if (flag)
			{
				bool flag2 = name.Contains("Close");
				if (flag2)
				{
					component2.sprite = ResourceLoader.LoadSprite("close_button");
					bool flag3 = component2.sprite == null;
					if (flag3)
					{
						component2.color = new Color(0.97f, 0.33f, 0.4f, 1f);
					}
				}
				else
				{
					bool flag4 = name.Contains("Prev") || name.Contains("Next");
					if (flag4)
					{
						component2.color = new Color(0.13f, 0.63f, 0.76f, 1f);
					}
					else
					{
						bool flag5 = name.Contains("Feedback");
						if (flag5)
						{
							component2.color = new Color(0.43f, 0.77f, 0.29f, 1f);
						}
						else
						{
							component2.color = new Color(0.2f, 0.6f, 0.9f, 1f);
						}
					}
				}
			}
			component2.type = 1;
			return gameObject;
		}

		// Token: 0x060000D8 RID: 216 RVA: 0x00009DC0 File Offset: 0x00007FC0
		private Sprite LoadSprite(string spriteName)
		{
			Sprite result;
			try
			{
				result = ResourceLoader.LoadSprite(spriteName);
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x060000D9 RID: 217 RVA: 0x00009DF0 File Offset: 0x00007FF0
		public void SetCallbacks(Action onPrevClicked, Action onNextClicked, Action onFeedbackClicked, Action onCloseClicked)
		{
			this._onPrevClicked = onPrevClicked;
			this._onNextClicked = onNextClicked;
			this._onFeedbackClicked = onFeedbackClicked;
			this._onCloseClicked = onCloseClicked;
		}

		// Token: 0x060000DA RID: 218 RVA: 0x00009E10 File Offset: 0x00008010
		public void Show()
		{
			bool flag = !this._isInitialized;
			if (!flag)
			{
				try
				{
					this._panelObject.SetActive(true);
					this._canvasGroup.alpha = 0f;
					base.StartCoroutine(this.DelayedShowAnimation());
				}
				catch (Exception ex)
				{
				}
			}
		}

		// Token: 0x060000DB RID: 219 RVA: 0x00009E74 File Offset: 0x00008074
		private IEnumerator DelayedShowAnimation()
		{
			MainPanel.<DelayedShowAnimation>d__39 <DelayedShowAnimation>d__ = new MainPanel.<DelayedShowAnimation>d__39(0);
			<DelayedShowAnimation>d__.<>4__this = this;
			return <DelayedShowAnimation>d__;
		}

		// Token: 0x060000DC RID: 220 RVA: 0x00009E84 File Offset: 0x00008084
		public void Hide()
		{
			bool flag = !this._isInitialized;
			if (!flag)
			{
				try
				{
					bool flag2 = this._animator != null;
					if (flag2)
					{
						base.StartCoroutine(this._animator.PanelHideAnimation(this._panelObject.transform, this._canvasGroup, delegate
						{
							this._panelObject.SetActive(false);
						}));
					}
					else
					{
						this._canvasGroup.alpha = 0f;
						this._panelObject.SetActive(false);
					}
				}
				catch (Exception ex)
				{
				}
			}
		}

		// Token: 0x060000DD RID: 221 RVA: 0x00009F1C File Offset: 0x0000811C
		public void UpdateContent(string modId, bool animate = false)
		{
			bool flag = !this._isInitialized;
			if (!flag)
			{
				try
				{
					AnnouncementConfig selectedConfig = this._state.SelectedConfig;
					bool flag2 = selectedConfig == null;
					if (!flag2)
					{
						this.UpdateTextElement("MainTitleContainer/MainTitle", selectedConfig.DisplayName, new TextAlignmentOptions?(513));
						string currentAnnouncementVersion = this.GetCurrentAnnouncementVersion(selectedConfig);
						this.UpdateTextElement("RightContainer/Version", "v" + currentAnnouncementVersion, new TextAlignmentOptions?(516));
						this.UpdateAnnouncementIndex();
						bool flag3 = this._contentArea != null && this._panelObject.activeSelf;
						if (flag3)
						{
							int currentAnnouncementIndex = this._state.GetCurrentAnnouncementIndex(null);
							this._contentArea.UpdateContent(selectedConfig, currentAnnouncementIndex);
						}
					}
				}
				catch (Exception ex)
				{
				}
			}
		}

		// Token: 0x060000DE RID: 222 RVA: 0x0000A000 File Offset: 0x00008200
		private string GetCurrentAnnouncementVersion(AnnouncementConfig config)
		{
			bool flag = config == null;
			string result;
			if (flag)
			{
				result = "1.0.0";
			}
			else
			{
				bool flag2 = this._state != null;
				if (flag2)
				{
					int currentAnnouncementIndex = this._state.GetCurrentAnnouncementIndex(null);
					bool flag3 = config.ApiAnnouncements != null && config.ApiAnnouncements.Count > currentAnnouncementIndex;
					if (flag3)
					{
						ApiAnnouncementData apiAnnouncementData = config.ApiAnnouncements[currentAnnouncementIndex];
						bool flag4 = !string.IsNullOrEmpty(apiAnnouncementData.version);
						if (flag4)
						{
							return apiAnnouncementData.version;
						}
					}
				}
				result = config.Version;
			}
			return result;
		}

		// Token: 0x060000DF RID: 223 RVA: 0x0000A094 File Offset: 0x00008294
		private void UpdateAnnouncementIndex()
		{
			try
			{
				Transform transform = this._panelObject.transform.Find("ContentContainer/AnnouncementIndex");
				bool flag = transform != null;
				if (flag)
				{
					TextMeshProUGUI component = transform.GetComponent<TextMeshProUGUI>();
					bool flag2 = component != null && this._state != null;
					if (flag2)
					{
						int num = this._state.GetCurrentAnnouncementIndex(null) + 1;
						int totalAnnouncements = this._state.GetTotalAnnouncements(null);
						component.text = string.Format("{0}/{1}", num, totalAnnouncements);
					}
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x060000E0 RID: 224 RVA: 0x0000A140 File Offset: 0x00008340
		public void RefreshSidebarList()
		{
			bool flag = !this._isInitialized || this._state == null;
			if (!flag)
			{
				List<AnnouncementConfig> allConfigsSorted = this._state.GetAllConfigsSorted();
				SidebarList sidebarList = this._sidebarList;
				if (sidebarList != null)
				{
					sidebarList.Refresh(allConfigsSorted);
				}
			}
		}

		// Token: 0x060000E1 RID: 225 RVA: 0x0000A188 File Offset: 0x00008388
		public void RefreshPanel()
		{
			this.RefreshSidebarList();
			AnnouncementState state = this._state;
			bool flag = ((state != null) ? state.SelectedConfig : null) != null;
			if (flag)
			{
				this.UpdateContent(this._state.SelectedModId, false);
			}
		}

		// Token: 0x060000E2 RID: 226 RVA: 0x0000A1CC File Offset: 0x000083CC
		private void UpdateTextElement(string path, string text, TextAlignmentOptions? alignment = null)
		{
			try
			{
				Transform transform = this._panelObject.transform.Find("ContentContainer/" + path);
				bool flag = transform != null;
				if (flag)
				{
					TextMeshProUGUI component = transform.GetComponent<TextMeshProUGUI>();
					bool flag2 = component != null;
					if (flag2)
					{
						component.text = text;
						bool flag3 = alignment != null;
						if (flag3)
						{
							component.alignment = alignment.Value;
						}
					}
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x060000E3 RID: 227 RVA: 0x0000A258 File Offset: 0x00008458
		public void Cleanup()
		{
			try
			{
				SidebarList sidebarList = this._sidebarList;
				if (sidebarList != null)
				{
					sidebarList.Cleanup();
				}
				ContentArea contentArea = this._contentArea;
				if (contentArea != null)
				{
					contentArea.Cleanup();
				}
				BottomNavigation bottomNavigation = this._bottomNavigation;
				if (bottomNavigation != null)
				{
					bottomNavigation.Cleanup();
				}
				bool flag = this._panelObject != null;
				if (flag)
				{
					Object.Destroy(this._panelObject);
				}
			}
			catch (Exception)
			{
			}
			this._panelObject = null;
			this._canvasGroup = null;
			this._state = null;
			this._animator = null;
			this._isInitialized = false;
		}

		// Token: 0x04000048 RID: 72
		private AnnouncementState _state;

		// Token: 0x04000049 RID: 73
		private UIAnimator _animator;

		// Token: 0x0400004A RID: 74
		private GameObject _panelObject;

		// Token: 0x0400004B RID: 75
		private CanvasGroup _canvasGroup;

		// Token: 0x0400004C RID: 76
		private SidebarList _sidebarList;

		// Token: 0x0400004D RID: 77
		private ContentArea _contentArea;

		// Token: 0x0400004E RID: 78
		private BottomNavigation _bottomNavigation;

		// Token: 0x0400004F RID: 79
		private Action _onPrevClicked;

		// Token: 0x04000050 RID: 80
		private Action _onNextClicked;

		// Token: 0x04000051 RID: 81
		private Action _onFeedbackClicked;

		// Token: 0x04000052 RID: 82
		private Action _onCloseClicked;

		// Token: 0x04000053 RID: 83
		private const float TITLE_BASE_Y = 280f;

		// Token: 0x04000054 RID: 84
		private const float CONTENT_OFFSET_X = -20f;

		// Token: 0x04000055 RID: 85
		private const float CONTENT_OFFSET_Y = -5f;

		// Token: 0x04000056 RID: 86
		private Button _prevButton;

		// Token: 0x04000057 RID: 87
		private Button _nextButton;

		// Token: 0x04000058 RID: 88
		private Image _prevButtonImage;

		// Token: 0x04000059 RID: 89
		private Image _nextButtonImage;

		// Token: 0x0400005A RID: 90
		private bool _isInitialized = false;
	}
}
