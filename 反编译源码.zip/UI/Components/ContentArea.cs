﻿using System;
using System.Collections;
using AnnouncementCore.Data;
using AnnouncementCore.Utility;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace AnnouncementCore.UI.Components
{
	// Token: 0x0200000C RID: 12
	public class ContentArea : MonoBehaviour
	{
		// Token: 0x060000B6 RID: 182 RVA: 0x00007D0C File Offset: 0x00005F0C
		public void Initialize()
		{
			try
			{
				this.CreateInfoSection();
				this.CreateContentScrollArea();
				this.FixRaycastTargets();
				this.SetupLinkClickHandler();
				this._isInitialized = true;
				Debug.Log("ContentArea: 初始化完成");
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("ContentArea 初始化异常: {0}", arg));
			}
		}

		// Token: 0x060000B7 RID: 183 RVA: 0x00007D74 File Offset: 0x00005F74
		private void SetupLinkClickHandler()
		{
			bool flag = this._contentText != null;
			if (flag)
			{
				this.AddLinkClickEventViaEventTrigger();
			}
		}

		// Token: 0x060000B8 RID: 184 RVA: 0x00007D9C File Offset: 0x00005F9C
		private void AddLinkClickEventViaEventTrigger()
		{
			try
			{
				EventTrigger eventTrigger = this._contentText.gameObject.AddComponent<EventTrigger>();
				this._contentText.raycastTarget = true;
				EventTrigger.Entry entry = new EventTrigger.Entry();
				entry.eventID = 4;
				entry.callback.AddListener(delegate(BaseEventData data)
				{
					this.OnTextClicked((PointerEventData)data);
				});
				eventTrigger.triggers.Add(entry);
				Debug.Log("链接点击事件监听器已添加（通过EventTrigger）");
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("添加链接点击事件失败: {0}", arg));
			}
		}

		// Token: 0x060000B9 RID: 185 RVA: 0x00007E30 File Offset: 0x00006030
		private void OnTextClicked(PointerEventData eventData)
		{
			try
			{
				int num = TMP_TextUtilities.FindIntersectingLink(this._contentText, eventData.position, null);
				bool flag = num != -1;
				if (flag)
				{
					TMP_LinkInfo tmp_LinkInfo = this._contentText.textInfo.linkInfo[num];
					string linkID = tmp_LinkInfo.GetLinkID();
					Debug.Log("链接被点击: ID=" + linkID + ", Text=" + tmp_LinkInfo.GetLinkText());
					bool flag2 = this.IsValidUrl(linkID);
					if (flag2)
					{
						Application.OpenURL(linkID);
						Debug.Log("打开链接: " + linkID);
					}
					else
					{
						Debug.LogWarning("无效的链接URL: " + linkID);
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("处理文本点击失败: {0}", arg));
			}
		}

		// Token: 0x060000BA RID: 186 RVA: 0x00007F08 File Offset: 0x00006108
		private bool IsValidUrl(string url)
		{
			bool flag = string.IsNullOrEmpty(url);
			return !flag && (url.StartsWith("http://", StringComparison.OrdinalIgnoreCase) || url.StartsWith("https://", StringComparison.OrdinalIgnoreCase) || url.StartsWith("mailto:", StringComparison.OrdinalIgnoreCase) || url.StartsWith("tel:", StringComparison.OrdinalIgnoreCase));
		}

		// Token: 0x060000BB RID: 187 RVA: 0x00007F64 File Offset: 0x00006164
		private void CreateInfoSection()
		{
			try
			{
				GameObject gameObject = new GameObject("InfoSection");
				RectTransform rectTransform = gameObject.AddComponent<RectTransform>();
				rectTransform.SetParent(base.transform, false);
				rectTransform.anchorMin = new Vector2(0f, 1f);
				rectTransform.anchorMax = new Vector2(1f, 1f);
				rectTransform.pivot = new Vector2(0.5f, 1f);
				rectTransform.anchoredPosition = Vector2.zero;
				rectTransform.anchoredPosition = new Vector2(0f, -40f);
				rectTransform.sizeDelta = new Vector2(-20f, 80f);
				Image image = gameObject.AddComponent<Image>();
				image.sprite = ResourceLoader.LoadSprite("info_bg");
				bool flag = image.sprite == null;
				if (flag)
				{
					image.color = new Color(0.1f, 0.1f, 0.15f, 0.7f);
				}
				image.type = 1;
				image.raycastTarget = true;
				GameObject gameObject2 = new GameObject("InfoText");
				RectTransform rectTransform2 = gameObject2.AddComponent<RectTransform>();
				rectTransform2.SetParent(rectTransform, false);
				rectTransform2.anchorMin = Vector2.zero;
				rectTransform2.anchorMax = Vector2.one;
				rectTransform2.pivot = new Vector2(0.5f, 0.5f);
				rectTransform2.offsetMin = new Vector2(10f, 5f);
				rectTransform2.offsetMax = new Vector2(-10f, -5f);
				this._infoText = gameObject2.AddComponent<TextMeshProUGUI>();
				this._infoText.fontSize = 14f;
				this._infoText.color = Color.white;
				this._infoText.alignment = 513;
				this._infoText.fontStyle = 1;
				this._infoText.enableWordWrapping = true;
				this._infoText.raycastTarget = false;
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("创建信息区异常: {0}", arg));
			}
		}

		// Token: 0x060000BC RID: 188 RVA: 0x00008184 File Offset: 0x00006384
		private void CreateContentScrollArea()
		{
			try
			{
				this._scrollArea = new GameObject("ContentScrollArea");
				RectTransform rectTransform = this._scrollArea.AddComponent<RectTransform>();
				rectTransform.SetParent(base.transform, false);
				rectTransform.anchorMin = new Vector2(0f, 0f);
				rectTransform.anchorMax = new Vector2(1f, 1f);
				rectTransform.pivot = new Vector2(0.5f, 0.5f);
				rectTransform.offsetMin = new Vector2(10f, 10f);
				rectTransform.offsetMax = new Vector2(-10f, -150f);
				this._scrollRect = this._scrollArea.AddComponent<ScrollRect>();
				this._scrollRect.horizontal = false;
				this._scrollRect.vertical = true;
				this._scrollRect.movementType = 1;
				this._scrollRect.scrollSensitivity = 1f;
				this._scrollRect.inertia = true;
				this._scrollRect.decelerationRate = 0.135f;
				this._scrollRect.elasticity = 0.1f;
				GameObject gameObject = new GameObject("Viewport");
				RectTransform rectTransform2 = gameObject.AddComponent<RectTransform>();
				rectTransform2.SetParent(rectTransform, false);
				rectTransform2.anchorMin = Vector2.zero;
				rectTransform2.anchorMax = Vector2.one;
				rectTransform2.pivot = new Vector2(0.5f, 0.5f);
				rectTransform2.offsetMin = Vector2.zero;
				rectTransform2.offsetMax = Vector2.zero;
				Mask mask = gameObject.AddComponent<Mask>();
				mask.showMaskGraphic = false;
				Image image = gameObject.AddComponent<Image>();
				image.color = new Color(0f, 0f, 0f, 0f);
				image.raycastTarget = true;
				image.enabled = true;
				GameObject gameObject2 = new GameObject("Content");
				RectTransform rectTransform3 = gameObject2.AddComponent<RectTransform>();
				rectTransform3.SetParent(rectTransform2, false);
				rectTransform3.anchorMin = new Vector2(0f, 1f);
				rectTransform3.anchorMax = new Vector2(1f, 1f);
				rectTransform3.pivot = new Vector2(0.5f, 1f);
				rectTransform3.anchoredPosition = Vector2.zero;
				rectTransform3.sizeDelta = new Vector2(0f, 100f);
				this._scrollRect.viewport = rectTransform2;
				this._scrollRect.content = rectTransform3;
				ContentSizeFitter contentSizeFitter = gameObject2.AddComponent<ContentSizeFitter>();
				contentSizeFitter.verticalFit = 2;
				contentSizeFitter.horizontalFit = 0;
				LayoutElement layoutElement = gameObject2.AddComponent<LayoutElement>();
				layoutElement.minHeight = 100f;
				layoutElement.preferredHeight = -1f;
				VerticalLayoutGroup verticalLayoutGroup = gameObject2.AddComponent<VerticalLayoutGroup>();
				verticalLayoutGroup.padding = new RectOffset(0, 0, 0, 0);
				verticalLayoutGroup.spacing = 0f;
				verticalLayoutGroup.childAlignment = 0;
				verticalLayoutGroup.childControlHeight = false;
				verticalLayoutGroup.childControlWidth = true;
				verticalLayoutGroup.childForceExpandHeight = false;
				verticalLayoutGroup.childForceExpandWidth = true;
				GameObject gameObject3 = new GameObject("Text");
				RectTransform rectTransform4 = gameObject3.AddComponent<RectTransform>();
				rectTransform4.SetParent(rectTransform3, false);
				rectTransform4.anchorMin = new Vector2(0f, 1f);
				rectTransform4.anchorMax = new Vector2(1f, 1f);
				rectTransform4.pivot = new Vector2(0.5f, 1f);
				rectTransform4.anchoredPosition = Vector2.zero;
				rectTransform4.sizeDelta = new Vector2(-20f, 0f);
				this._contentText = gameObject3.AddComponent<TextMeshProUGUI>();
				this._contentText.text = "正在加载内容...";
				this._contentText.alignment = 257;
				this._contentText.color = new Color(0.9f, 0.92f, 0.95f, 1f);
				this._contentText.fontSize = 18f;
				this._contentText.richText = true;
				this._contentText.overflowMode = 0;
				this._contentText.enableWordWrapping = true;
				this._contentText.margin = new Vector4(15f, 10f, 15f, 10f);
				this._contentText.raycastTarget = false;
				LayoutElement layoutElement2 = gameObject3.AddComponent<LayoutElement>();
				layoutElement2.minHeight = 50f;
				layoutElement2.preferredHeight = -1f;
				this._scrollArea.transform.SetAsLastSibling();
				this._scrollRect.verticalNormalizedPosition = 1f;
				this.AddScrollAreaDebugComponents();
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("创建内容滚动区域异常: {0}", arg));
			}
		}

		// Token: 0x060000BD RID: 189 RVA: 0x00008650 File Offset: 0x00006850
		private void AddScrollAreaDebugComponents()
		{
			try
			{
				EventTrigger eventTrigger = this._scrollArea.AddComponent<EventTrigger>();
				EventTrigger.Entry entry = new EventTrigger.Entry();
				entry.eventID = 4;
				entry.callback.AddListener(delegate(BaseEventData data)
				{
				});
				eventTrigger.triggers.Add(entry);
				EventTrigger.Entry entry2 = new EventTrigger.Entry();
				entry2.eventID = 13;
				entry2.callback.AddListener(delegate(BaseEventData data)
				{
				});
				eventTrigger.triggers.Add(entry2);
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("添加滚动区域调试组件异常: {0}", arg));
			}
		}

		// Token: 0x060000BE RID: 190 RVA: 0x00008720 File Offset: 0x00006920
		private void FixRaycastTargets()
		{
			try
			{
				bool flag = this._scrollArea == null;
				if (!flag)
				{
					Image[] componentsInChildren = this._scrollArea.GetComponentsInChildren<Image>(true);
					foreach (Image image in componentsInChildren)
					{
						string name = image.gameObject.name;
						bool flag2 = name.Contains("Viewport") || name.Contains("Background") || name.Contains("ContentScrollArea");
						if (flag2)
						{
							bool flag3 = !image.raycastTarget;
							if (flag3)
							{
								image.raycastTarget = true;
							}
						}
						else
						{
							bool flag4 = name.Contains("Text") || name.Contains("Info");
							if (flag4)
							{
								bool raycastTarget = image.raycastTarget;
								if (raycastTarget)
								{
									image.raycastTarget = false;
								}
							}
						}
					}
					TextMeshProUGUI[] componentsInChildren2 = this._scrollArea.GetComponentsInChildren<TextMeshProUGUI>(true);
					foreach (TextMeshProUGUI textMeshProUGUI in componentsInChildren2)
					{
						bool raycastTarget2 = textMeshProUGUI.raycastTarget;
						if (raycastTarget2)
						{
							textMeshProUGUI.raycastTarget = false;
						}
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("修复raycastTarget异常: {0}", arg));
			}
		}

		// Token: 0x060000BF RID: 191 RVA: 0x0000888C File Offset: 0x00006A8C
		public void TestScrollRectFunctionality()
		{
			bool flag = !this._isInitialized || this._scrollArea == null;
			if (!flag)
			{
				try
				{
					Debug.Log("=== 滚动区域诊断 ===");
					Debug.Log(string.Format("1. ScrollRect状态: enabled={0}, vertical={1}", this._scrollRect.enabled, this._scrollRect.vertical));
					string str = "2. Viewport: ";
					RectTransform viewport = this._scrollRect.viewport;
					string str2 = (viewport != null) ? viewport.name : null;
					string str3 = ", Content: ";
					RectTransform content = this._scrollRect.content;
					Debug.Log(str + str2 + str3 + ((content != null) ? content.name : null));
					bool flag2 = this._scrollRect.viewport != null;
					if (flag2)
					{
						Image component = this._scrollRect.viewport.GetComponent<Image>();
						Debug.Log(string.Format("3. Viewport Image: {0}, raycastTarget={1}", component != null, component != null && component.raycastTarget));
						Mask component2 = this._scrollRect.viewport.GetComponent<Mask>();
						Debug.Log(string.Format("4. Viewport Mask: {0}, showMaskGraphic={1}", component2 != null, component2 != null && component2.showMaskGraphic));
					}
					bool flag3 = this._scrollRect.content != null;
					if (flag3)
					{
						Debug.Log(string.Format("5. Content尺寸: {0}, 子物体数量: {1}", this._scrollRect.content.sizeDelta, this._scrollRect.content.childCount));
						Transform transform = this._scrollRect.content.Find("Text");
						bool flag4 = transform != null;
						if (flag4)
						{
							TextMeshProUGUI component3 = transform.GetComponent<TextMeshProUGUI>();
							Debug.Log(string.Format("6. 文本内容: 长度={0}, 首选高度={1}", component3.text.Length, component3.preferredHeight));
						}
					}
					Canvas componentInParent = this._scrollArea.GetComponentInParent<Canvas>();
					bool flag5 = componentInParent != null;
					if (flag5)
					{
						Debug.Log(string.Format("7. 父Canvas: {0}, renderMode={1}, sortingOrder={2}", componentInParent.name, componentInParent.renderMode, componentInParent.sortingOrder));
					}
					this._scrollRect.verticalNormalizedPosition = 0.5f;
					Debug.Log(string.Format("8. 测试滚动位置设置: {0}", this._scrollRect.verticalNormalizedPosition));
					Debug.Log("=== 诊断结束 ===");
				}
				catch (Exception arg)
				{
					Debug.LogError(string.Format("滚动区域诊断异常: {0}", arg));
				}
			}
		}

		// Token: 0x060000C0 RID: 192 RVA: 0x00008B50 File Offset: 0x00006D50
		public void ForceRefreshScrollArea()
		{
			try
			{
				bool flag = this._scrollArea != null && this._scrollArea.activeInHierarchy;
				if (flag)
				{
					bool flag2 = this._scrollRect != null && this._scrollRect.content != null;
					if (flag2)
					{
						LayoutRebuilder.ForceRebuildLayoutImmediate(this._scrollRect.content);
						Canvas.ForceUpdateCanvases();
						Debug.Log("强制刷新滚动区域完成");
						Debug.Log(string.Format("新Content尺寸: {0}", this._scrollRect.content.rect.size));
						bool flag3 = this._scrollRect.content.rect.height <= this._scrollRect.viewport.rect.height;
						if (flag3)
						{
							this._scrollRect.vertical = false;
							Debug.Log("内容不足，禁用垂直滚动");
						}
						else
						{
							this._scrollRect.vertical = true;
							Debug.Log(string.Format("启用垂直滚动，可滚动范围: {0}", this._scrollRect.content.rect.height - this._scrollRect.viewport.rect.height));
						}
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("强制刷新滚动区域异常: {0}", arg));
			}
		}

		// Token: 0x060000C1 RID: 193 RVA: 0x00008CE0 File Offset: 0x00006EE0
		public void UpdateContent(AnnouncementConfig config, int currentAnnouncementIndex = 0)
		{
			try
			{
				bool flag = !this._isInitialized;
				if (!flag)
				{
					Debug.Log(string.Format("ContentArea: 更新内容 {0}, 索引: {1}", config.ModId, currentAnnouncementIndex));
					this.UpdateInfoSection(config, currentAnnouncementIndex);
					string displayContentFromApiOrLocal = this.GetDisplayContentFromApiOrLocal(config, currentAnnouncementIndex);
					this._contentText.text = displayContentFromApiOrLocal;
					this._contentText.ForceMeshUpdate(false, false);
					Debug.Log(string.Format("文本首选高度: {0}, 实际尺寸: {1}", this._contentText.preferredHeight, this._contentText.rectTransform.rect.size));
					this._scrollRect.verticalNormalizedPosition = 1f;
					Debug.Log("重置滚动位置到顶部");
					base.StartCoroutine(this.ImmediateLayoutUpdate(this._scrollRect, this._contentText));
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("更新内容异常: {0}", arg));
			}
		}

		// Token: 0x060000C2 RID: 194 RVA: 0x00008DE8 File Offset: 0x00006FE8
		private void UpdateInfoSection(AnnouncementConfig config, int currentIndex = 0)
		{
			try
			{
				string text = "";
				bool flag = config.ApiAnnouncements != null && config.ApiAnnouncements.Count > currentIndex;
				if (flag)
				{
					ApiAnnouncementData apiAnnouncementData = config.ApiAnnouncements[currentIndex];
					bool flag2 = !string.IsNullOrEmpty(apiAnnouncementData.title);
					if (flag2)
					{
						text = text + "<size=18><b>" + apiAnnouncementData.title + "</b></size>\n\n";
					}
					bool flag3 = !string.IsNullOrEmpty(apiAnnouncementData.author);
					if (flag3)
					{
						text = text + "<size=16><b>作者:</b> " + apiAnnouncementData.author + "</size>\n";
					}
					bool flag4 = !string.IsNullOrEmpty(apiAnnouncementData.version);
					if (flag4)
					{
						text = string.Concat(new string[]
						{
							text,
							"<size=16><b>版本:</b>v",
							apiAnnouncementData.version,
							" (v",
							config.Version,
							")</size>\n"
						});
					}
				}
				bool flag5 = !string.IsNullOrEmpty(config.SteamWorkshopId);
				if (flag5)
				{
					text = text + "<size=16><b>创意工坊ID:</b> " + config.SteamWorkshopId + "</size>";
				}
				this._infoText.text = text;
				Debug.Log(string.Format("更新信息区成功，索引: {0}", currentIndex));
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("更新信息区异常: {0}", arg));
			}
		}

		// Token: 0x060000C3 RID: 195 RVA: 0x00008F5C File Offset: 0x0000715C
		private string GetDisplayContentFromApiOrLocal(AnnouncementConfig config, int announcementIndex = 0)
		{
			string result;
			try
			{
				bool flag = config.ApiAnnouncements != null && config.ApiAnnouncements.Count > 0;
				if (flag)
				{
					int index = Mathf.Clamp(announcementIndex, 0, config.ApiAnnouncements.Count - 1);
					ApiAnnouncementData apiAnnouncementData = config.ApiAnnouncements[index];
					bool flag2 = !string.IsNullOrEmpty(apiAnnouncementData.content_html);
					if (flag2)
					{
						string text = HtmlToTmpConverter.ConvertApiExample(apiAnnouncementData.content_html);
						bool flag3 = text.Contains("<link=");
						if (flag3)
						{
							Debug.Log("链接转换成功: " + text);
						}
						else
						{
							Debug.LogWarning("链接转换可能失败，结果: " + text);
						}
						return text;
					}
				}
				result = "暂无更新内容";
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("获取显示内容异常: {0}", arg));
				result = "内容加载失败";
			}
			return result;
		}

		// Token: 0x060000C4 RID: 196 RVA: 0x0000904C File Offset: 0x0000724C
		private IEnumerator ImmediateLayoutUpdate(ScrollRect scrollRect, TextMeshProUGUI text)
		{
			ContentArea.<ImmediateLayoutUpdate>d__19 <ImmediateLayoutUpdate>d__ = new ContentArea.<ImmediateLayoutUpdate>d__19(0);
			<ImmediateLayoutUpdate>d__.<>4__this = this;
			<ImmediateLayoutUpdate>d__.scrollRect = scrollRect;
			<ImmediateLayoutUpdate>d__.text = text;
			return <ImmediateLayoutUpdate>d__;
		}

		// Token: 0x060000C5 RID: 197 RVA: 0x0000906C File Offset: 0x0000726C
		public void Cleanup()
		{
			try
			{
				bool flag = this._contentText != null;
				if (flag)
				{
					EventTrigger component = this._contentText.GetComponent<EventTrigger>();
					bool flag2 = component != null;
					if (flag2)
					{
						Object.Destroy(component);
					}
					this._contentText.raycastTarget = false;
				}
				bool flag3 = this._scrollArea != null;
				if (flag3)
				{
					Object.Destroy(this._scrollArea);
				}
			}
			catch (Exception)
			{
			}
			this._scrollRect = null;
			this._contentText = null;
			this._infoText = null;
			this._scrollArea = null;
			this._isInitialized = false;
		}

		// Token: 0x04000043 RID: 67
		private ScrollRect _scrollRect;

		// Token: 0x04000044 RID: 68
		private TextMeshProUGUI _contentText;

		// Token: 0x04000045 RID: 69
		private TextMeshProUGUI _infoText;

		// Token: 0x04000046 RID: 70
		private GameObject _scrollArea;

		// Token: 0x04000047 RID: 71
		private bool _isInitialized = false;
	}
}
