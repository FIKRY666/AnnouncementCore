﻿using System;
using System.Collections.Generic;
using AnnouncementCore.Data;
using AnnouncementCore.Utility;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace AnnouncementCore.UI.Components
{
	// Token: 0x02000010 RID: 16
	public class SidebarList : MonoBehaviour
	{
		// Token: 0x0600010D RID: 269 RVA: 0x0000B3FF File Offset: 0x000095FF
		public void Initialize(AnnouncementState state, Action<string> onItemClick)
		{
			this._state = state;
			this._onItemClick = onItemClick;
			this.CreateScrollView();
			AnnouncementState.OnAnnouncementSelected += this.OnAnnouncementSelected;
			AnnouncementState.OnAnnouncementRead += this.OnAnnouncementRead;
		}

		// Token: 0x0600010E RID: 270 RVA: 0x0000B43C File Offset: 0x0000963C
		private void CreateScrollView()
		{
			base.gameObject.AddComponent<RectTransform>();
			this._scrollRect = base.gameObject.AddComponent<ScrollRect>();
			this._scrollRect.horizontal = false;
			this._scrollRect.vertical = true;
			this._scrollRect.movementType = 2;
			GameObject gameObject = new GameObject("Viewport", new Type[]
			{
				typeof(RectTransform),
				typeof(Mask),
				typeof(Image)
			});
			Image component = gameObject.GetComponent<Image>();
			component.sprite = ResourceLoader.LoadSprite("sidebar_bg");
			gameObject.transform.SetParent(base.transform, false);
			RectTransform component2 = gameObject.GetComponent<RectTransform>();
			component2.anchorMin = Vector2.zero;
			component2.anchorMax = Vector2.one;
			component2.sizeDelta = Vector2.zero;
			GameObject gameObject2 = new GameObject("Content", new Type[]
			{
				typeof(RectTransform),
				typeof(VerticalLayoutGroup),
				typeof(ContentSizeFitter)
			});
			gameObject2.transform.SetParent(gameObject.transform, false);
			this._content = gameObject2.GetComponent<RectTransform>();
			this._content.anchorMin = new Vector2(0f, 1f);
			this._content.anchorMax = new Vector2(1f, 1f);
			this._content.pivot = new Vector2(0.5f, 1f);
			this._content.sizeDelta = new Vector2(0f, 0f);
			VerticalLayoutGroup component3 = gameObject2.GetComponent<VerticalLayoutGroup>();
			component3.padding = new RectOffset(10, 10, 10, 10);
			component3.spacing = 8f;
			component3.childControlHeight = false;
			component3.childForceExpandHeight = false;
			ContentSizeFitter component4 = gameObject2.GetComponent<ContentSizeFitter>();
			component4.verticalFit = 2;
			this._scrollRect.viewport = component2;
			this._scrollRect.content = this._content;
		}

		// Token: 0x0600010F RID: 271 RVA: 0x0000B64C File Offset: 0x0000984C
		public void Refresh(List<AnnouncementConfig> configs)
		{
			foreach (SidebarItem sidebarItem in this._items.Values)
			{
				Object.Destroy(sidebarItem.gameObject);
			}
			this._items.Clear();
			foreach (AnnouncementConfig config in configs)
			{
				this.CreateItem(config);
			}
			LayoutRebuilder.ForceRebuildLayoutImmediate(this._content);
		}

		// Token: 0x06000110 RID: 272 RVA: 0x0000B708 File Offset: 0x00009908
		private void CreateItem(AnnouncementConfig config)
		{
			GameObject gameObject = new GameObject("SidebarItem_" + config.ModId, new Type[]
			{
				typeof(RectTransform)
			});
			gameObject.transform.SetParent(this._content, false);
			RectTransform component = gameObject.GetComponent<RectTransform>();
			component.sizeDelta = new Vector2(200f, 68f);
			LayoutElement layoutElement = gameObject.AddComponent<LayoutElement>();
			layoutElement.preferredHeight = 68f;
			layoutElement.minHeight = 68f;
			Image image = gameObject.AddComponent<Image>();
			image.type = 1;
			Button button = gameObject.AddComponent<Button>();
			SidebarItem sidebarItem = gameObject.AddComponent<SidebarItem>();
			sidebarItem.Background = image;
			sidebarItem.Button = button;
			this.CreateItemComponents(gameObject, sidebarItem);
			sidebarItem.Initialize(config, this._state, this._onItemClick);
			this._items[config.ModId] = sidebarItem;
		}

		// Token: 0x06000111 RID: 273 RVA: 0x0000B7F4 File Offset: 0x000099F4
		private void CreateItemComponents(GameObject parent, SidebarItem sidebarItem)
		{
			GameObject gameObject = new GameObject("ModName", new Type[]
			{
				typeof(RectTransform),
				typeof(TextMeshProUGUI)
			});
			gameObject.transform.SetParent(parent.transform, false);
			RectTransform component = gameObject.GetComponent<RectTransform>();
			component.anchorMin = new Vector2(0.05f, 0.5f);
			component.anchorMax = new Vector2(0.95f, 0.9f);
			component.offsetMin = Vector2.zero;
			component.offsetMax = Vector2.zero;
			sidebarItem.NameText = gameObject.GetComponent<TextMeshProUGUI>();
			sidebarItem.NameText.fontSize = 13f;
			sidebarItem.NameText.enableWordWrapping = true;
			GameObject gameObject2 = new GameObject("ModVersion", new Type[]
			{
				typeof(RectTransform),
				typeof(TextMeshProUGUI)
			});
			gameObject2.transform.SetParent(parent.transform, false);
			RectTransform component2 = gameObject2.GetComponent<RectTransform>();
			component2.anchorMin = new Vector2(0.05f, 0.1f);
			component2.anchorMax = new Vector2(0.95f, 0.5f);
			component2.offsetMin = Vector2.zero;
			component2.offsetMax = Vector2.zero;
			sidebarItem.VersionText = gameObject2.GetComponent<TextMeshProUGUI>();
			sidebarItem.VersionText.fontSize = 13f;
			GameObject gameObject3 = new GameObject("UnreadBadge", new Type[]
			{
				typeof(RectTransform),
				typeof(Image)
			});
			gameObject3.transform.SetParent(parent.transform, false);
			RectTransform component3 = gameObject3.GetComponent<RectTransform>();
			component3.anchorMin = new Vector2(1f, 1f);
			component3.anchorMax = new Vector2(1f, 1f);
			component3.pivot = new Vector2(1f, 1f);
			component3.anchoredPosition = new Vector2(-15f, -15f);
			component3.sizeDelta = new Vector2(8f, 8f);
			gameObject3.GetComponent<Image>().color = new Color(1f, 0.9176471f, 0.5803922f, 1f);
			sidebarItem.UnreadBadge = gameObject3;
		}

		// Token: 0x06000112 RID: 274 RVA: 0x0000BA48 File Offset: 0x00009C48
		private void OnAnnouncementSelected(string modId)
		{
			foreach (KeyValuePair<string, SidebarItem> keyValuePair in this._items)
			{
				keyValuePair.Value.SetSelected(keyValuePair.Key == modId);
			}
		}

		// Token: 0x06000113 RID: 275 RVA: 0x0000BAB4 File Offset: 0x00009CB4
		private void OnAnnouncementRead(string modId)
		{
			SidebarItem sidebarItem;
			bool flag = this._items.TryGetValue(modId, out sidebarItem);
			if (flag)
			{
				sidebarItem.UpdateReadStatus();
			}
		}

		// Token: 0x06000114 RID: 276 RVA: 0x0000BAE0 File Offset: 0x00009CE0
		public void Cleanup()
		{
			AnnouncementState.OnAnnouncementSelected -= this.OnAnnouncementSelected;
			AnnouncementState.OnAnnouncementRead -= this.OnAnnouncementRead;
			foreach (SidebarItem sidebarItem in this._items.Values)
			{
				Object.Destroy(sidebarItem.gameObject);
			}
			this._items.Clear();
		}

		// Token: 0x04000085 RID: 133
		private ScrollRect _scrollRect;

		// Token: 0x04000086 RID: 134
		private RectTransform _content;

		// Token: 0x04000087 RID: 135
		private AnnouncementState _state;

		// Token: 0x04000088 RID: 136
		private Dictionary<string, SidebarItem> _items = new Dictionary<string, SidebarItem>();

		// Token: 0x04000089 RID: 137
		private Action<string> _onItemClick;
	}
}
