﻿using System;
using System.Collections;
using System.Collections.Generic;
using AnnouncementCore.Data;
using AnnouncementCore.UI.Effects;
using AnnouncementCore.Utility;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace AnnouncementCore.UI.Components
{
	// Token: 0x02000011 RID: 17
	public class SummaryNotificationPanel : MonoBehaviour
	{
		// Token: 0x06000116 RID: 278 RVA: 0x0000BB88 File Offset: 0x00009D88
		public void Initialize(AnnouncementState state, Transform uiRoot, Action<bool> onVisibilityChanged)
		{
			try
			{
				this._state = state;
				this._onVisibilityChanged = onVisibilityChanged;
				this.CreatePanel(uiRoot);
				this.CreateUIElements();
				this.UpdateContent();
				this.UpdateButtonIcon();
				Debug.Log("SummaryNotificationPanel: 初始化完成");
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("SummaryNotificationPanel 初始化失败: {0}", arg));
			}
		}

		// Token: 0x06000117 RID: 279 RVA: 0x0000BBF8 File Offset: 0x00009DF8
		private void CreatePanel(Transform uiRoot)
		{
			this._panelObject = new GameObject("SummaryNotificationPanel");
			this._panelObject.transform.SetParent(uiRoot, false);
			this._panelRect = this._panelObject.AddComponent<RectTransform>();
			this._panelRect.anchorMin = new Vector2(1f, 1f);
			this._panelRect.anchorMax = new Vector2(1f, 1f);
			this._panelRect.pivot = new Vector2(1f, 1f);
			this._panelRect.anchoredPosition = new Vector2(-20f, -100f);
			this._panelRect.sizeDelta = new Vector2(230f, 70f);
			this._canvasGroup = this._panelObject.AddComponent<CanvasGroup>();
			this._canvasGroup.alpha = 1f;
			this._canvasGroup.interactable = true;
			this._canvasGroup.blocksRaycasts = true;
			Image image = this._panelObject.AddComponent<Image>();
			image.sprite = this.LoadSprite("update_panel_bg");
			bool flag = image.sprite == null;
			if (flag)
			{
				image.color = new Color(0.15f, 0.15f, 0.2f, 0.95f);
			}
			image.type = 1;
		}

		// Token: 0x06000118 RID: 280 RVA: 0x0000BD55 File Offset: 0x00009F55
		private void CreateUIElements()
		{
			this.CreateTitleText();
			this.CreateContentText();
			this.CreateToggleButton();
		}

		// Token: 0x06000119 RID: 281 RVA: 0x0000BD70 File Offset: 0x00009F70
		private void CreateTitleText()
		{
			GameObject gameObject = new GameObject("Title");
			RectTransform rectTransform = gameObject.AddComponent<RectTransform>();
			rectTransform.SetParent(this._panelRect, false);
			rectTransform.anchorMin = new Vector2(0f, 1f);
			rectTransform.anchorMax = new Vector2(0f, 1f);
			rectTransform.pivot = new Vector2(0f, 1f);
			rectTransform.anchoredPosition = new Vector2(17f, -7f);
			rectTransform.sizeDelta = new Vector2(100f, 25f);
			this._titleText = gameObject.AddComponent<TextMeshProUGUI>();
			this._titleText.text = "更新通知";
			this._titleText.fontSize = 19f;
			this._titleText.color = Color.white;
			this._titleText.fontStyle = 1;
			this._titleText.alignment = 513;
		}

		// Token: 0x0600011A RID: 282 RVA: 0x0000BE6C File Offset: 0x0000A06C
		private void CreateContentText()
		{
			GameObject gameObject = new GameObject("Content");
			RectTransform rectTransform = gameObject.AddComponent<RectTransform>();
			rectTransform.SetParent(this._panelRect, false);
			rectTransform.anchorMin = new Vector2(0f, 1f);
			rectTransform.anchorMax = new Vector2(0f, 1f);
			rectTransform.pivot = new Vector2(0f, 1f);
			rectTransform.anchoredPosition = new Vector2(17f, -40f);
			rectTransform.sizeDelta = new Vector2(130f, 25f);
			this._contentText = gameObject.AddComponent<TextMeshProUGUI>();
			this._contentText.text = "";
			this._contentText.fontSize = 16f;
			this._contentText.color = new Color(1f, 0.92f, 0.58f, 1f);
			this._contentText.alignment = 513;
		}

		// Token: 0x0600011B RID: 283 RVA: 0x0000BF6C File Offset: 0x0000A16C
		private void CreateToggleButton()
		{
			GameObject gameObject = new GameObject("ToggleButton");
			RectTransform rectTransform = gameObject.AddComponent<RectTransform>();
			rectTransform.SetParent(this._panelRect, false);
			rectTransform.anchorMin = new Vector2(1f, 1f);
			rectTransform.anchorMax = new Vector2(1f, 1f);
			rectTransform.pivot = new Vector2(1f, 1f);
			rectTransform.anchoredPosition = new Vector2(-10f, -10f);
			rectTransform.sizeDelta = new Vector2(50f, 22f);
			this._toggleButtonImage = gameObject.AddComponent<Image>();
			this._toggleButtonImage.sprite = this.LoadSprite("panel_collapse");
			bool flag = this._toggleButtonImage.sprite == null;
			if (flag)
			{
				this._toggleButtonImage.color = new Color(0.2f, 0.6f, 0.9f, 1f);
			}
			this._toggleButtonImage.type = 1;
			this._toggleButton = gameObject.AddComponent<Button>();
			this._toggleButton.onClick.AddListener(new UnityAction(this.OnToggleButtonClicked));
			ConsolidatedHoverEffect consolidatedHoverEffect = gameObject.AddComponent<ConsolidatedHoverEffect>();
			consolidatedHoverEffect.ButtonImage = this._toggleButtonImage;
			consolidatedHoverEffect.ButtonComponent = this._toggleButton;
			consolidatedHoverEffect.SetEffectType(ConsolidatedHoverEffect.EffectType.PopupButton);
		}

		// Token: 0x0600011C RID: 284 RVA: 0x0000C0C8 File Offset: 0x0000A2C8
		private void OnToggleButtonClicked()
		{
			AudioUtility.PlayClickSound();
			this._arePopupsVisible = !this._arePopupsVisible;
			this.UpdateButtonIcon();
			Action<bool> onVisibilityChanged = this._onVisibilityChanged;
			if (onVisibilityChanged != null)
			{
				onVisibilityChanged(this._arePopupsVisible);
			}
			base.StartCoroutine(this.PlayButtonClickAnimation(this._toggleButtonImage.transform));
			Debug.Log("切换弹窗显示状态: " + (this._arePopupsVisible ? "显示" : "隐藏"));
		}

		// Token: 0x0600011D RID: 285 RVA: 0x0000C146 File Offset: 0x0000A346
		private IEnumerator PlayButtonClickAnimation(Transform buttonTransform)
		{
			SummaryNotificationPanel.<PlayButtonClickAnimation>d__21 <PlayButtonClickAnimation>d__ = new SummaryNotificationPanel.<PlayButtonClickAnimation>d__21(0);
			<PlayButtonClickAnimation>d__.<>4__this = this;
			<PlayButtonClickAnimation>d__.buttonTransform = buttonTransform;
			return <PlayButtonClickAnimation>d__;
		}

		// Token: 0x0600011E RID: 286 RVA: 0x0000C15C File Offset: 0x0000A35C
		private float ElasticEaseOut(float t)
		{
			bool flag = t >= 1f;
			float result;
			if (flag)
			{
				result = 1f;
			}
			else
			{
				float num = 0.3f;
				float num2 = num / 4f;
				result = Mathf.Pow(2f, -10f * t) * Mathf.Sin((t - num2) * 6.2831855f / num) + 1f;
			}
			return result;
		}

		// Token: 0x0600011F RID: 287 RVA: 0x0000C1BC File Offset: 0x0000A3BC
		public void UpdateContent()
		{
			try
			{
				bool flag = this._state == null;
				if (!flag)
				{
					bool allRead = this._state.AllRead;
					if (allRead)
					{
						this.Hide();
					}
					else
					{
						this.Show();
						List<AnnouncementConfig> allConfigsSorted = this._state.GetAllConfigsSorted();
						int count = allConfigsSorted.Count;
						int num = 0;
						int num2 = 0;
						foreach (AnnouncementConfig announcementConfig in allConfigsSorted)
						{
							bool hasPermanentUpdate = announcementConfig.HasPermanentUpdate;
							if (hasPermanentUpdate)
							{
								num++;
							}
							else
							{
								bool flag2 = !this._state.IsRead(announcementConfig.ModId);
								if (flag2)
								{
									num2++;
								}
							}
						}
						bool flag3 = count == 0;
						if (flag3)
						{
							this._contentText.text = "暂无更新";
							this._contentText.color = new Color(0.7f, 0.7f, 0.7f, 1f);
						}
						else
						{
							string text = "";
							bool flag4 = num > 0;
							if (flag4)
							{
								text += string.Format("版本更新:{0}   ", num);
								bool flag5 = num2 > 0;
								if (flag5)
								{
									text += " ";
								}
							}
							bool flag6 = num2 > 0;
							if (flag6)
							{
								text += string.Format("未读公告:{0}", num2);
							}
							this._contentText.text = text;
							this._contentText.color = new Color(1f, 0.92f, 0.58f, 1f);
							bool flag7 = this._toggleButtonImage != null;
							if (flag7)
							{
								this._toggleButton.interactable = true;
								this.UpdateButtonIcon();
							}
						}
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("更新摘要面板内容失败: {0}", arg));
			}
		}

		// Token: 0x06000120 RID: 288 RVA: 0x0000C3E0 File Offset: 0x0000A5E0
		private void UpdateButtonIcon()
		{
			bool flag = this._toggleButtonImage == null;
			if (!flag)
			{
				string spriteName = this._arePopupsVisible ? "panel_collapse" : "panel_expand";
				Sprite sprite = this.LoadSprite(spriteName);
				bool flag2 = sprite != null;
				if (flag2)
				{
					this._toggleButtonImage.sprite = sprite;
				}
				else
				{
					this._toggleButtonImage.color = (this._arePopupsVisible ? new Color(0.9f, 0.3f, 0.3f, 1f) : new Color(0.3f, 0.9f, 0.3f, 1f));
				}
			}
		}

		// Token: 0x06000121 RID: 289 RVA: 0x0000C488 File Offset: 0x0000A688
		public void Show()
		{
			bool flag = this._panelObject == null;
			if (!flag)
			{
				this._panelObject.SetActive(true);
				this._canvasGroup.alpha = 1f;
			}
		}

		// Token: 0x06000122 RID: 290 RVA: 0x0000C4C8 File Offset: 0x0000A6C8
		public void Hide()
		{
			bool flag = this._panelObject == null;
			if (!flag)
			{
				this._canvasGroup.alpha = 0f;
				this._panelObject.SetActive(false);
			}
		}

		// Token: 0x06000123 RID: 291 RVA: 0x0000C508 File Offset: 0x0000A708
		private Sprite LoadSprite(string spriteName)
		{
			Sprite result;
			try
			{
				Sprite sprite = ResourceLoader.LoadSprite(spriteName);
				bool flag = sprite == null;
				if (flag)
				{
					if (!(spriteName == "summary_panel_bg"))
					{
						if (!(spriteName == "summary_hide"))
						{
							if (spriteName == "summary_show")
							{
								sprite = ResourceLoader.LoadSprite("panel_expand");
							}
						}
						else
						{
							sprite = ResourceLoader.LoadSprite("panel_collapse");
						}
					}
					else
					{
						sprite = ResourceLoader.LoadSprite("update_panel_bg");
					}
				}
				bool flag2 = sprite == null && spriteName == "summary_panel_bg";
				if (flag2)
				{
					sprite = ResourceLoader.LoadSprite("panel_empty");
				}
				result = sprite;
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000124 RID: 292 RVA: 0x0000C5C8 File Offset: 0x0000A7C8
		public void Cleanup()
		{
			try
			{
				bool flag = this._panelObject != null;
				if (flag)
				{
					Object.Destroy(this._panelObject);
					this._panelObject = null;
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("SummaryNotificationPanel 清理失败: {0}", arg));
			}
			this._titleText = null;
			this._contentText = null;
			this._toggleButton = null;
			this._toggleButtonImage = null;
			this._state = null;
			this._onVisibilityChanged = null;
		}

		// Token: 0x0400008A RID: 138
		private const float PANEL_WIDTH = 230f;

		// Token: 0x0400008B RID: 139
		private const float PANEL_HEIGHT = 70f;

		// Token: 0x0400008C RID: 140
		private const float RIGHT_MARGIN = 20f;

		// Token: 0x0400008D RID: 141
		private const float TOP_MARGIN = -100f;

		// Token: 0x0400008E RID: 142
		private GameObject _panelObject;

		// Token: 0x0400008F RID: 143
		private RectTransform _panelRect;

		// Token: 0x04000090 RID: 144
		private CanvasGroup _canvasGroup;

		// Token: 0x04000091 RID: 145
		private AnnouncementState _state;

		// Token: 0x04000092 RID: 146
		private TextMeshProUGUI _titleText;

		// Token: 0x04000093 RID: 147
		private TextMeshProUGUI _contentText;

		// Token: 0x04000094 RID: 148
		private Button _toggleButton;

		// Token: 0x04000095 RID: 149
		private Image _toggleButtonImage;

		// Token: 0x04000096 RID: 150
		private bool _arePopupsVisible = true;

		// Token: 0x04000097 RID: 151
		private Action<bool> _onVisibilityChanged;
	}
}
