﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using AnnouncementCore.Data;
using AnnouncementCore.UI.Effects;
using AnnouncementCore.Utility;
using Steamworks;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace AnnouncementCore.UI.Components
{
	// Token: 0x02000012 RID: 18
	public class UpdateNotificationPopup : MonoBehaviour
	{
		// Token: 0x1700000E RID: 14
		// (get) Token: 0x06000126 RID: 294 RVA: 0x0000C660 File Offset: 0x0000A860
		public string ModId
		{
			get
			{
				AnnouncementConfig config = this._config;
				return (config != null) ? config.ModId : null;
			}
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x06000127 RID: 295 RVA: 0x0000C674 File Offset: 0x0000A874
		public bool IsPermanentUpdate
		{
			get
			{
				AnnouncementConfig config = this._config;
				return config != null && config.HasPermanentUpdate;
			}
		}

		// Token: 0x06000128 RID: 296 RVA: 0x0000C688 File Offset: 0x0000A888
		public void Initialize(AnnouncementConfig config, AnnouncementState state, Transform uiRoot, UIAnimator animator, int index = 0)
		{
			try
			{
				this._popupType = (config.HasPermanentUpdate ? UpdateNotificationPopup.PopupType.PermanentUpdate : UpdateNotificationPopup.PopupType.UnreadAnnouncement);
				bool flag = !state.ShouldShowPopup(config.ModId);
				if (flag)
				{
					Debug.Log(string.Format("跳过弹窗 - 不满足显示条件: {0}, 类型: {1}", config.ModId, this._popupType));
					Object.Destroy(base.gameObject);
				}
				else
				{
					this._config = config;
					this._state = state;
					this._uiRoot = uiRoot;
					this._animator = animator;
					this._popupIndex = index;
					this.CreatePopup();
					this._isInitialized = true;
					UpdateNotificationPopup._allPopups.Add(this);
					AnnouncementState.OnAnnouncementRead += this.OnAnnouncementRead;
					AnnouncementState.OnPopupShouldHide += this.OnPopupShouldHide;
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("UpdateNotificationPopup初始化失败: {0}", arg));
			}
		}

		// Token: 0x06000129 RID: 297 RVA: 0x0000C778 File Offset: 0x0000A978
		private void OnAnnouncementRead(string modId)
		{
			try
			{
				bool flag = this._config == null || this._config.ModId != modId;
				if (!flag)
				{
					bool flag2 = this._popupType == UpdateNotificationPopup.PopupType.UnreadAnnouncement;
					if (flag2)
					{
						this.HideWithAnimation();
					}
					else
					{
						bool flag3 = this._popupType == UpdateNotificationPopup.PopupType.PermanentUpdate;
						if (flag3)
						{
						}
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("处理已读事件失败: {0}", arg));
			}
		}

		// Token: 0x0600012A RID: 298 RVA: 0x0000C7FC File Offset: 0x0000A9FC
		private void HideWithAnimation()
		{
			bool flag = !this._isInitialized || this._popupObject == null;
			if (!flag)
			{
				try
				{
					this._canvasGroup.interactable = false;
					this._canvasGroup.blocksRaycasts = false;
					this._isVisible = false;
					bool flag2 = this._animator != null;
					if (flag2)
					{
						base.StartCoroutine(this._animator.PanelHideAnimation(this._popupObject.transform, this._canvasGroup, delegate
						{
							this.OnHideComplete();
						}));
					}
					else
					{
						base.StartCoroutine(this.SimpleHideAnimation());
					}
				}
				catch (Exception arg)
				{
					Debug.LogError(string.Format("隐藏弹窗失败: {0}", arg));
				}
			}
		}

		// Token: 0x0600012B RID: 299 RVA: 0x0000C8C8 File Offset: 0x0000AAC8
		private IEnumerator SimpleHideAnimation()
		{
			UpdateNotificationPopup.<SimpleHideAnimation>d__21 <SimpleHideAnimation>d__ = new UpdateNotificationPopup.<SimpleHideAnimation>d__21(0);
			<SimpleHideAnimation>d__.<>4__this = this;
			return <SimpleHideAnimation>d__;
		}

		// Token: 0x0600012C RID: 300 RVA: 0x0000C8D7 File Offset: 0x0000AAD7
		private float QuadEaseOut(float t)
		{
			return 1f - (1f - t) * (1f - t);
		}

		// Token: 0x0600012D RID: 301 RVA: 0x0000C8F0 File Offset: 0x0000AAF0
		private void OnPopupShouldHide(string modId)
		{
			try
			{
				bool flag = this._config == null || this._config.ModId != modId;
				if (!flag)
				{
					bool flag2 = this._popupType == UpdateNotificationPopup.PopupType.UnreadAnnouncement;
					if (flag2)
					{
						Debug.Log("收到隐藏指令，隐藏未读公告弹窗: " + modId);
						AnnouncementState state = this._state;
						if (state != null)
						{
							state.MarkPopupAsHidden(modId);
						}
						this.HideWithAnimation();
					}
					else
					{
						bool flag3 = this._popupType == UpdateNotificationPopup.PopupType.PermanentUpdate;
						if (flag3)
						{
							Debug.Log("版本更新弹窗忽略隐藏请求: " + modId);
						}
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("处理弹窗隐藏事件失败: {0}", arg));
			}
		}

		// Token: 0x0600012E RID: 302 RVA: 0x0000C9A8 File Offset: 0x0000ABA8
		private bool ShouldShowPopup(AnnouncementConfig config, AnnouncementState state, UpdateNotificationPopup.PopupType popupType)
		{
			bool result;
			try
			{
				bool flag = config == null || state == null;
				if (flag)
				{
					Debug.LogWarning("ShouldShowPopup: 配置或状态为空");
					result = false;
				}
				else
				{
					if (popupType != UpdateNotificationPopup.PopupType.PermanentUpdate)
					{
						if (popupType == UpdateNotificationPopup.PopupType.UnreadAnnouncement)
						{
							bool flag2 = !config.HasPermanentUpdate && !state.IsRead(config.ModId);
							if (flag2)
							{
								Debug.Log(string.Concat(new string[]
								{
									"未读公告弹窗显示: ",
									config.ModId,
									" (本地==云端: ",
									config.Version,
									")"
								}));
								return true;
							}
						}
					}
					else
					{
						bool flag3 = config.HasPermanentUpdate && !state.IsRead(config.ModId);
						if (flag3)
						{
							Debug.Log(string.Concat(new string[]
							{
								"版本更新弹窗显示: ",
								config.ModId,
								" (本地: ",
								config.Version,
								", 云端: ",
								config.GetLatestCloudVersion(),
								")"
							}));
							return true;
						}
					}
					Debug.Log(string.Format("已读或不符合条件，跳过弹窗: {0}, 类型: {1}", config.ModId, popupType));
					result = false;
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("ShouldShowPopup 异常: {0}", arg));
				result = false;
			}
			return result;
		}

		// Token: 0x0600012F RID: 303 RVA: 0x0000CB18 File Offset: 0x0000AD18
		private void CreatePopup()
		{
			try
			{
				this.CreatePopupContainer();
				this.CreatePopupBackground();
				this.CreateCenterContainer();
				this.CreateUIElements();
				this._popupObject.SetActive(false);
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("创建弹窗失败: {0}", arg));
				this.CleanupTempObjects();
			}
		}

		// Token: 0x06000130 RID: 304 RVA: 0x0000CB80 File Offset: 0x0000AD80
		private void CreatePopupContainer()
		{
			this._popupObject = new GameObject("UpdatePopup_" + this._config.ModId);
			this._popupObject.transform.SetParent(this._uiRoot, false);
			RectTransform rectTransform = this._popupObject.AddComponent<RectTransform>();
			rectTransform.anchorMin = new Vector2(1f, 1f);
			rectTransform.anchorMax = new Vector2(1f, 1f);
			rectTransform.pivot = new Vector2(1f, 1f);
			float num = -180f;
			float y = num - (float)this._popupIndex * 140f;
			rectTransform.anchoredPosition = new Vector2(-20f, y);
			rectTransform.sizeDelta = new Vector2(375f, 130f);
			this._canvasGroup = this._popupObject.AddComponent<CanvasGroup>();
			this._canvasGroup.alpha = 0f;
			this._canvasGroup.interactable = false;
			this._canvasGroup.blocksRaycasts = false;
		}

		// Token: 0x06000131 RID: 305 RVA: 0x0000CC90 File Offset: 0x0000AE90
		private void CreatePopupBackground()
		{
			Image image = this._popupObject.AddComponent<Image>();
			image.sprite = this.LoadSprite("update_popup_background");
			bool flag = image.sprite == null;
			if (flag)
			{
				image.color = new Color(0.15f, 0.15f, 0.2f, 0.95f);
			}
			else
			{
				image.type = 1;
			}
		}

		// Token: 0x06000132 RID: 306 RVA: 0x0000CCFC File Offset: 0x0000AEFC
		private void CreateCenterContainer()
		{
			GameObject gameObject = new GameObject("CenterContainer");
			RectTransform rectTransform = gameObject.AddComponent<RectTransform>();
			rectTransform.SetParent(this._popupObject.transform, false);
			rectTransform.anchorMin = new Vector2(0.5f, 0.5f);
			rectTransform.anchorMax = new Vector2(0.5f, 0.5f);
			rectTransform.pivot = new Vector2(0.5f, 0.5f);
			rectTransform.anchoredPosition = Vector2.zero;
			rectTransform.sizeDelta = new Vector2(375f, 130f);
		}

		// Token: 0x06000133 RID: 307 RVA: 0x0000CD94 File Offset: 0x0000AF94
		private void CreateUIElements()
		{
			Transform parent = this._popupObject.transform.Find("CenterContainer");
			this.CreateTitleText(parent, new Vector2(-62f, 15f), new Vector2(215f, 70f));
			this.CreateVersionText(parent, new Vector2(-53f, -35f), new Vector2(240f, 28f));
			this.CreateAnnouncementButton(parent, new Vector2(135.5f, 31f), new Vector2(80f, 44f));
			bool flag = !string.IsNullOrEmpty(this._config.SteamWorkshopId);
			if (flag)
			{
				this.CreateSteamButton(parent, new Vector2(135.5f, -28f), new Vector2(80f, 54f));
			}
		}

		// Token: 0x06000134 RID: 308 RVA: 0x0000CE6C File Offset: 0x0000B06C
		private void CreateTitleText(Transform parent, Vector2 position, Vector2 size)
		{
			GameObject gameObject = new GameObject("Title");
			RectTransform rectTransform = gameObject.AddComponent<RectTransform>();
			rectTransform.SetParent(parent, false);
			rectTransform.anchorMin = new Vector2(0.5f, 0.5f);
			rectTransform.anchorMax = new Vector2(0.5f, 0.5f);
			rectTransform.pivot = new Vector2(0.5f, 0.5f);
			rectTransform.anchoredPosition = position;
			rectTransform.sizeDelta = size;
			TextMeshProUGUI textMeshProUGUI = gameObject.AddComponent<TextMeshProUGUI>();
			textMeshProUGUI.text = this.FormatTitleForTwoLines(this._config.DisplayName);
			textMeshProUGUI.fontSize = 20f;
			textMeshProUGUI.fontStyle = 1;
			textMeshProUGUI.alignment = 257;
			textMeshProUGUI.color = Color.white;
			textMeshProUGUI.enableWordWrapping = true;
			textMeshProUGUI.lineSpacing = -15f;
		}

		// Token: 0x06000135 RID: 309 RVA: 0x0000CF48 File Offset: 0x0000B148
		private string FormatTitleForTwoLines(string originalTitle)
		{
			bool flag = string.IsNullOrEmpty(originalTitle);
			string result;
			if (flag)
			{
				result = "";
			}
			else
			{
				string text = originalTitle.Trim();
				bool flag2 = text.Length <= 16;
				if (flag2)
				{
					result = text;
				}
				else
				{
					int num = Math.Min(15, text.Length);
					string str = text.Substring(0, num);
					string text2 = text.Substring(num);
					bool flag3 = text2.Length > 15;
					if (flag3)
					{
						text2 = text2.Substring(0, 15) + "...";
					}
					result = str + "\n" + text2;
				}
			}
			return result;
		}

		// Token: 0x06000136 RID: 310 RVA: 0x0000CFE4 File Offset: 0x0000B1E4
		private void CreateVersionText(Transform parent, Vector2 position, Vector2 size)
		{
			GameObject gameObject = new GameObject("Version");
			RectTransform rectTransform = gameObject.AddComponent<RectTransform>();
			rectTransform.SetParent(parent, false);
			rectTransform.anchorMin = new Vector2(0.5f, 0.5f);
			rectTransform.anchorMax = new Vector2(0.5f, 0.5f);
			rectTransform.pivot = new Vector2(0.5f, 0.5f);
			rectTransform.anchoredPosition = position;
			rectTransform.sizeDelta = size;
			TextMeshProUGUI textMeshProUGUI = gameObject.AddComponent<TextMeshProUGUI>();
			string text = (!this._state.IsRead(this._config.ModId)) ? "#FFEA94" : "#FFFFFF";
			textMeshProUGUI.text = string.Concat(new string[]
			{
				"<color=",
				text,
				">NEW: ",
				this._config.LatestVersion,
				"</color>\n当前: v",
				this._config.Version
			});
			textMeshProUGUI.fontSize = 16f;
			textMeshProUGUI.fontStyle = 1;
			textMeshProUGUI.alignment = 513;
			textMeshProUGUI.color = Color.white;
			textMeshProUGUI.enableWordWrapping = true;
		}

		// Token: 0x06000137 RID: 311 RVA: 0x0000D110 File Offset: 0x0000B310
		private void CreateAnnouncementButton(Transform parent, Vector2 position, Vector2 size)
		{
			Button button = this.CreatePopupButton(parent, position, size, "AnnouncementButton", "update_popup_announcement_bg", new Color(0.2f, 0.4f, 0.8f, 1f));
			button.onClick.AddListener(delegate()
			{
				this.OnAnnouncementButtonClicked();
			});
		}

		// Token: 0x06000138 RID: 312 RVA: 0x0000D164 File Offset: 0x0000B364
		private void CreateSteamButton(Transform parent, Vector2 position, Vector2 size)
		{
			Button button = this.CreatePopupButton(parent, position, size, "SteamButton", "update_popup_steam_bg", new Color(0.1f, 0.5f, 0.2f, 1f));
			button.onClick.AddListener(delegate()
			{
				this.OnSteamButtonClicked();
			});
		}

		// Token: 0x06000139 RID: 313 RVA: 0x0000D1B8 File Offset: 0x0000B3B8
		private Button CreatePopupButton(Transform parent, Vector2 position, Vector2 size, string name, string spriteName, Color fallbackColor)
		{
			GameObject gameObject = new GameObject(name);
			RectTransform rectTransform = gameObject.AddComponent<RectTransform>();
			rectTransform.SetParent(parent, false);
			rectTransform.anchorMin = new Vector2(0.5f, 0.5f);
			rectTransform.anchorMax = new Vector2(0.5f, 0.5f);
			rectTransform.pivot = new Vector2(0.5f, 0.5f);
			rectTransform.anchoredPosition = position;
			rectTransform.sizeDelta = size;
			Image image = gameObject.AddComponent<Image>();
			image.sprite = this.LoadSprite(spriteName);
			bool flag = image.sprite == null;
			if (flag)
			{
				image.color = fallbackColor;
			}
			image.type = 1;
			Button button = gameObject.AddComponent<Button>();
			button.onClick.AddListener(delegate()
			{
				this.OnPopupButtonClicked(button.transform);
			});
			ConsolidatedHoverEffect consolidatedHoverEffect = gameObject.AddComponent<ConsolidatedHoverEffect>();
			consolidatedHoverEffect.ButtonImage = image;
			consolidatedHoverEffect.ButtonComponent = button;
			consolidatedHoverEffect.SetEffectType(ConsolidatedHoverEffect.EffectType.PopupButton);
			return button;
		}

		// Token: 0x0600013A RID: 314 RVA: 0x0000D2D3 File Offset: 0x0000B4D3
		private void OnPopupButtonClicked(Transform buttonTransform)
		{
			AudioUtility.PlayClickSound();
			base.StartCoroutine(this.PlayButtonClickAnimation(buttonTransform));
		}

		// Token: 0x0600013B RID: 315 RVA: 0x0000D2EC File Offset: 0x0000B4EC
		private void OnAnnouncementButtonClicked()
		{
			try
			{
				Debug.Log("查看更新公告: " + this._config.ModId);
				UIManager componentInParent = base.GetComponentInParent<UIManager>();
				bool flag = componentInParent != null;
				if (flag)
				{
					componentInParent.OpenAnnouncementFromPopup(this._config.ModId);
				}
				else
				{
					AnnouncementState state = this._state;
					if (state != null)
					{
						state.SelectAnnouncement(this._config.ModId, true);
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("处理公告按钮点击失败: {0}", arg));
			}
		}

		// Token: 0x0600013C RID: 316 RVA: 0x0000D388 File Offset: 0x0000B588
		private void OnSteamButtonClicked()
		{
			try
			{
				bool flag = string.IsNullOrEmpty(this._config.SteamWorkshopUrl);
				if (!flag)
				{
					Debug.Log("打开Steam页面: " + this._config.SteamWorkshopUrl);
					bool flag2 = this.IsSteamRunning();
					if (flag2)
					{
						SteamFriends.ActivateGameOverlayToWebPage(this._config.SteamWorkshopUrl, 0);
					}
					else
					{
						Application.OpenURL(this._config.SteamWorkshopUrl);
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("打开Steam页面失败: {0}", arg));
				bool flag3 = !string.IsNullOrEmpty(this._config.SteamWorkshopUrl);
				if (flag3)
				{
					Application.OpenURL(this._config.SteamWorkshopUrl);
				}
			}
		}

		// Token: 0x0600013D RID: 317 RVA: 0x0000D454 File Offset: 0x0000B654
		private IEnumerator PlayButtonClickAnimation(Transform buttonTransform)
		{
			UpdateNotificationPopup.<PlayButtonClickAnimation>d__39 <PlayButtonClickAnimation>d__ = new UpdateNotificationPopup.<PlayButtonClickAnimation>d__39(0);
			<PlayButtonClickAnimation>d__.<>4__this = this;
			<PlayButtonClickAnimation>d__.buttonTransform = buttonTransform;
			return <PlayButtonClickAnimation>d__;
		}

		// Token: 0x0600013E RID: 318 RVA: 0x0000D46C File Offset: 0x0000B66C
		private float ElasticEaseOut(float t)
		{
			bool flag = t >= 1f;
			float result;
			if (flag)
			{
				result = 1f;
			}
			else
			{
				float num = 0.3f;
				float num2 = num / 4f;
				result = Mathf.Pow(2f, -10f * t) * Mathf.Sin((t - num2) * 6.2831855f / num) + 1f;
			}
			return result;
		}

		// Token: 0x0600013F RID: 319 RVA: 0x0000D4CC File Offset: 0x0000B6CC
		public void Show()
		{
			bool flag = !this._isInitialized || this._popupObject == null;
			if (!flag)
			{
				try
				{
					this._popupObject.SetActive(true);
					this._canvasGroup.interactable = true;
					this._canvasGroup.blocksRaycasts = true;
					bool flag2 = this._animator != null;
					if (flag2)
					{
						base.StartCoroutine(this._animator.PanelElasticShowAnimation(this._popupObject.transform, this._canvasGroup, delegate
						{
							this._isVisible = true;
						}));
					}
					else
					{
						this._canvasGroup.alpha = 1f;
						this._isVisible = true;
					}
				}
				catch (Exception arg)
				{
					Debug.LogError(string.Format("显示弹窗失败: {0}", arg));
				}
			}
		}

		// Token: 0x06000140 RID: 320 RVA: 0x0000D5A8 File Offset: 0x0000B7A8
		public void Hide()
		{
			bool flag = !this._isInitialized || this._popupObject == null;
			if (!flag)
			{
				try
				{
					this._canvasGroup.interactable = false;
					this._canvasGroup.blocksRaycasts = false;
					this._isVisible = false;
					bool flag2 = this._animator != null;
					if (flag2)
					{
						base.StartCoroutine(this._animator.PanelHideAnimation(this._popupObject.transform, this._canvasGroup, delegate
						{
							this.OnHideComplete();
						}));
					}
					else
					{
						this._canvasGroup.alpha = 0f;
						this.OnHideComplete();
					}
				}
				catch (Exception arg)
				{
					Debug.LogError(string.Format("隐藏弹窗失败: {0}", arg));
				}
			}
		}

		// Token: 0x06000141 RID: 321 RVA: 0x0000D67C File Offset: 0x0000B87C
		private void OnHideComplete()
		{
			this._popupObject.SetActive(false);
			UpdateNotificationPopup._allPopups.Remove(this);
		}

		// Token: 0x06000142 RID: 322 RVA: 0x0000D698 File Offset: 0x0000B898
		public static int GetPopupCount()
		{
			return UpdateNotificationPopup._allPopups.Count;
		}

		// Token: 0x06000143 RID: 323 RVA: 0x0000D6A4 File Offset: 0x0000B8A4
		public static void CleanupAll()
		{
			try
			{
				foreach (UpdateNotificationPopup updateNotificationPopup in UpdateNotificationPopup._allPopups.ToArray())
				{
					if (updateNotificationPopup != null)
					{
						updateNotificationPopup.Cleanup();
					}
				}
				UpdateNotificationPopup._allPopups.Clear();
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("清理所有弹窗失败: {0}", arg));
			}
		}

		// Token: 0x06000144 RID: 324 RVA: 0x0000D714 File Offset: 0x0000B914
		public static void RearrangeAllPopups()
		{
			try
			{
				List<UpdateNotificationPopup> list = (from p in UpdateNotificationPopup._allPopups
				where p != null && p._popupObject != null && p._popupObject.activeSelf
				select p).ToList<UpdateNotificationPopup>();
				list.Sort((UpdateNotificationPopup a, UpdateNotificationPopup b) => a._popupIndex.CompareTo(b._popupIndex));
				for (int i = 0; i < list.Count; i++)
				{
					UpdateNotificationPopup updateNotificationPopup = list[i];
					RectTransform component = updateNotificationPopup._popupObject.GetComponent<RectTransform>();
					bool flag = component == null;
					if (!flag)
					{
						float num = -180f;
						float y = num - (float)i * 140f;
						component.anchoredPosition = new Vector2(-20f, y);
						updateNotificationPopup._popupIndex = i;
					}
				}
				Debug.Log(string.Format("重新排列 {0} 个弹窗", list.Count));
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("重新排列弹窗失败: {0}", arg));
			}
		}

		// Token: 0x06000145 RID: 325 RVA: 0x0000D828 File Offset: 0x0000BA28
		private void OnEnable()
		{
			SceneManager.sceneLoaded += this.OnSceneLoaded;
		}

		// Token: 0x06000146 RID: 326 RVA: 0x0000D83D File Offset: 0x0000BA3D
		private void OnDisable()
		{
			SceneManager.sceneLoaded -= this.OnSceneLoaded;
		}

		// Token: 0x06000147 RID: 327 RVA: 0x0000D854 File Offset: 0x0000BA54
		private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
		{
			try
			{
				bool flag = this._isVisible && this._popupObject != null && this._canvasGroup != null;
				if (flag)
				{
					this._canvasGroup.interactable = true;
					this._canvasGroup.blocksRaycasts = true;
					this._canvasGroup.alpha = 1f;
					this._popupObject.SetActive(true);
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("处理场景加载事件失败: {0}", arg));
			}
		}

		// Token: 0x06000148 RID: 328 RVA: 0x0000D8F0 File Offset: 0x0000BAF0
		private bool IsSteamRunning()
		{
			bool result;
			try
			{
				result = SteamAPI.IsSteamRunning();
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000149 RID: 329 RVA: 0x0000D920 File Offset: 0x0000BB20
		private Sprite LoadSprite(string spriteName)
		{
			Sprite result;
			try
			{
				Sprite sprite = ResourceLoader.LoadSprite(spriteName);
				bool flag = sprite == null;
				if (flag)
				{
					if (!(spriteName == "update_popup_background"))
					{
						if (!(spriteName == "update_popup_announcement_bg") && !(spriteName == "update_popup_steam_bg"))
						{
							if (spriteName == "update_popup_btn_bg")
							{
								sprite = ResourceLoader.LoadSprite("button_bg");
							}
						}
						else
						{
							sprite = ResourceLoader.LoadSprite("update_popup_btn_bg");
						}
					}
					else
					{
						sprite = ResourceLoader.LoadSprite("popup_bg");
					}
				}
				result = sprite;
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x0600014A RID: 330 RVA: 0x0000D9C4 File Offset: 0x0000BBC4
		private void CleanupTempObjects()
		{
			bool flag = this._popupObject != null;
			if (flag)
			{
				Object.Destroy(this._popupObject);
				this._popupObject = null;
			}
		}

		// Token: 0x0600014B RID: 331 RVA: 0x0000D9F8 File Offset: 0x0000BBF8
		public void Cleanup()
		{
			try
			{
				AnnouncementState.OnAnnouncementRead -= this.OnAnnouncementRead;
				AnnouncementState.OnPopupShouldHide -= this.OnPopupShouldHide;
				bool flag = this._popupObject != null;
				if (flag)
				{
					Object.Destroy(this._popupObject);
					this._popupObject = null;
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("清理弹窗失败: {0}", arg));
			}
			this._canvasGroup = null;
			this._config = null;
			this._state = null;
			this._animator = null;
			this._uiRoot = null;
			this._isInitialized = false;
			this._isVisible = false;
		}

		// Token: 0x04000098 RID: 152
		private const float POPUP_WIDTH = 375f;

		// Token: 0x04000099 RID: 153
		private const float POPUP_HEIGHT = 130f;

		// Token: 0x0400009A RID: 154
		private const float POPUP_SPACING = 10f;

		// Token: 0x0400009B RID: 155
		private const float BASE_Y_POSITION = -100f;

		// Token: 0x0400009C RID: 156
		private AnnouncementConfig _config;

		// Token: 0x0400009D RID: 157
		private AnnouncementState _state;

		// Token: 0x0400009E RID: 158
		private UIAnimator _animator;

		// Token: 0x0400009F RID: 159
		private Transform _uiRoot;

		// Token: 0x040000A0 RID: 160
		private GameObject _popupObject;

		// Token: 0x040000A1 RID: 161
		private CanvasGroup _canvasGroup;

		// Token: 0x040000A2 RID: 162
		private bool _isInitialized = false;

		// Token: 0x040000A3 RID: 163
		private bool _isVisible = false;

		// Token: 0x040000A4 RID: 164
		private int _popupIndex = 0;

		// Token: 0x040000A5 RID: 165
		private static List<UpdateNotificationPopup> _allPopups = new List<UpdateNotificationPopup>();

		// Token: 0x040000A6 RID: 166
		private UpdateNotificationPopup.PopupType _popupType;

		// Token: 0x02000034 RID: 52
		private enum PopupType
		{
			// Token: 0x040001A4 RID: 420
			PermanentUpdate,
			// Token: 0x040001A5 RID: 421
			UnreadAnnouncement
		}
	}
}
