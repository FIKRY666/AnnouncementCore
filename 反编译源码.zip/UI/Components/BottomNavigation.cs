﻿using System;
using System.Collections;
using AnnouncementCore.Data;
using AnnouncementCore.UI.Effects;
using AnnouncementCore.Utility;
using Steamworks;
using UnityEngine;
using UnityEngine.UI;

namespace AnnouncementCore.UI.Components
{
	// Token: 0x0200000B RID: 11
	public class BottomNavigation : MonoBehaviour
	{
		// Token: 0x060000A9 RID: 169 RVA: 0x000072A8 File Offset: 0x000054A8
		public void Initialize(Transform parent = null, Action onRefresh = null, Action onPrev = null, Action onNext = null, Action onFeedback = null, AnnouncementState state = null)
		{
			this._parentTransform = (parent ?? base.transform);
			this._onRefresh = onRefresh;
			this._onPrev = onPrev;
			this._onNext = onNext;
			this._onFeedback = onFeedback;
			this._state = state;
			this.CreateNavigationButtons();
		}

		// Token: 0x060000AA RID: 170 RVA: 0x000072F4 File Offset: 0x000054F4
		private void CreateNavigationButtons()
		{
			this.CreateButton("RefreshButton", new Vector2(-345f, -270f), new Vector2(40f, 40f), "refresh_button", new Color(0.2f, 0.6f, 0.9f, 1f), this._onRefresh, true);
			this.CreateNavigationButton("PrevButton", new Vector2(78f, -270f), "prev_button", true, this._onPrev);
			this.CreateNavigationButton("NextButton", new Vector2(123f, -270f), "next_button", false, this._onNext);
			this.CreateButton("FeedbackButton", new Vector2(183f, -270f), new Vector2(70f, 40f), "feedback_button", new Color(0.43f, 0.77f, 0.29f, 1f), new Action(this.OnFeedbackButtonClicked), true);
			this.CreateSteamWorkshopButton();
		}

		// Token: 0x060000AB RID: 171 RVA: 0x000073FC File Offset: 0x000055FC
		private void OnFeedbackButtonClicked()
		{
			try
			{
				AudioUtility.PlayClickSound();
				bool flag = this._state == null;
				if (!flag)
				{
					AnnouncementConfig selectedConfig = this._state.SelectedConfig;
					bool flag2 = selectedConfig == null;
					if (flag2)
					{
						Debug.LogWarning("BottomNavigation: 没有选中的Mod配置");
					}
					else
					{
						string feedbackUrl = selectedConfig.FeedbackUrl;
						bool flag3 = string.IsNullOrEmpty(feedbackUrl);
						if (!flag3)
						{
							Debug.Log("BottomNavigation: 打开反馈链接: " + feedbackUrl);
							Application.OpenURL(feedbackUrl);
						}
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("BottomNavigation: 打开反馈链接失败: {0}", arg));
			}
		}

		// Token: 0x060000AC RID: 172 RVA: 0x0000749C File Offset: 0x0000569C
		private void CreateButton(string name, Vector2 position, Vector2 size, string spriteName, Color fallbackColor, Action onClick, bool isEnabled = true)
		{
			GameObject gameObject = new GameObject(name, new Type[]
			{
				typeof(RectTransform),
				typeof(Image),
				typeof(Button)
			});
			gameObject.transform.SetParent(this._parentTransform, false);
			RectTransform rect = gameObject.GetComponent<RectTransform>();
			rect.anchorMin = new Vector2(0.5f, 0.5f);
			rect.anchorMax = new Vector2(0.5f, 0.5f);
			rect.pivot = new Vector2(0.5f, 0.5f);
			rect.anchoredPosition = position;
			rect.sizeDelta = size;
			Image component = gameObject.GetComponent<Image>();
			component.sprite = ResourceLoader.LoadSprite(spriteName);
			bool flag = !isEnabled;
			if (flag)
			{
				bool flag2 = component.sprite == null;
				if (flag2)
				{
					float num = fallbackColor.r * 0.299f + fallbackColor.g * 0.587f + fallbackColor.b * 0.114f;
					component.color = new Color(num, num, num, fallbackColor.a * 0.7f);
				}
				else
				{
					component.color = new Color(0.5f, 0.5f, 0.5f, 0.7f);
				}
			}
			else
			{
				component.color = Color.white;
				bool flag3 = component.sprite == null;
				if (flag3)
				{
					component.color = fallbackColor;
				}
			}
			component.type = 1;
			Button component2 = gameObject.GetComponent<Button>();
			component2.interactable = isEnabled;
			bool flag4 = isEnabled && onClick != null;
			if (flag4)
			{
				component2.onClick.AddListener(delegate()
				{
					AudioUtility.PlayClickSound();
					this.StartCoroutine(this.PlayButtonClickAnimation(rect));
					Action onClick2 = onClick;
					if (onClick2 != null)
					{
						onClick2();
					}
				});
			}
			if (isEnabled)
			{
				ButtonHoverEffect buttonHoverEffect = gameObject.AddComponent<ButtonHoverEffect>();
				buttonHoverEffect.ButtonImage = component;
				buttonHoverEffect.ButtonComponent = component2;
				buttonHoverEffect.ConfigureForPopupButton();
			}
			gameObject.transform.SetAsLastSibling();
		}

		// Token: 0x060000AD RID: 173 RVA: 0x000076D4 File Offset: 0x000058D4
		private void CreateNavigationButton(string name, Vector2 position, string spriteName, bool isLeft, Action onClick)
		{
			GameObject gameObject = new GameObject(name, new Type[]
			{
				typeof(RectTransform),
				typeof(Image),
				typeof(Button)
			});
			gameObject.transform.SetParent(this._parentTransform, false);
			RectTransform rect = gameObject.GetComponent<RectTransform>();
			rect.anchorMin = new Vector2(0.5f, 0.5f);
			rect.anchorMax = new Vector2(0.5f, 0.5f);
			rect.pivot = new Vector2(0.5f, 0.5f);
			rect.anchoredPosition = position;
			rect.sizeDelta = new Vector2(40f, 40f);
			Image component = gameObject.GetComponent<Image>();
			component.sprite = ResourceLoader.LoadSprite(spriteName);
			bool flag = component.sprite == null;
			if (flag)
			{
				component.color = new Color(0.13f, 0.63f, 0.76f, 1f);
			}
			component.type = 1;
			Button component2 = gameObject.GetComponent<Button>();
			component2.onClick.AddListener(delegate()
			{
				AudioUtility.PlayClickSound();
				this.StartCoroutine(this.PlayButtonClickAnimation(rect));
				Action onClick2 = onClick;
				if (onClick2 != null)
				{
					onClick2();
				}
			});
			this.CreateArrowIcon(gameObject.transform, isLeft);
			ButtonHoverEffect buttonHoverEffect = gameObject.AddComponent<ButtonHoverEffect>();
			buttonHoverEffect.ButtonImage = component;
			buttonHoverEffect.ButtonComponent = component2;
			buttonHoverEffect.ConfigureForPopupButton();
			gameObject.transform.SetAsLastSibling();
		}

		// Token: 0x060000AE RID: 174 RVA: 0x0000786C File Offset: 0x00005A6C
		private void CreateArrowIcon(Transform parent, bool isLeft)
		{
			GameObject gameObject = new GameObject("Arrow", new Type[]
			{
				typeof(RectTransform),
				typeof(Image)
			});
			gameObject.transform.SetParent(parent, false);
			RectTransform component = gameObject.GetComponent<RectTransform>();
			component.anchorMin = new Vector2(0.5f, 0.5f);
			component.anchorMax = new Vector2(0.5f, 0.5f);
			component.pivot = new Vector2(0.5f, 0.5f);
			component.anchoredPosition = Vector2.zero;
			component.sizeDelta = new Vector2(18f, 18f);
			Image component2 = gameObject.GetComponent<Image>();
			component2.sprite = ResourceLoader.LoadSprite(isLeft ? "left_arrow" : "right_arrow");
			bool flag = component2.sprite == null;
			if (flag)
			{
				component2.color = new Color(0.85f, 0.85f, 0.85f, 1f);
			}
			bool flag2 = !isLeft;
			if (flag2)
			{
				component.localRotation = Quaternion.Euler(0f, 0f, 180f);
			}
		}

		// Token: 0x060000AF RID: 175 RVA: 0x00007998 File Offset: 0x00005B98
		private void CreateSteamWorkshopButton()
		{
			GameObject gameObject = new GameObject("SteamWorkshopButton", new Type[]
			{
				typeof(RectTransform),
				typeof(Image),
				typeof(Button)
			});
			gameObject.transform.SetParent(this._parentTransform, false);
			RectTransform rect = gameObject.GetComponent<RectTransform>();
			rect.anchorMin = new Vector2(0.5f, 0.5f);
			rect.anchorMax = new Vector2(0.5f, 0.5f);
			rect.pivot = new Vector2(0.5f, 0.5f);
			rect.anchoredPosition = new Vector2(290f, -270f);
			rect.sizeDelta = new Vector2(135f, 40f);
			Image component = gameObject.GetComponent<Image>();
			component.sprite = ResourceLoader.LoadSprite("update_popup_steam_bg2");
			bool flag = component.sprite == null;
			if (flag)
			{
				component.color = new Color(0.1f, 0.5f, 0.2f, 1f);
			}
			component.type = 1;
			Button component2 = gameObject.GetComponent<Button>();
			component2.onClick.AddListener(delegate()
			{
				AudioUtility.PlayClickSound();
				this.StartCoroutine(this.PlayButtonClickAnimation(rect));
				this.OpenSteamWorkshop();
			});
			ButtonHoverEffect buttonHoverEffect = gameObject.AddComponent<ButtonHoverEffect>();
			buttonHoverEffect.ButtonImage = component;
			buttonHoverEffect.ButtonComponent = component2;
			buttonHoverEffect.ConfigureForPopupButton();
			gameObject.transform.SetAsLastSibling();
		}

		// Token: 0x060000B0 RID: 176 RVA: 0x00007B30 File Offset: 0x00005D30
		private void OpenSteamWorkshop()
		{
			try
			{
				bool flag = this._state == null;
				if (!flag)
				{
					AnnouncementConfig selectedConfig = this._state.SelectedConfig;
					bool flag2 = selectedConfig == null;
					if (!flag2)
					{
						string steamWorkshopUrl = selectedConfig.SteamWorkshopUrl;
						bool flag3 = string.IsNullOrEmpty(steamWorkshopUrl);
						if (flag3)
						{
							Debug.LogWarning("BottomNavigation: 选中的Mod没有Steam创意工坊链接: " + selectedConfig.ModId);
						}
						else
						{
							Debug.Log("BottomNavigation: 打开Steam页面: " + steamWorkshopUrl);
							bool flag4 = this.IsSteamRunning();
							if (flag4)
							{
								SteamFriends.ActivateGameOverlayToWebPage(steamWorkshopUrl, 0);
							}
							else
							{
								Application.OpenURL(steamWorkshopUrl);
							}
						}
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("BottomNavigation: 打开Steam创意工坊失败: {0}", arg));
			}
		}

		// Token: 0x060000B1 RID: 177 RVA: 0x00007BF4 File Offset: 0x00005DF4
		private bool IsSteamRunning()
		{
			bool result;
			try
			{
				result = SteamAPI.IsSteamRunning();
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x060000B2 RID: 178 RVA: 0x00007C24 File Offset: 0x00005E24
		private IEnumerator PlayButtonClickAnimation(RectTransform buttonRect)
		{
			BottomNavigation.<PlayButtonClickAnimation>d__19 <PlayButtonClickAnimation>d__ = new BottomNavigation.<PlayButtonClickAnimation>d__19(0);
			<PlayButtonClickAnimation>d__.<>4__this = this;
			<PlayButtonClickAnimation>d__.buttonRect = buttonRect;
			return <PlayButtonClickAnimation>d__;
		}

		// Token: 0x060000B3 RID: 179 RVA: 0x00007C3C File Offset: 0x00005E3C
		private float ElasticEaseOut(float t)
		{
			bool flag = t >= 1f;
			float result;
			if (flag)
			{
				result = 1f;
			}
			else
			{
				float num = 0.3f;
				float num2 = num / 4f;
				result = Mathf.Pow(2f, -10f * t) * Mathf.Sin((t - num2) * 6.2831855f / num) + 1f;
			}
			return result;
		}

		// Token: 0x060000B4 RID: 180 RVA: 0x00007C9C File Offset: 0x00005E9C
		public void Cleanup()
		{
			foreach (object obj in base.transform)
			{
				Transform transform = (Transform)obj;
				Object.Destroy(transform.gameObject);
			}
		}

		// Token: 0x04000039 RID: 57
		private Transform _parentTransform;

		// Token: 0x0400003A RID: 58
		private Action _onRefresh;

		// Token: 0x0400003B RID: 59
		private Action _onPrev;

		// Token: 0x0400003C RID: 60
		private Action _onNext;

		// Token: 0x0400003D RID: 61
		private Action _onFeedback;

		// Token: 0x0400003E RID: 62
		private const float BUTTON_SPACING = 49f;

		// Token: 0x0400003F RID: 63
		private const float BUTTON_Y = -270f;

		// Token: 0x04000040 RID: 64
		private const float BUTTON_BASE_Y = 65f;

		// Token: 0x04000041 RID: 65
		private const float NAVIGATION_OFFSET_Y = -200f;

		// Token: 0x04000042 RID: 66
		private AnnouncementState _state;
	}
}
