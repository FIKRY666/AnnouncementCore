﻿using System;
using System.Collections;
using AnnouncementCore.Utility;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace AnnouncementCore.UI.Effects
{
	// Token: 0x0200000A RID: 10
	public class ConsolidatedHoverEffect : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler
	{
		// Token: 0x0600008A RID: 138 RVA: 0x00006918 File Offset: 0x00004B18
		private void Awake()
		{
			this.CacheOriginalState();
			this.ApplyPresetConfiguration();
			this.ValidateComponents();
		}

		// Token: 0x0600008B RID: 139 RVA: 0x00006930 File Offset: 0x00004B30
		private void OnDestroy()
		{
			this.RestoreOriginalState();
			this.StopAnimation();
		}

		// Token: 0x0600008C RID: 140 RVA: 0x00006941 File Offset: 0x00004B41
		public void SetEffectType(ConsolidatedHoverEffect.EffectType type)
		{
			this._effectType = type;
			this.ApplyPresetConfiguration();
		}

		// Token: 0x0600008D RID: 141 RVA: 0x00006954 File Offset: 0x00004B54
		public void TriggerHover(bool isHovering)
		{
			bool flag = this._currentAnimation != null;
			if (flag)
			{
				base.StopCoroutine(this._currentAnimation);
			}
			this._currentAnimation = base.StartCoroutine(this.HoverAnimation(isHovering));
		}

		// Token: 0x0600008E RID: 142 RVA: 0x00006994 File Offset: 0x00004B94
		public void OnPointerEnter(PointerEventData eventData)
		{
			bool flag = this._buttonComponent != null && !this._buttonComponent.interactable;
			if (!flag)
			{
				AudioUtility.PlayHoverSound();
				this.TriggerHover(true);
			}
		}

		// Token: 0x0600008F RID: 143 RVA: 0x000069D8 File Offset: 0x00004BD8
		public void OnPointerExit(PointerEventData eventData)
		{
			bool flag = this._buttonComponent != null && !this._buttonComponent.interactable;
			if (!flag)
			{
				this.TriggerHover(false);
			}
		}

		// Token: 0x06000090 RID: 144 RVA: 0x00006A14 File Offset: 0x00004C14
		private void ApplyPresetConfiguration()
		{
			switch (this._effectType)
			{
			case ConsolidatedHoverEffect.EffectType.CloseButton:
				this.ConfigureAsCloseButton();
				break;
			case ConsolidatedHoverEffect.EffectType.SidebarItem:
				this.ConfigureAsSidebarItem();
				break;
			case ConsolidatedHoverEffect.EffectType.NotificationButton:
				this.ConfigureAsNotificationButton();
				break;
			case ConsolidatedHoverEffect.EffectType.PopupButton:
				this.ConfigureAsPopupButton();
				break;
			}
		}

		// Token: 0x06000091 RID: 145 RVA: 0x00006A6C File Offset: 0x00004C6C
		public void ConfigureAsCloseButton()
		{
			this._hoverScale = 1.08f;
			this._hoverAlpha = 0.85f;
			this._useHoverColor = false;
			this._useTextHoverColor = true;
			this._textHoverColor = new Color(1f, 0.95f, 0.9f, 1f);
			this._animationDuration = 0.2f;
			this._affectAdditionalTexts = false;
		}

		// Token: 0x06000092 RID: 146 RVA: 0x00006AD0 File Offset: 0x00004CD0
		public void ConfigureAsSidebarItem()
		{
			this._hoverScale = 1.05f;
			this._hoverAlpha = 0.9f;
			this._useHoverColor = true;
			this._hoverColor = new Color(0.3f, 0.3f, 0.4f, 1f);
			this._useTextHoverColor = true;
			this._textHoverColor = new Color(1f, 1f, 0.9f, 1f);
			this._animationDuration = 0.2f;
			this._affectAdditionalTexts = true;
		}

		// Token: 0x06000093 RID: 147 RVA: 0x00006B52 File Offset: 0x00004D52
		public void ConfigureAsNotificationButton()
		{
			this._hoverScale = 1.1f;
			this._hoverAlpha = 1f;
			this._useHoverColor = false;
			this._useTextHoverColor = false;
			this._animationDuration = 0.2f;
			this._affectAdditionalTexts = false;
		}

		// Token: 0x06000094 RID: 148 RVA: 0x00006B8C File Offset: 0x00004D8C
		public void ConfigureAsPopupButton()
		{
			this._hoverScale = 1.1f;
			this._hoverAlpha = 0.8f;
			this._useHoverColor = false;
			this._useTextHoverColor = true;
			this._textHoverColor = new Color(1f, 0.9f, 0.8f, 1f);
			this._animationDuration = 0.3f;
			this._affectAdditionalTexts = false;
		}

		// Token: 0x06000095 RID: 149 RVA: 0x00006BF0 File Offset: 0x00004DF0
		private void CacheOriginalState()
		{
			bool flag = this._buttonImage == null;
			if (flag)
			{
				this._buttonImage = base.GetComponent<Image>();
			}
			bool flag2 = this._buttonComponent == null;
			if (flag2)
			{
				this._buttonComponent = base.GetComponent<Button>();
			}
			bool flag3 = this._buttonText == null && this._buttonComponent != null;
			if (flag3)
			{
				this._buttonText = this._buttonComponent.GetComponentInChildren<TextMeshProUGUI>();
			}
			bool flag4 = this._additionalText1 == null;
			if (flag4)
			{
				Transform transform = base.transform.Find("ModName");
				this._additionalText1 = ((transform != null) ? transform.GetComponent<TextMeshProUGUI>() : null);
			}
			bool flag5 = this._additionalText2 == null;
			if (flag5)
			{
				Transform transform2 = base.transform.Find("ModVersion");
				this._additionalText2 = ((transform2 != null) ? transform2.GetComponent<TextMeshProUGUI>() : null);
			}
			bool flag6 = this._buttonImage != null;
			if (flag6)
			{
				this._originalImageColor = this._buttonImage.color;
			}
			this._originalScale = base.transform.localScale;
			bool flag7 = this._buttonText != null;
			if (flag7)
			{
				this._originalTextColor = this._buttonText.color;
			}
			bool flag8 = this._additionalText1 != null;
			if (flag8)
			{
				this._originalAdditionalText1Color = this._additionalText1.color;
			}
			bool flag9 = this._additionalText2 != null;
			if (flag9)
			{
				this._originalAdditionalText2Color = this._additionalText2.color;
			}
		}

		// Token: 0x06000096 RID: 150 RVA: 0x00006D74 File Offset: 0x00004F74
		private void RestoreOriginalState()
		{
			bool flag = base.transform != null;
			if (flag)
			{
				base.transform.localScale = this._originalScale;
			}
			bool flag2 = this._buttonImage != null;
			if (flag2)
			{
				this._buttonImage.color = this._originalImageColor;
			}
			bool flag3 = this._buttonText != null;
			if (flag3)
			{
				this._buttonText.color = this._originalTextColor;
			}
			bool flag4 = this._additionalText1 != null;
			if (flag4)
			{
				this._additionalText1.color = this._originalAdditionalText1Color;
			}
			bool flag5 = this._additionalText2 != null;
			if (flag5)
			{
				this._additionalText2.color = this._originalAdditionalText2Color;
			}
		}

		// Token: 0x06000097 RID: 151 RVA: 0x00006E30 File Offset: 0x00005030
		private void ValidateComponents()
		{
			bool flag = this._buttonImage == null;
			if (flag)
			{
				Debug.LogWarning("ConsolidatedHoverEffect: " + base.gameObject.name + " 缺少Image组件");
			}
			bool flag2 = this._buttonComponent == null;
			if (flag2)
			{
				Debug.LogWarning("ConsolidatedHoverEffect: " + base.gameObject.name + " 缺少Button组件");
			}
		}

		// Token: 0x06000098 RID: 152 RVA: 0x00006EA2 File Offset: 0x000050A2
		private IEnumerator HoverAnimation(bool isHovering)
		{
			ConsolidatedHoverEffect.<HoverAnimation>d__35 <HoverAnimation>d__ = new ConsolidatedHoverEffect.<HoverAnimation>d__35(0);
			<HoverAnimation>d__.<>4__this = this;
			<HoverAnimation>d__.isHovering = isHovering;
			return <HoverAnimation>d__;
		}

		// Token: 0x06000099 RID: 153 RVA: 0x00006EB8 File Offset: 0x000050B8
		private Color GetTargetImageColor(bool isHovering)
		{
			bool flag = !isHovering;
			Color result;
			if (flag)
			{
				result = this._originalImageColor;
			}
			else
			{
				bool flag2 = this._useHoverColor && this._buttonImage != null;
				if (flag2)
				{
					result = Color.Lerp(this._originalImageColor, this._hoverColor, 0.4f);
				}
				else
				{
					result = new Color(this._originalImageColor.r, this._originalImageColor.g, this._originalImageColor.b, this._hoverAlpha);
				}
			}
			return result;
		}

		// Token: 0x0600009A RID: 154 RVA: 0x00006F3C File Offset: 0x0000513C
		private Color GetTargetTextColor(bool isHovering)
		{
			bool flag = !isHovering;
			Color result;
			if (flag)
			{
				result = this._originalTextColor;
			}
			else
			{
				result = ((this._useTextHoverColor && this._buttonText != null) ? this._textHoverColor : this._originalTextColor);
			}
			return result;
		}

		// Token: 0x0600009B RID: 155 RVA: 0x00006F84 File Offset: 0x00005184
		private Color GetTargetAdditionalTextColor(TextMeshProUGUI text, bool isHovering)
		{
			bool flag = !isHovering || !this._affectAdditionalTexts || text == null;
			Color result;
			if (flag)
			{
				result = ((text != null) ? text.color : Color.white);
			}
			else
			{
				result = this._textHoverColor;
			}
			return result;
		}

		// Token: 0x0600009C RID: 156 RVA: 0x00006FD0 File Offset: 0x000051D0
		private void ApplyTransform(float progress, Vector3 startScale, Vector3 targetScale, Color startImageColor, Color targetImageColor, Color startTextColor, Color targetTextColor, Color startAdditionalText1Color, Color targetAdditionalText1Color, Color startAdditionalText2Color, Color targetAdditionalText2Color)
		{
			base.transform.localScale = Vector3.Lerp(startScale, targetScale, progress);
			bool flag = this._buttonImage != null;
			if (flag)
			{
				this._buttonImage.color = Color.Lerp(startImageColor, targetImageColor, progress);
			}
			bool flag2 = this._buttonText != null;
			if (flag2)
			{
				this._buttonText.color = Color.Lerp(startTextColor, targetTextColor, progress);
			}
			bool flag3 = this._additionalText1 != null;
			if (flag3)
			{
				this._additionalText1.color = Color.Lerp(startAdditionalText1Color, targetAdditionalText1Color, progress);
			}
			bool flag4 = this._additionalText2 != null;
			if (flag4)
			{
				this._additionalText2.color = Color.Lerp(startAdditionalText2Color, targetAdditionalText2Color, progress);
			}
		}

		// Token: 0x0600009D RID: 157 RVA: 0x0000708C File Offset: 0x0000528C
		private void ApplyFinalState(Vector3 targetScale, Color targetImageColor, Color targetTextColor, Color targetAdditionalText1Color, Color targetAdditionalText2Color)
		{
			bool flag = base.transform != null;
			if (flag)
			{
				base.transform.localScale = targetScale;
			}
			bool flag2 = this._buttonImage != null;
			if (flag2)
			{
				this._buttonImage.color = targetImageColor;
			}
			bool flag3 = this._buttonText != null;
			if (flag3)
			{
				this._buttonText.color = targetTextColor;
			}
			bool flag4 = this._additionalText1 != null;
			if (flag4)
			{
				this._additionalText1.color = targetAdditionalText1Color;
			}
			bool flag5 = this._additionalText2 != null;
			if (flag5)
			{
				this._additionalText2.color = targetAdditionalText2Color;
			}
		}

		// Token: 0x0600009E RID: 158 RVA: 0x00007130 File Offset: 0x00005330
		private void StopAnimation()
		{
			bool flag = this._currentAnimation != null;
			if (flag)
			{
				base.StopCoroutine(this._currentAnimation);
				this._currentAnimation = null;
			}
		}

		// Token: 0x0600009F RID: 159 RVA: 0x00007161 File Offset: 0x00005361
		private float SmoothEaseOut(float t)
		{
			return 1f - Mathf.Pow(1f - t, 3f);
		}

		// Token: 0x060000A0 RID: 160 RVA: 0x0000717C File Offset: 0x0000537C
		private float ElasticEaseOut(float t)
		{
			bool flag = t >= 1f;
			float result;
			if (flag)
			{
				result = 1f;
			}
			else
			{
				float num = 0.3f;
				float num2 = num / 4f;
				result = Mathf.Pow(2f, -10f * t) * Mathf.Sin((t - num2) * 6.2831855f / num) + 1f;
			}
			return result;
		}

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x060000A1 RID: 161 RVA: 0x000071DB File Offset: 0x000053DB
		// (set) Token: 0x060000A2 RID: 162 RVA: 0x000071E3 File Offset: 0x000053E3
		public Image ButtonImage
		{
			get
			{
				return this._buttonImage;
			}
			set
			{
				this._buttonImage = value;
			}
		}

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x060000A3 RID: 163 RVA: 0x000071EC File Offset: 0x000053EC
		// (set) Token: 0x060000A4 RID: 164 RVA: 0x000071F4 File Offset: 0x000053F4
		public Button ButtonComponent
		{
			get
			{
				return this._buttonComponent;
			}
			set
			{
				this._buttonComponent = value;
			}
		}

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x060000A5 RID: 165 RVA: 0x000071FD File Offset: 0x000053FD
		// (set) Token: 0x060000A6 RID: 166 RVA: 0x00007205 File Offset: 0x00005405
		public TextMeshProUGUI ButtonText
		{
			get
			{
				return this._buttonText;
			}
			set
			{
				this._buttonText = value;
			}
		}

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x060000A7 RID: 167 RVA: 0x0000720E File Offset: 0x0000540E
		public ConsolidatedHoverEffect.EffectType CurrentEffectType
		{
			get
			{
				return this._effectType;
			}
		}

		// Token: 0x04000025 RID: 37
		[Header("组件引用")]
		[SerializeField]
		private Image _buttonImage;

		// Token: 0x04000026 RID: 38
		[SerializeField]
		private Button _buttonComponent;

		// Token: 0x04000027 RID: 39
		[SerializeField]
		private TextMeshProUGUI _buttonText;

		// Token: 0x04000028 RID: 40
		[SerializeField]
		private TextMeshProUGUI _additionalText1;

		// Token: 0x04000029 RID: 41
		[SerializeField]
		private TextMeshProUGUI _additionalText2;

		// Token: 0x0400002A RID: 42
		[Header("悬停效果配置")]
		[SerializeField]
		private float _hoverScale = 1.05f;

		// Token: 0x0400002B RID: 43
		[SerializeField]
		private float _hoverAlpha = 0.85f;

		// Token: 0x0400002C RID: 44
		[SerializeField]
		private float _animationDuration = 0.2f;

		// Token: 0x0400002D RID: 45
		[Header("颜色配置")]
		[SerializeField]
		private bool _useHoverColor = false;

		// Token: 0x0400002E RID: 46
		[SerializeField]
		private Color _hoverColor = new Color(0.3f, 0.3f, 0.4f, 1f);

		// Token: 0x0400002F RID: 47
		[SerializeField]
		private bool _useTextHoverColor = false;

		// Token: 0x04000030 RID: 48
		[SerializeField]
		private Color _textHoverColor = new Color(1f, 0.95f, 0.9f, 1f);

		// Token: 0x04000031 RID: 49
		[SerializeField]
		private bool _affectAdditionalTexts = true;

		// Token: 0x04000032 RID: 50
		[Header("效果类型")]
		[SerializeField]
		private ConsolidatedHoverEffect.EffectType _effectType = ConsolidatedHoverEffect.EffectType.Generic;

		// Token: 0x04000033 RID: 51
		private Vector3 _originalScale;

		// Token: 0x04000034 RID: 52
		private Color _originalImageColor;

		// Token: 0x04000035 RID: 53
		private Color _originalTextColor;

		// Token: 0x04000036 RID: 54
		private Color _originalAdditionalText1Color;

		// Token: 0x04000037 RID: 55
		private Color _originalAdditionalText2Color;

		// Token: 0x04000038 RID: 56
		private Coroutine _currentAnimation;

		// Token: 0x02000025 RID: 37
		public enum EffectType
		{
			// Token: 0x0400013B RID: 315
			Generic,
			// Token: 0x0400013C RID: 316
			CloseButton,
			// Token: 0x0400013D RID: 317
			SidebarItem,
			// Token: 0x0400013E RID: 318
			NotificationButton,
			// Token: 0x0400013F RID: 319
			PopupButton
		}
	}
}
