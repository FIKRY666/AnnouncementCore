﻿using System;
using System.Collections;
using AnnouncementCore.Utility;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace AnnouncementCore.UI.Effects
{
	// Token: 0x02000009 RID: 9
	public class ButtonHoverEffect : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler
	{
		// Token: 0x06000080 RID: 128 RVA: 0x000065D0 File Offset: 0x000047D0
		private void Awake()
		{
			bool flag = this.ButtonImage == null;
			if (flag)
			{
				this.ButtonImage = base.GetComponent<Image>();
			}
			bool flag2 = this.ButtonComponent == null;
			if (flag2)
			{
				this.ButtonComponent = base.GetComponent<Button>();
			}
			bool flag3 = this.ButtonText == null && this.ButtonComponent != null;
			if (flag3)
			{
				this.ButtonText = this.ButtonComponent.GetComponentInChildren<TextMeshProUGUI>();
			}
			bool flag4 = this.ButtonImage != null;
			if (flag4)
			{
				this._originalImageColor = this.ButtonImage.color;
			}
			this._originalScale = base.transform.localScale;
			bool flag5 = this.ButtonText != null;
			if (flag5)
			{
				this._originalTextColor = this.ButtonText.color;
			}
		}

		// Token: 0x06000081 RID: 129 RVA: 0x000066A0 File Offset: 0x000048A0
		public void OnPointerEnter(PointerEventData eventData)
		{
			bool flag = this.ButtonComponent != null && !this.ButtonComponent.interactable;
			if (!flag)
			{
				AudioUtility.PlayHoverSound();
				bool flag2 = this._currentAnimation != null;
				if (flag2)
				{
					base.StopCoroutine(this._currentAnimation);
				}
				this._currentAnimation = base.StartCoroutine(this.HoverAnimation(true));
			}
		}

		// Token: 0x06000082 RID: 130 RVA: 0x00006708 File Offset: 0x00004908
		public void OnPointerExit(PointerEventData eventData)
		{
			bool flag = this.ButtonComponent != null && !this.ButtonComponent.interactable;
			if (!flag)
			{
				bool flag2 = this._currentAnimation != null;
				if (flag2)
				{
					base.StopCoroutine(this._currentAnimation);
				}
				this._currentAnimation = base.StartCoroutine(this.HoverAnimation(false));
			}
		}

		// Token: 0x06000083 RID: 131 RVA: 0x00006768 File Offset: 0x00004968
		private IEnumerator HoverAnimation(bool isHovering)
		{
			ButtonHoverEffect.<HoverAnimation>d__14 <HoverAnimation>d__ = new ButtonHoverEffect.<HoverAnimation>d__14(0);
			<HoverAnimation>d__.<>4__this = this;
			<HoverAnimation>d__.isHovering = isHovering;
			return <HoverAnimation>d__;
		}

		// Token: 0x06000084 RID: 132 RVA: 0x0000677E File Offset: 0x0000497E
		private float SmoothEaseOut(float t)
		{
			return 1f - Mathf.Pow(1f - t, 3f);
		}

		// Token: 0x06000085 RID: 133 RVA: 0x00006797 File Offset: 0x00004997
		public void ConfigureForPopupButton()
		{
			this._hoverScale = 1.1f;
			this._useTextHoverColor = true;
			this._textHoverColor = new Color(1f, 0.9f, 0.8f, 1f);
			this._animationDuration = 0.3f;
		}

		// Token: 0x06000086 RID: 134 RVA: 0x000067D6 File Offset: 0x000049D6
		public void ConfigureForSidebarItem()
		{
			this._hoverScale = 1.05f;
			this._useTextHoverColor = true;
			this._textHoverColor = new Color(1f, 1f, 0.9f, 1f);
			this._animationDuration = 0.3f;
		}

		// Token: 0x06000087 RID: 135 RVA: 0x00006815 File Offset: 0x00004A15
		public void ConfigureForNotificationButton()
		{
			this._hoverScale = 1.1f;
			this._useTextHoverColor = false;
			this._animationDuration = 0.3f;
		}

		// Token: 0x06000088 RID: 136 RVA: 0x00006838 File Offset: 0x00004A38
		private void OnDestroy()
		{
			bool flag = base.transform != null;
			if (flag)
			{
				base.transform.localScale = this._originalScale;
			}
			bool flag2 = this.ButtonImage != null;
			if (flag2)
			{
				this.ButtonImage.color = this._originalImageColor;
			}
			bool flag3 = this.ButtonText != null;
			if (flag3)
			{
				this.ButtonText.color = this._originalTextColor;
			}
			bool flag4 = this._currentAnimation != null;
			if (flag4)
			{
				base.StopCoroutine(this._currentAnimation);
			}
		}

		// Token: 0x0400001A RID: 26
		[Header("组件引用")]
		public Image ButtonImage;

		// Token: 0x0400001B RID: 27
		public Button ButtonComponent;

		// Token: 0x0400001C RID: 28
		public TextMeshProUGUI ButtonText;

		// Token: 0x0400001D RID: 29
		[Header("效果配置")]
		[SerializeField]
		private float _hoverScale = 1.1f;

		// Token: 0x0400001E RID: 30
		[SerializeField]
		private float _animationDuration = 0.3f;

		// Token: 0x0400001F RID: 31
		[SerializeField]
		private bool _useTextHoverColor = false;

		// Token: 0x04000020 RID: 32
		[SerializeField]
		private Color _textHoverColor = new Color(1f, 0.95f, 0.9f, 1f);

		// Token: 0x04000021 RID: 33
		private Vector3 _originalScale;

		// Token: 0x04000022 RID: 34
		private Color _originalImageColor;

		// Token: 0x04000023 RID: 35
		private Color _originalTextColor;

		// Token: 0x04000024 RID: 36
		private Coroutine _currentAnimation;
	}
}
