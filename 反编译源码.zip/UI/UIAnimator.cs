﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace AnnouncementCore.UI
{
	// Token: 0x02000007 RID: 7
	public class UIAnimator
	{
		// Token: 0x06000053 RID: 83 RVA: 0x00005198 File Offset: 0x00003398
		public UIAnimator(MonoBehaviour owner)
		{
			bool flag = owner == null;
			if (flag)
			{
				Debug.LogError("UIAnimator: owner不能为null");
				throw new ArgumentNullException("owner");
			}
			this._owner = owner;
		}

		// Token: 0x06000054 RID: 84 RVA: 0x000051D8 File Offset: 0x000033D8
		public void StartButtonRotation(Transform buttonTransform, bool shouldAnimate)
		{
			this.StopButtonAnimation();
			bool flag = buttonTransform == null;
			if (flag)
			{
				Debug.LogWarning("UIAnimator: buttonTransform 为 null，无法开始旋转动画");
			}
			else
			{
				bool flag2 = !shouldAnimate;
				if (flag2)
				{
					try
					{
						buttonTransform.localRotation = Quaternion.identity;
					}
					catch (Exception arg)
					{
						Debug.LogError(string.Format("重置按钮旋转失败: {0}", arg));
					}
				}
				else
				{
					try
					{
						this._buttonAnimationCoroutine = this._owner.StartCoroutine(this.ButtonRotationAnimation(buttonTransform));
					}
					catch (Exception arg2)
					{
						Debug.LogError(string.Format("启动按钮旋转动画失败: {0}", arg2));
					}
				}
			}
		}

		// Token: 0x06000055 RID: 85 RVA: 0x00005288 File Offset: 0x00003488
		public IEnumerator ScrollViewElasticAnimation(ScrollRect scrollRect, float targetNormalizedPos, float duration = 0.5f)
		{
			UIAnimator.<ScrollViewElasticAnimation>d__4 <ScrollViewElasticAnimation>d__ = new UIAnimator.<ScrollViewElasticAnimation>d__4(0);
			<ScrollViewElasticAnimation>d__.<>4__this = this;
			<ScrollViewElasticAnimation>d__.scrollRect = scrollRect;
			<ScrollViewElasticAnimation>d__.targetNormalizedPos = targetNormalizedPos;
			<ScrollViewElasticAnimation>d__.duration = duration;
			return <ScrollViewElasticAnimation>d__;
		}

		// Token: 0x06000056 RID: 86 RVA: 0x000052AC File Offset: 0x000034AC
		public void StopButtonAnimation()
		{
			bool flag = this._buttonAnimationCoroutine != null;
			if (flag)
			{
				try
				{
					this._owner.StopCoroutine(this._buttonAnimationCoroutine);
				}
				catch (Exception arg)
				{
					Debug.LogError(string.Format("停止按钮动画失败: {0}", arg));
				}
				finally
				{
					this._buttonAnimationCoroutine = null;
				}
			}
		}

		// Token: 0x06000057 RID: 87 RVA: 0x00005320 File Offset: 0x00003520
		private IEnumerator ButtonRotationAnimation(Transform buttonTransform)
		{
			UIAnimator.<ButtonRotationAnimation>d__6 <ButtonRotationAnimation>d__ = new UIAnimator.<ButtonRotationAnimation>d__6(0);
			<ButtonRotationAnimation>d__.<>4__this = this;
			<ButtonRotationAnimation>d__.buttonTransform = buttonTransform;
			return <ButtonRotationAnimation>d__;
		}

		// Token: 0x06000058 RID: 88 RVA: 0x00005336 File Offset: 0x00003536
		public IEnumerator PanelShowAnimation(Transform panelTransform, CanvasGroup canvasGroup, Action onComplete = null)
		{
			UIAnimator.<PanelShowAnimation>d__7 <PanelShowAnimation>d__ = new UIAnimator.<PanelShowAnimation>d__7(0);
			<PanelShowAnimation>d__.<>4__this = this;
			<PanelShowAnimation>d__.panelTransform = panelTransform;
			<PanelShowAnimation>d__.canvasGroup = canvasGroup;
			<PanelShowAnimation>d__.onComplete = onComplete;
			return <PanelShowAnimation>d__;
		}

		// Token: 0x06000059 RID: 89 RVA: 0x0000535A File Offset: 0x0000355A
		public IEnumerator PanelHideAnimation(Transform panelTransform, CanvasGroup canvasGroup, Action onComplete = null)
		{
			UIAnimator.<PanelHideAnimation>d__8 <PanelHideAnimation>d__ = new UIAnimator.<PanelHideAnimation>d__8(0);
			<PanelHideAnimation>d__.<>4__this = this;
			<PanelHideAnimation>d__.panelTransform = panelTransform;
			<PanelHideAnimation>d__.canvasGroup = canvasGroup;
			<PanelHideAnimation>d__.onComplete = onComplete;
			return <PanelHideAnimation>d__;
		}

		// Token: 0x0600005A RID: 90 RVA: 0x0000537E File Offset: 0x0000357E
		public IEnumerator ButtonBounceAnimation(Transform buttonTransform, float intensity = 0.12f, float duration = 0.25f)
		{
			UIAnimator.<ButtonBounceAnimation>d__9 <ButtonBounceAnimation>d__ = new UIAnimator.<ButtonBounceAnimation>d__9(0);
			<ButtonBounceAnimation>d__.<>4__this = this;
			<ButtonBounceAnimation>d__.buttonTransform = buttonTransform;
			<ButtonBounceAnimation>d__.intensity = intensity;
			<ButtonBounceAnimation>d__.duration = duration;
			return <ButtonBounceAnimation>d__;
		}

		// Token: 0x0600005B RID: 91 RVA: 0x000053A2 File Offset: 0x000035A2
		public IEnumerator PanelElasticShowAnimation(Transform panelTransform, CanvasGroup canvasGroup, Action onComplete = null)
		{
			UIAnimator.<PanelElasticShowAnimation>d__10 <PanelElasticShowAnimation>d__ = new UIAnimator.<PanelElasticShowAnimation>d__10(0);
			<PanelElasticShowAnimation>d__.<>4__this = this;
			<PanelElasticShowAnimation>d__.panelTransform = panelTransform;
			<PanelElasticShowAnimation>d__.canvasGroup = canvasGroup;
			<PanelElasticShowAnimation>d__.onComplete = onComplete;
			return <PanelElasticShowAnimation>d__;
		}

		// Token: 0x0600005C RID: 92 RVA: 0x000053C8 File Offset: 0x000035C8
		private float ElasticEaseOut(float t)
		{
			bool flag = t >= 1f;
			float result;
			if (flag)
			{
				result = 1f;
			}
			else
			{
				float num = 0.3f;
				float num2 = num / 4f;
				result = Mathf.Pow(2f, -10f * t) * Mathf.Sin((t - num2) * 6.2831855f / num) + 1f;
			}
			return result;
		}

		// Token: 0x0600005D RID: 93 RVA: 0x00005428 File Offset: 0x00003628
		private float BackEaseOut(float t)
		{
			float num = 1.70158f;
			float num2 = num + 1f;
			return 1f + num2 * Mathf.Pow(t - 1f, 3f) + num * Mathf.Pow(t - 1f, 2f);
		}

		// Token: 0x0600005E RID: 94 RVA: 0x00005478 File Offset: 0x00003678
		private float QuadEaseOut(float t)
		{
			return 1f - (1f - t) * (1f - t);
		}

		// Token: 0x0600005F RID: 95 RVA: 0x000054A0 File Offset: 0x000036A0
		private float BounceEaseOut(float t)
		{
			bool flag = t < 0.36363637f;
			float result;
			if (flag)
			{
				result = 7.5625f * t * t;
			}
			else
			{
				bool flag2 = t < 0.72727275f;
				if (flag2)
				{
					t -= 0.54545456f;
					result = 7.5625f * t * t + 0.75f;
				}
				else
				{
					bool flag3 = t < 0.90909094f;
					if (flag3)
					{
						t -= 0.8181818f;
						result = 7.5625f * t * t + 0.9375f;
					}
					else
					{
						t -= 0.95454544f;
						result = 7.5625f * t * t + 0.984375f;
					}
				}
			}
			return result;
		}

		// Token: 0x06000060 RID: 96 RVA: 0x00005534 File Offset: 0x00003734
		public void Cleanup()
		{
			this.StopButtonAnimation();
		}

		// Token: 0x0400000F RID: 15
		private readonly MonoBehaviour _owner;

		// Token: 0x04000010 RID: 16
		private Coroutine _buttonAnimationCoroutine;
	}
}
