﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using AnnouncementCore.Data;
using AnnouncementCore.UI.Components;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace AnnouncementCore.UI
{
	// Token: 0x02000008 RID: 8
	public class UIManager : MonoBehaviour
	{
		// Token: 0x06000061 RID: 97 RVA: 0x00005540 File Offset: 0x00003740
		public void Initialize(AnnouncementState state, Transform uiRoot)
		{
			try
			{
				bool flag = uiRoot == null;
				if (flag)
				{
					Debug.LogError("UIManager: uiRoot为null");
				}
				else
				{
					Canvas component = uiRoot.GetComponent<Canvas>();
					bool flag2 = component == null;
					if (flag2)
					{
						Debug.LogError("UIManager: uiRoot没有Canvas组件");
					}
					else
					{
						bool flag3 = state == null;
						if (flag3)
						{
							Debug.LogError("UIManager: AnnouncementState为null");
						}
						else
						{
							List<AnnouncementConfig> allConfigsSorted;
							try
							{
								allConfigsSorted = state.GetAllConfigsSorted();
							}
							catch (Exception ex)
							{
								Debug.LogError("获取配置列表失败: " + ex.Message);
								return;
							}
							bool flag4 = allConfigsSorted.Count == 0;
							if (flag4)
							{
								Debug.Log("AnnouncementCore: 没有公告配置，不创建UI");
							}
							else
							{
								this._state = state;
								this._uiRoot = uiRoot;
								this._animator = new UIAnimator(this);
								this.CreateNotificationButton();
								this.CreateMainPanel();
								this.CreateSummaryPanel();
								this.SubscribeToEvents();
								base.StartCoroutine(this.DelayedInitialization());
							}
						}
					}
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("UIManager 初始化失败: {0}", arg));
				this._isInitialized = false;
			}
		}

		// Token: 0x06000062 RID: 98 RVA: 0x00005674 File Offset: 0x00003874
		private IEnumerator DelayedInitialization()
		{
			UIManager.<DelayedInitialization>d__10 <DelayedInitialization>d__ = new UIManager.<DelayedInitialization>d__10(0);
			<DelayedInitialization>d__.<>4__this = this;
			return <DelayedInitialization>d__;
		}

		// Token: 0x06000063 RID: 99 RVA: 0x00005684 File Offset: 0x00003884
		private void CreateNotificationButton()
		{
			try
			{
				this._notificationButton = base.gameObject.AddComponent<NotificationButton>();
				this._notificationButton.Initialize(this._uiRoot, new Action(this.OnNotificationButtonClicked));
			}
			catch (Exception ex)
			{
				this._notificationButton = null;
			}
		}

		// Token: 0x06000064 RID: 100 RVA: 0x000056E4 File Offset: 0x000038E4
		private void CreateMainPanel()
		{
			try
			{
				this._mainPanel = base.gameObject.AddComponent<MainPanel>();
				this._mainPanel.Initialize(this._uiRoot, this._state, this._animator);
				this._mainPanel.SetCallbacks(new Action(this.OnPrevButtonClicked), new Action(this.OnNextButtonClicked), new Action(this.OnFeedbackButtonClicked), new Action(this.OnCloseButtonClicked));
			}
			catch (Exception ex)
			{
				this._mainPanel = null;
			}
		}

		// Token: 0x06000065 RID: 101 RVA: 0x00005780 File Offset: 0x00003980
		private void CreateSummaryPanel()
		{
			try
			{
				this._summaryPanel = base.gameObject.AddComponent<SummaryNotificationPanel>();
				this._summaryPanel.Initialize(this._state, this._uiRoot, new Action<bool>(this.OnPopupsVisibilityChanged));
				this._summaryPanel.Show();
			}
			catch (Exception ex)
			{
				this._summaryPanel = null;
			}
		}

		// Token: 0x06000066 RID: 102 RVA: 0x000057F0 File Offset: 0x000039F0
		private void OnPopupsVisibilityChanged(bool areVisible)
		{
			this._popupsVisible = areVisible;
			try
			{
				if (areVisible)
				{
					foreach (UpdateNotificationPopup updateNotificationPopup in this._updatePopups)
					{
						bool flag = updateNotificationPopup != null && updateNotificationPopup.ModId != null && this._state != null;
						if (flag)
						{
							AnnouncementConfig configById = this._state.GetConfigById(updateNotificationPopup.ModId);
							bool flag2 = configById != null && this.ShouldPopupBeVisible(configById, updateNotificationPopup.ModId);
							if (flag2)
							{
								updateNotificationPopup.Show();
							}
							else
							{
								updateNotificationPopup.Cleanup();
							}
						}
					}
					this._updatePopups.RemoveAll((UpdateNotificationPopup p) => p == null);
					UpdateNotificationPopup.RearrangeAllPopups();
				}
				else
				{
					foreach (UpdateNotificationPopup updateNotificationPopup2 in this._updatePopups)
					{
						bool flag3 = updateNotificationPopup2 != null && updateNotificationPopup2.ModId != null && this._state != null;
						if (flag3)
						{
							AnnouncementConfig configById2 = this._state.GetConfigById(updateNotificationPopup2.ModId);
							bool flag4 = configById2 != null && !configById2.HasPermanentUpdate;
							if (flag4)
							{
								this._state.MarkPopupAsHidden(updateNotificationPopup2.ModId);
							}
							updateNotificationPopup2.Hide();
						}
					}
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x06000067 RID: 103 RVA: 0x000059DC File Offset: 0x00003BDC
		private void SubscribeToEvents()
		{
			AnnouncementState.OnUnreadStatusChanged += this.UpdateNotificationButton;
			AnnouncementState.OnAnnouncementSelected += this.OnAnnouncementSelected;
			AnnouncementState.OnPanelStateChanged += this.OnPanelStateChanged;
			AnnouncementState.OnAnnouncementRead += this.OnAnnouncementRead;
			AnnouncementState.OnPopupShouldHide += this.OnPopupShouldHide;
			SceneManager.sceneLoaded += this.OnSceneLoaded;
		}

		// Token: 0x06000068 RID: 104 RVA: 0x00005A58 File Offset: 0x00003C58
		private void UnsubscribeFromEvents()
		{
			AnnouncementState.OnUnreadStatusChanged -= this.UpdateNotificationButton;
			AnnouncementState.OnAnnouncementSelected -= this.OnAnnouncementSelected;
			AnnouncementState.OnPanelStateChanged -= this.OnPanelStateChanged;
			AnnouncementState.OnAnnouncementRead -= this.OnAnnouncementRead;
			AnnouncementState.OnPopupShouldHide -= this.OnPopupShouldHide;
			SceneManager.sceneLoaded -= this.OnSceneLoaded;
		}

		// Token: 0x06000069 RID: 105 RVA: 0x00005AD4 File Offset: 0x00003CD4
		private void OnNotificationButtonClicked()
		{
			bool flag = !this._isInitialized || this._state == null;
			if (!flag)
			{
				try
				{
					bool isPanelOpen = this._state.IsPanelOpen;
					if (isPanelOpen)
					{
						MainPanel mainPanel = this._mainPanel;
						if (mainPanel != null)
						{
							mainPanel.Hide();
						}
						this._state.ClosePanel();
					}
					else
					{
						List<AnnouncementConfig> allConfigsSorted = this._state.GetAllConfigsSorted();
						bool flag2 = allConfigsSorted.Count > 0;
						if (flag2)
						{
							AnnouncementConfig announcementConfig = allConfigsSorted.Find((AnnouncementConfig c) => c != null && !this._state.IsRead(c.ModId));
							bool flag3 = announcementConfig != null;
							if (flag3)
							{
								this._state.SelectAnnouncement(announcementConfig.ModId, true);
							}
							else
							{
								AnnouncementConfig announcementConfig2 = allConfigsSorted.Find((AnnouncementConfig c) => c != null);
								bool flag4 = announcementConfig2 != null;
								if (flag4)
								{
									this._state.SelectAnnouncement(announcementConfig2.ModId, true);
								}
							}
						}
						MainPanel mainPanel2 = this._mainPanel;
						if (mainPanel2 != null)
						{
							mainPanel2.Show();
						}
						this._state.OpenPanel();
					}
				}
				catch (Exception ex)
				{
				}
			}
		}

		// Token: 0x0600006A RID: 106 RVA: 0x00005C10 File Offset: 0x00003E10
		private void OnAnnouncementSelected(string modId)
		{
			bool flag = !this._isInitialized || this._mainPanel == null;
			if (!flag)
			{
				this._mainPanel.UpdateContent(modId, false);
			}
		}

		// Token: 0x0600006B RID: 107 RVA: 0x00005C4C File Offset: 0x00003E4C
		private void OnPanelStateChanged()
		{
			bool flag = !this._isInitialized;
			if (!flag)
			{
				this.UpdateNotificationButton();
			}
		}

		// Token: 0x0600006C RID: 108 RVA: 0x00005C70 File Offset: 0x00003E70
		private void OnAnnouncementRead(string modId)
		{
			SummaryNotificationPanel summaryPanel = this._summaryPanel;
			if (summaryPanel != null)
			{
				summaryPanel.UpdateContent();
			}
		}

		// Token: 0x0600006D RID: 109 RVA: 0x00005C85 File Offset: 0x00003E85
		private void OnPopupShouldHide(string modId)
		{
			SummaryNotificationPanel summaryPanel = this._summaryPanel;
			if (summaryPanel != null)
			{
				summaryPanel.UpdateContent();
			}
		}

		// Token: 0x0600006E RID: 110 RVA: 0x00005C9C File Offset: 0x00003E9C
		private void OnPrevButtonClicked()
		{
			bool flag = !this._isInitialized || this._state == null;
			if (!flag)
			{
				try
				{
					string prevVersion = this._state.GetPrevVersion();
					bool flag2 = prevVersion != null;
					if (flag2)
					{
						bool flag3 = this._mainPanel != null;
						if (flag3)
						{
							this._mainPanel.UpdateContent(prevVersion, false);
						}
					}
				}
				catch (Exception ex)
				{
				}
			}
		}

		// Token: 0x0600006F RID: 111 RVA: 0x00005D18 File Offset: 0x00003F18
		private void OnNextButtonClicked()
		{
			bool flag = !this._isInitialized || this._state == null;
			if (!flag)
			{
				try
				{
					string nextVersion = this._state.GetNextVersion();
					bool flag2 = nextVersion != null;
					if (flag2)
					{
						bool flag3 = this._mainPanel != null;
						if (flag3)
						{
							this._mainPanel.UpdateContent(nextVersion, false);
						}
					}
				}
				catch (Exception ex)
				{
				}
			}
		}

		// Token: 0x06000070 RID: 112 RVA: 0x00005D94 File Offset: 0x00003F94
		private void OnFeedbackButtonClicked()
		{
			bool flag = !this._isInitialized;
			if (!flag)
			{
				try
				{
					AnnouncementState state = this._state;
					bool flag2 = ((state != null) ? state.SelectedConfig : null) != null;
					if (flag2)
					{
						Application.OpenURL("https://qm.qq.com/q/WwTcbfW266");
					}
				}
				catch (Exception arg)
				{
					Debug.LogError(string.Format("处理反馈按钮点击失败: {0}", arg));
				}
			}
		}

		// Token: 0x06000071 RID: 113 RVA: 0x00005E04 File Offset: 0x00004004
		private void OnCloseButtonClicked()
		{
			bool flag = !this._isInitialized || this._mainPanel == null || this._state == null;
			if (!flag)
			{
				try
				{
					this._mainPanel.Hide();
					this._state.ClosePanel();
				}
				catch (Exception arg)
				{
					Debug.LogError(string.Format("处理关闭按钮点击失败: {0}", arg));
				}
			}
		}

		// Token: 0x06000072 RID: 114 RVA: 0x00005E80 File Offset: 0x00004080
		public void RefreshAnnouncements()
		{
			bool flag = !this._isInitialized || this._state == null;
			if (flag)
			{
				Debug.LogWarning("UIManager: 未初始化，无法刷新");
			}
			else
			{
				base.StartCoroutine(this.RefreshAnnouncementsCoroutine());
			}
		}

		// Token: 0x06000073 RID: 115 RVA: 0x00005EC1 File Offset: 0x000040C1
		private IEnumerator RefreshAnnouncementsCoroutine()
		{
			UIManager.<RefreshAnnouncementsCoroutine>d__27 <RefreshAnnouncementsCoroutine>d__ = new UIManager.<RefreshAnnouncementsCoroutine>d__27(0);
			<RefreshAnnouncementsCoroutine>d__.<>4__this = this;
			return <RefreshAnnouncementsCoroutine>d__;
		}

		// Token: 0x06000074 RID: 116 RVA: 0x00005ED0 File Offset: 0x000040D0
		private void UpdateNotificationButton()
		{
			bool flag = !this._isInitialized || this._notificationButton == null || !this._notificationButton.IsInitialized || this._state == null;
			if (!flag)
			{
				try
				{
					int unreadCount = this._state.UnreadCount;
					bool allRead = this._state.AllRead;
					if (allRead)
					{
						this._notificationButton.HideButton();
						Debug.Log("全部已读，隐藏通知按钮");
					}
					else
					{
						this._notificationButton.ShowButton();
						this._notificationButton.UpdateUnreadIndicator(unreadCount);
						bool flag2 = unreadCount > 0;
						if (flag2)
						{
							Debug.Log(string.Format("通知按钮更新: {0} 个未读公告", unreadCount));
						}
					}
				}
				catch (Exception arg)
				{
					Debug.LogError(string.Format("更新通知按钮失败: {0}", arg));
				}
			}
		}

		// Token: 0x06000075 RID: 117 RVA: 0x00005FB4 File Offset: 0x000041B4
		public void CheckAndShowUpdatePopup()
		{
			bool flag = !this._isInitialized || this._state == null;
			if (flag)
			{
				Debug.Log("UIManager: 未初始化，跳过更新检查");
			}
			else
			{
				try
				{
					List<AnnouncementConfig> list = new List<AnnouncementConfig>();
					List<AnnouncementConfig> list2 = new List<AnnouncementConfig>();
					List<AnnouncementConfig> allConfigsSorted = this._state.GetAllConfigsSorted();
					foreach (AnnouncementConfig announcementConfig in allConfigsSorted)
					{
						bool flag2 = announcementConfig.HasPermanentUpdate && !this._state.IsRead(announcementConfig.ModId);
						if (flag2)
						{
							list.Add(announcementConfig);
						}
						else
						{
							bool flag3 = !announcementConfig.HasPermanentUpdate && !this._state.IsRead(announcementConfig.ModId);
							if (flag3)
							{
								list2.Add(announcementConfig);
							}
						}
					}
					List<AnnouncementConfig> list3 = new List<AnnouncementConfig>();
					list3.AddRange(list);
					list3.AddRange(list2);
					bool flag4 = list3.Count > 0;
					if (flag4)
					{
						this.CreateUpdateNotificationPopups(list3);
						SummaryNotificationPanel summaryPanel = this._summaryPanel;
						if (summaryPanel != null)
						{
							summaryPanel.UpdateContent();
						}
						this.UpdateNotificationButton();
					}
					else
					{
						this.CleanupUpdatePopups();
						SummaryNotificationPanel summaryPanel2 = this._summaryPanel;
						if (summaryPanel2 != null)
						{
							summaryPanel2.UpdateContent();
						}
					}
				}
				catch (Exception ex)
				{
				}
			}
		}

		// Token: 0x06000076 RID: 118 RVA: 0x00006144 File Offset: 0x00004344
		private bool ShouldPopupBeVisible(AnnouncementConfig config, string modId)
		{
			bool result;
			try
			{
				bool flag = config == null || this._state == null;
				if (flag)
				{
					result = false;
				}
				else
				{
					bool flag2 = this._state.IsRead(modId);
					if (flag2)
					{
						result = false;
					}
					else
					{
						bool hasPermanentUpdate = config.HasPermanentUpdate;
						if (hasPermanentUpdate)
						{
							result = true;
						}
						else
						{
							bool flag3 = this._state.IsPopupHidden(modId);
							bool flag4 = !flag3;
							if (flag4)
							{
								result = true;
							}
							else
							{
								result = false;
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000077 RID: 119 RVA: 0x000061CC File Offset: 0x000043CC
		private bool CreateUpdateNotificationPopups(List<AnnouncementConfig> updateConfigs)
		{
			bool result;
			try
			{
				this.CleanupUpdatePopups();
				List<AnnouncementConfig> list = (from config in updateConfigs
				where this.ShouldPopupBeVisible(config, config.ModId)
				select config into c
				orderby c.HasPermanentUpdate ? 0 : 1
				select c).ToList<AnnouncementConfig>();
				for (int i = 0; i < list.Count; i++)
				{
					AnnouncementConfig announcementConfig = list[i];
					bool flag = !this.ShouldPopupBeVisible(announcementConfig, announcementConfig.ModId);
					if (!flag)
					{
						UpdateNotificationPopup updateNotificationPopup = base.gameObject.AddComponent<UpdateNotificationPopup>();
						updateNotificationPopup.Initialize(announcementConfig, this._state, this._uiRoot, this._animator, i);
						this._updatePopups.Add(updateNotificationPopup);
						bool popupsVisible = this._popupsVisible;
						if (popupsVisible)
						{
							updateNotificationPopup.Show();
						}
						else
						{
							updateNotificationPopup.Hide();
						}
					}
				}
				Debug.Log(string.Format("创建弹窗: 版本更新{0}个, 未读公告{1}个", list.Count((AnnouncementConfig c) => c.HasPermanentUpdate), list.Count((AnnouncementConfig c) => !c.HasPermanentUpdate)));
				result = true;
			}
			catch (Exception ex)
			{
				this.CleanupUpdatePopups();
				result = false;
			}
			return result;
		}

		// Token: 0x06000078 RID: 120 RVA: 0x00006348 File Offset: 0x00004548
		private void CleanupUpdatePopups()
		{
			try
			{
				foreach (UpdateNotificationPopup updateNotificationPopup in this._updatePopups)
				{
					bool flag = updateNotificationPopup != null;
					if (flag)
					{
						updateNotificationPopup.Cleanup();
					}
				}
				this._updatePopups.Clear();
				UpdateNotificationPopup.CleanupAll();
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x06000079 RID: 121 RVA: 0x000063D4 File Offset: 0x000045D4
		public void OpenAnnouncementFromPopup(string modId)
		{
			bool flag = !this._isInitialized || this._state == null;
			if (!flag)
			{
				try
				{
					this._state.SelectAnnouncement(modId, true);
					bool flag2 = this._mainPanel != null && !this._state.IsPanelOpen;
					if (flag2)
					{
						this._mainPanel.Show();
						this._state.OpenPanel();
					}
				}
				catch (Exception ex)
				{
				}
			}
		}

		// Token: 0x0600007A RID: 122 RVA: 0x00006464 File Offset: 0x00004664
		private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
		{
			try
			{
				UpdateNotificationPopup.RearrangeAllPopups();
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x0600007B RID: 123 RVA: 0x00006494 File Offset: 0x00004694
		public void HideMainPanelOnly()
		{
			try
			{
				MainPanel mainPanel = this._mainPanel;
				if (mainPanel != null)
				{
					mainPanel.Hide();
				}
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x0600007C RID: 124 RVA: 0x000064D0 File Offset: 0x000046D0
		public void Cleanup()
		{
			try
			{
				this.UnsubscribeFromEvents();
				NotificationButton notificationButton = this._notificationButton;
				if (notificationButton != null)
				{
					notificationButton.Cleanup();
				}
				MainPanel mainPanel = this._mainPanel;
				if (mainPanel != null)
				{
					mainPanel.Cleanup();
				}
				this.CleanupUpdatePopups();
				SummaryNotificationPanel summaryPanel = this._summaryPanel;
				if (summaryPanel != null)
				{
					summaryPanel.Cleanup();
				}
				this._notificationButton = null;
				this._mainPanel = null;
				this._updatePopups.Clear();
				this._summaryPanel = null;
				this._state = null;
				this._animator = null;
				this._uiRoot = null;
				this._isInitialized = false;
				this._popupsVisible = true;
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x04000011 RID: 17
		private AnnouncementState _state;

		// Token: 0x04000012 RID: 18
		private UIAnimator _animator;

		// Token: 0x04000013 RID: 19
		private NotificationButton _notificationButton;

		// Token: 0x04000014 RID: 20
		private MainPanel _mainPanel;

		// Token: 0x04000015 RID: 21
		private List<UpdateNotificationPopup> _updatePopups = new List<UpdateNotificationPopup>();

		// Token: 0x04000016 RID: 22
		private SummaryNotificationPanel _summaryPanel;

		// Token: 0x04000017 RID: 23
		private Transform _uiRoot;

		// Token: 0x04000018 RID: 24
		private bool _isInitialized = false;

		// Token: 0x04000019 RID: 25
		private bool _popupsVisible = true;
	}
}
