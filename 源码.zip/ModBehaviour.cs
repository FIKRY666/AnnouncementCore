﻿using UnityEngine;

namespace AnnouncementCore
{
    public class ModBehaviour : Duckov.Modding.ModBehaviour
    {
        private void OnEnable()
        {
            try
            {
                AnnouncementCore.Core.AnnouncementManager.WakeUp();
            }
            catch (System.Exception e)
            {
                Debug.LogError($"AnnouncementCore启用异常: {e}");
            }
        }

        private void OnDisable()
        {
            try
            {
            }
            catch (System.Exception e)
            {
                Debug.LogError($"AnnouncementCore禁用异常: {e}");
            }
        }
    }
}