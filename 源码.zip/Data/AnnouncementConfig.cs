﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Networking;

namespace AnnouncementCore.Data
{
    [Serializable]
    public class ApiModListItem
    {
        public string id;
        public string name;
    }

    [Serializable]
    public class ApiAnnouncementData
    {
        public string id;
        public string modId;
        public string title;
        public string content_html;
        public string content_text;
        public string author;
        public long timestamp;
        public string version;
    }

    [Serializable]
    public class AnnouncementConfig
    {
        public string ModId;
        public string DisplayName;
        public string Version = "1.0.0";
        public string Author;
        public string SteamWorkshopId;
        public bool AutoShowUpdates = true;

        [NonSerialized] public string ModDirectory;
        [NonSerialized] public string ChangelogContent;

        [NonSerialized] public List<ApiAnnouncementData> ApiAnnouncements = new List<ApiAnnouncementData>();
        [NonSerialized] public DateTime LastApiFetchTime = DateTime.MinValue;
        [NonSerialized] public bool IsFetchingApi = false;

        public string FeedbackUrl;

        private const int CACHE_DURATION_MINUTES = 10;
        private const string API_BASE_URL = "https://duckov.guducat.cc/api";

        public bool HasNewVersionAvailable => HasPermanentUpdate;
        public string LatestVersion => GetLatestVersion();
        public string SteamWorkshopUrl => !string.IsNullOrEmpty(SteamWorkshopId)
            ? $"https://steamcommunity.com/sharedfiles/filedetails/?id={SteamWorkshopId}"
            : null;

        public static AnnouncementConfig LoadFromFolder(string modFolderPath)
        {
            try
            {
                var config = LoadFromInfoIni(modFolderPath) ?? LoadFromAnnouncementConfigJson(modFolderPath);
                if (config == null) return null;

                config.ModDirectory = modFolderPath;
                config.LoadLocalChangelog();
                return config;
            }
            catch (Exception e)
            {
                Debug.LogError($"加载配置失败 {modFolderPath}: {e}");
                return null;
            }
        }

        private void LoadLocalChangelog()
        {
            try
            {
                string changelogPath = Path.Combine(ModDirectory, "changelog.md");
                if (File.Exists(changelogPath))
                {
                    ChangelogContent = File.ReadAllText(changelogPath);
                }
            }
            catch (Exception e)
            {
                Debug.LogWarning($"加载本地changelog失败: {e}");
            }
        }

        private static AnnouncementConfig LoadFromInfoIni(string modFolderPath)
        {
            try
            {
                string iniPath = Path.Combine(modFolderPath, "info.ini");
                if (!File.Exists(iniPath)) return null;

                var config = new AnnouncementConfig();
                string[] lines = File.ReadAllLines(iniPath);

                foreach (string line in lines)
                {
                    if (string.IsNullOrWhiteSpace(line) || line.Trim().StartsWith(";") || line.Trim().StartsWith("#"))
                        continue;

                    int equalsIndex = line.IndexOf('=');
                    if (equalsIndex <= 0) continue;

                    string key = line.Substring(0, equalsIndex).Trim().ToLower();
                    string value = line.Substring(equalsIndex + 1).Trim();

                    if (value.StartsWith("\"") && value.EndsWith("\""))
                    {
                        value = value.Substring(1, value.Length - 2);
                    }

                    ParseIniKeyValue(config, key, value);
                }

                if (string.IsNullOrEmpty(config.ModId)) return null;
                if (string.IsNullOrEmpty(config.DisplayName)) config.DisplayName = config.ModId;

                return config;
            }
            catch (Exception e)
            {
                Debug.LogError($"读取 info.ini 失败: {e}");
                return null;
            }
        }

        private static void ParseIniKeyValue(AnnouncementConfig config, string key, string value)
        {
            switch (key)
            {
                case "name": config.ModId = value; break;
                case "displayname": config.DisplayName = value; break;
                case "description": if (string.IsNullOrEmpty(config.Author)) config.Author = value; break;
                case "publishedfileid": config.SteamWorkshopId = value; break;
                case "version": config.Version = value; break;
                case "author": config.Author = value; break;
                case "feedbackurl": config.FeedbackUrl = value; break;
            }
        }

        private static AnnouncementConfig LoadFromAnnouncementConfigJson(string modFolderPath)
        {
            try
            {
                string configPath = Path.Combine(modFolderPath, "announcement_config.json");
                if (!File.Exists(configPath)) return null;

                string json = File.ReadAllText(configPath);
                return JsonUtility.FromJson<AnnouncementConfig>(json);
            }
            catch (Exception e)
            {
                Debug.LogError($"读取 JSON 配置失败: {e}");
                return null;
            }
        }

        public async Task FetchAnnouncementsFromApiAsync()
        {
            if (IsFetchingApi || (DateTime.Now - LastApiFetchTime).TotalMinutes < CACHE_DURATION_MINUTES)
                return;

            if (string.IsNullOrEmpty(ModId)) return;

            IsFetchingApi = true;

            try
            {
                string url = $"{API_BASE_URL}/public/list?modId={UnityWebRequest.EscapeURL(ModId)}";
                using (UnityWebRequest webRequest = UnityWebRequest.Get(url))
                {
                    webRequest.timeout = 15;
                    var operation = webRequest.SendWebRequest();

                    var cancellationToken = new System.Threading.CancellationTokenSource(TimeSpan.FromSeconds(20));

                    while (!operation.isDone && !cancellationToken.Token.IsCancellationRequested)
                    {
                        await Task.Delay(100);
                    }

                    if (cancellationToken.Token.IsCancellationRequested)
                    {
                        Debug.LogWarning($"API 请求超时: {url}");
                        return;
                    }

                    if (webRequest.result == UnityWebRequest.Result.Success)
                    {
                        string responseText = webRequest.downloadHandler.text;

                        if (TryParseAnnouncementJson(responseText, out var announcementList))
                        {
                            ApiAnnouncements = announcementList;
                            ApiAnnouncements.Sort((a, b) => b.timestamp.CompareTo(a.timestamp));
                            LastApiFetchTime = DateTime.Now;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"获取 API 公告异常: {ex.Message}");
            }
            finally
            {
                IsFetchingApi = false;
            }
        }

        public bool HasPermanentUpdate
        {
            get
            {
                try
                {
                    if (ApiAnnouncements == null || ApiAnnouncements.Count == 0)
                        return false;

                    var latestAnnouncement = ApiAnnouncements[0];
                    if (string.IsNullOrEmpty(latestAnnouncement.version))
                        return false;

                    return IsNewerVersion(latestAnnouncement.version, Version);
                }
                catch (Exception e)
                {
                    Debug.LogError($"计算HasPermanentUpdate失败: {e}");
                    return false;
                }
            }
        }

        public string GetLatestCloudVersion()
        {
            if (ApiAnnouncements == null || ApiAnnouncements.Count == 0) return Version;
            var latestAnnouncement = ApiAnnouncements[0];
            return !string.IsNullOrEmpty(latestAnnouncement.version)
                ? latestAnnouncement.version
                : Version;
        }

        private string GetLatestVersion()
        {
            if (ApiAnnouncements == null || ApiAnnouncements.Count == 0) return Version;

            var latestAnnouncement = ApiAnnouncements[0];
            return !string.IsNullOrEmpty(latestAnnouncement.version)
                ? latestAnnouncement.version
                : Version;
        }

        private bool IsNewerVersion(string version1, string version2)
        {
            try
            {
                string v1 = version1.Trim().TrimStart('v', 'V', ' ');
                string v2 = version2.Trim().TrimStart('v', 'V', ' ');

                if (string.IsNullOrEmpty(v1) || string.IsNullOrEmpty(v2)) return false;

                var parts1 = v1.Split('.');
                var parts2 = v2.Split('.');
                int maxLength = Math.Max(parts1.Length, parts2.Length);

                for (int i = 0; i < maxLength; i++)
                {
                    int part1 = (i < parts1.Length && int.TryParse(parts1[i], out int p1)) ? p1 : 0;
                    int part2 = (i < parts2.Length && int.TryParse(parts2[i], out int p2)) ? p2 : 0;

                    if (part1 > part2) return true;
                    if (part1 < part2) return false;
                }

                return false;
            }
            catch
            {
                return string.Compare(version1, version2, StringComparison.OrdinalIgnoreCase) > 0;
            }
        }

        public string GetDisplayContent()
        {
            if (ApiAnnouncements != null && ApiAnnouncements.Count > 0)
            {
                var latestAnnouncement = ApiAnnouncements[0];
                if (!string.IsNullOrWhiteSpace(latestAnnouncement.content_text))
                    return latestAnnouncement.content_text;
                if (!string.IsNullOrWhiteSpace(latestAnnouncement.content_html))
                    return latestAnnouncement.content_html;
            }

            if (!string.IsNullOrWhiteSpace(ChangelogContent))
                return ChangelogContent;

            return "暂无更新内容";
        }

        private bool TryParseAnnouncementJson(string json, out List<ApiAnnouncementData> announcementList)
        {
            announcementList = new List<ApiAnnouncementData>();

            try
            {
                string cleanJson = json.Replace("\n", "").Replace("\r", "").Replace("\t", "").Replace(" ", "");
                if (!cleanJson.Contains("\"success\":true")) return false;

                int dataStart = cleanJson.IndexOf("\"data\":[");
                if (dataStart < 0) return false;

                dataStart += 8;
                int dataEnd = cleanJson.IndexOf("]", dataStart);
                if (dataEnd < 0) return false;

                string dataArray = cleanJson.Substring(dataStart, dataEnd - dataStart);
                if (string.IsNullOrWhiteSpace(dataArray) || dataArray == "}") return true;

                var items = dataArray.Split(new[] { "},{" }, StringSplitOptions.RemoveEmptyEntries);

                foreach (var item in items)
                {
                    string cleanItem = item.Trim('{', '}', ' ', '\r', '\n', '\t');
                    if (string.IsNullOrWhiteSpace(cleanItem)) continue;

                    var announcement = ParseAnnouncementItem(cleanItem);
                    if (announcement != null) announcementList.Add(announcement);
                }

                return true;
            }
            catch (Exception ex)
            {
                Debug.LogError($"解析公告JSON失败: {ex.Message}");
                return false;
            }
        }

        private ApiAnnouncementData ParseAnnouncementItem(string jsonObject)
        {
            try
            {
                string id = ExtractJsonValue(jsonObject, "id");
                string modId = ExtractJsonValue(jsonObject, "modId");

                if (string.IsNullOrEmpty(id) || string.IsNullOrEmpty(modId))
                {
                    return null;
                }

                string title = ExtractJsonValue(jsonObject, "title");
                string content_html = ExtractJsonValue(jsonObject, "content_html");
                string content_text = ExtractJsonValue(jsonObject, "content_text");
                string author = ExtractJsonValue(jsonObject, "author");
                string version = ExtractJsonValue(jsonObject, "version");

                return new ApiAnnouncementData
                {
                    id = id,
                    modId = modId,
                    title = title,
                    content_html = content_html,
                    content_text = content_text,
                    author = author,
                    timestamp = long.TryParse(ExtractJsonValue(jsonObject, "timestamp"), out long ts) ? ts : 0,
                    version = version
                };
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        private string ExtractJsonValue(string jsonObject, string key)
        {
            try
            {
                string searchString = $"\"{key}\":\"";
                int start = jsonObject.IndexOf(searchString);

                if (start >= 0)
                {
                    start += searchString.Length;

                    int end = start;
                    bool inEscape = false;

                    while (end < jsonObject.Length)
                    {
                        char c = jsonObject[end];

                        if (inEscape)
                        {
                            inEscape = false;
                        }
                        else if (c == '\\')
                        {
                            inEscape = true;
                        }
                        else if (c == '"')
                        {
                            break;
                        }

                        end++;
                    }

                    if (end < jsonObject.Length)
                    {
                        string value = jsonObject.Substring(start, end - start);
                        value = DecodeJsonString(value);
                        return value;
                    }
                }

                searchString = $"\"{key}\":";
                start = jsonObject.IndexOf(searchString);
                if (start < 0) return null;

                start += searchString.Length;

                int endPos = jsonObject.Length;
                int endComma = jsonObject.IndexOf(",", start);
                int endBrace = jsonObject.IndexOf("}", start);
                int endBracket = jsonObject.IndexOf("]", start);

                if (endComma >= 0) endPos = Math.Min(endPos, endComma);
                if (endBrace >= 0) endPos = Math.Min(endPos, endBrace);
                if (endBracket >= 0) endPos = Math.Min(endPos, endBracket);

                if (endPos == jsonObject.Length) return null;

                string rawValue = jsonObject.Substring(start, endPos - start).Trim();

                if (rawValue.StartsWith("\"") && rawValue.EndsWith("\""))
                {
                    rawValue = rawValue.Substring(1, rawValue.Length - 2);
                    rawValue = DecodeJsonString(rawValue);
                }

                return rawValue;
            }
            catch
            {
                return null;
            }
        }

        private string DecodeJsonString(string jsonString)
        {
            if (string.IsNullOrEmpty(jsonString))
                return jsonString;

            try
            {
                string result = jsonString
                    .Replace("\\\"", "\"")
                    .Replace("\\\\", "\\")
                    .Replace("\\/", "/")
                    .Replace("\\b", "\b")
                    .Replace("\\f", "\f")
                    .Replace("\\n", "\n")
                    .Replace("\\r", "\r")
                    .Replace("\\t", "\t");

                result = Regex.Replace(result, @"\\u([0-9a-fA-F]{4})", match =>
                {
                    try
                    {
                        string hex = match.Groups[1].Value;
                        int unicodeValue = Convert.ToInt32(hex, 16);
                        return char.ConvertFromUtf32(unicodeValue);
                    }
                    catch
                    {
                        return match.Value;
                    }
                });

                return result;
            }
            catch
            {
                return jsonString;
            }
        }

        public override string ToString() => $"{DisplayName} ({ModId}) v{Version}";
    }
}