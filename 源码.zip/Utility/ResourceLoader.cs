﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;

namespace AnnouncementCore.Utility
{
    public static class ResourceLoader
    {
        private static readonly Dictionary<string, Sprite> _spriteCache = new Dictionary<string, Sprite>();

        public static Sprite LoadSprite(string resourceName)
        {
            try
            {
                if (_spriteCache.TryGetValue(resourceName, out var cachedSprite))
                    return cachedSprite;

                var assembly = Assembly.GetExecutingAssembly();

                foreach (var res in assembly.GetManifestResourceNames())
                {
                    if (res.Contains(resourceName))
                    {
                        using (Stream stream = assembly.GetManifestResourceStream(res))
                        {
                            if (stream == null) continue;

                            byte[] buffer = new byte[stream.Length];
                            stream.Read(buffer, 0, buffer.Length);

                            Texture2D texture = new Texture2D(2, 2);
                            if (!texture.LoadImage(buffer)) continue;

                            Sprite sprite = Sprite.Create(texture,
                                new Rect(0, 0, texture.width, texture.height),
                                new Vector2(0.5f, 0.5f), 100f);

                            _spriteCache[resourceName] = sprite;
                            return sprite;
                        }
                    }
                }

                Debug.LogWarning($"找不到资源: {resourceName}");
                return null;
            }
            catch (Exception e)
            {
                Debug.LogError($"加载资源失败: {resourceName}, 错误: {e.Message}");
                return null;
            }
        }

        public static void PreloadSprites()
        {
            string[] requiredSprites = new string[]
                {
                    "panel_background",
                    "sidebar_bg",
                    "content_bg",
                    "info_bg",
                    "close_button",
                    "refresh_button",
                    "prev_button",
                    "next_button",
                    "feedback_button",
                    "left_arrow",
                    "right_arrow",
                    "update_popup_steam_bg2",
                    "list_item_normal",
                    "list_item_selected",
                    "list_item_unread",
                    "update_popup_background",
                    "update_popup_announcement_bg",
                    "update_popup_steam_bg",
                    "update_popup_btn_bg",
                    "notification_badge",
                    "notification_button",
                    "update_panel_bg",
                    "panel_collapse",
                    "panel_expand",
                    "panel_empty"
                };

            foreach (var spriteName in requiredSprites)
            {
                LoadSprite(spriteName);
            }
        }

        public static void ClearCache() => _spriteCache.Clear();
    }
}