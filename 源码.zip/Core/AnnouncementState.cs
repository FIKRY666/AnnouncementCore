﻿using AnnouncementCore.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace AnnouncementCore
{
    public class AnnouncementState
    {
        public static event Action<string> OnAnnouncementSelected;
        public static event Action<string> OnAnnouncementRead;
        public static event Action OnUnreadStatusChanged;
        public static event Action OnPanelStateChanged;
        public static event Action<string> OnPopupShouldHide;

        private readonly Dictionary<string, AnnouncementConfig> _configs;
        private readonly Dictionary<string, string> _readVersions;
        private readonly HashSet<string> _popupShownIds;
        private readonly HashSet<string> _readModIds;
        private string _selectedModId;
        private bool _isPanelOpen = false;
        private Dictionary<string, int> _currentAnnouncementIndex = new Dictionary<string, int>();
        private HashSet<string> _hiddenPopupIds = new HashSet<string>();

        public AnnouncementState(Dictionary<string, AnnouncementConfig> configs)
        {
            try
            {
                _configs = configs ?? new Dictionary<string, AnnouncementConfig>();
                _readVersions = new Dictionary<string, string>();
                _popupShownIds = new HashSet<string>();

                ValidateConfigs();
                LoadReadStatus();
                LoadPopupStatus();
            }
            catch (Exception e)
            {
                Debug.LogError($"AnnouncementState 初始化失败: {e}");
                _configs = new Dictionary<string, AnnouncementConfig>();
                _readVersions = new Dictionary<string, string>();
                _popupShownIds = new HashSet<string>();
            }
        }

        public void MarkPopupAsHidden(string modId)
        {
            try
            {
                if (string.IsNullOrEmpty(modId)) return;

                var config = GetConfigById(modId);
                if (config == null) return;

                if (!config.HasPermanentUpdate)
                {
                    _hiddenPopupIds.Add(modId);

                    if (!_popupShownIds.Contains(modId))
                    {
                        _popupShownIds.Add(modId);
                    }

                    SavePopupStatus();
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"标记弹窗隐藏失败: {e}");
            }
        }

        public bool IsPopupHidden(string modId)
        {
            try
            {
                return !string.IsNullOrEmpty(modId) && _hiddenPopupIds.Contains(modId);
            }
            catch (Exception e)
            {
                Debug.LogError($"检查弹窗隐藏状态失败: {e}");
                return false;
            }
        }

        public bool ShouldShowPopup(string modId)
        {
            try
            {
                if (string.IsNullOrEmpty(modId) || !_configs.ContainsKey(modId))
                    return false;

                var config = _configs[modId];
                if (config == null) return false;

                if (IsPopupHidden(modId))
                {
                    return false;
                }

                if (config.HasPermanentUpdate && !IsRead(modId))
                {
                    return true;
                }

                if (!config.HasPermanentUpdate && !IsRead(modId) && !_popupShownIds.Contains(modId))
                {
                    return true;
                }

                return false;
            }
            catch (Exception e)
            {
                Debug.LogError($"ShouldShowPopup异常: {e}");
                return false;
            }
        }

        private void SavePopupStatus()
        {
            try
            {
                string popupShownJson = string.Join(";", _popupShownIds);
                PlayerPrefs.SetString("Announcement_PopupShown", popupShownJson);

                string hiddenPopupJson = string.IsNullOrEmpty(popupShownJson) ? "" : string.Join(";", _hiddenPopupIds);
                PlayerPrefs.SetString("Announcement_HiddenPopups", hiddenPopupJson);

                PlayerPrefs.Save();
            }
            catch (Exception e)
            {
                Debug.LogError($"保存弹窗状态失败: {e}");
            }
        }

        private void LoadPopupStatus()
        {
            try
            {
                string popupShownJson = PlayerPrefs.GetString("Announcement_PopupShown", "");
                if (!string.IsNullOrEmpty(popupShownJson))
                {
                    var ids = popupShownJson.Split(';');
                    foreach (var id in ids)
                    {
                        if (!string.IsNullOrEmpty(id))
                            _popupShownIds.Add(id);
                    }
                }

                string hiddenPopupJson = PlayerPrefs.GetString("Announcement_HiddenPopups", "");
                if (!string.IsNullOrEmpty(hiddenPopupJson))
                {
                    var ids = hiddenPopupJson.Split(';');
                    foreach (var id in ids)
                    {
                        if (!string.IsNullOrEmpty(id))
                            _hiddenPopupIds.Add(id);
                    }
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"加载弹窗状态失败: {e}");
            }
        }

        private void ValidateConfigs()
        {
            if (_configs == null) return;

            var invalidKeys = new List<string>();

            foreach (var kvp in _configs)
            {
                if (kvp.Value == null || string.IsNullOrEmpty(kvp.Value.ModId))
                {
                    invalidKeys.Add(kvp.Key);
                }
            }

            foreach (var key in invalidKeys)
            {
                _configs.Remove(key);
            }

            if (invalidKeys.Count > 0)
            {
            }
        }

        public void ClearPopupStatus()
        {
            try
            {
                _popupShownIds.Clear();
            }
            catch (Exception e)
            {
                Debug.LogError($"清理弹窗状态失败: {e}");
            }
        }

        public string SelectedModId => _selectedModId;
        public AnnouncementConfig SelectedConfig =>
            _selectedModId != null && _configs.ContainsKey(_selectedModId) ? _configs[_selectedModId] : null;

        public bool HasUnread
        {
            get
            {
                try
                {
                    if (_configs == null || _configs.Count == 0) return false;

                    foreach (var id in _configs.Keys)
                    {
                        if (string.IsNullOrEmpty(id)) continue;

                        if (!IsRead(id))
                        {
                            return true;
                        }
                    }
                    return false;
                }
                catch (Exception e)
                {
                    Debug.LogError($"HasUnread 属性异常: {e}");
                    return false;
                }
            }
        }

        public int UnreadCount
        {
            get
            {
                try
                {
                    if (_configs == null || _configs.Count == 0) return 0;

                    int count = 0;
                    foreach (var id in _configs.Keys)
                    {
                        if (string.IsNullOrEmpty(id)) continue;

                        if (!IsRead(id))
                        {
                            count++;
                        }
                    }
                    return count;
                }
                catch (Exception e)
                {
                    Debug.LogError($"UnreadCount 属性异常: {e}");
                    return 0;
                }
            }
        }

        public bool AllRead
        {
            get
            {
                try
                {
                    if (_configs == null || _configs.Count == 0) return true;

                    foreach (var kvp in _configs)
                    {
                        string modId = kvp.Key;
                        var config = kvp.Value;
                        if (config == null) continue;

                        if (config.HasPermanentUpdate)
                        {
                            return false;
                        }

                        if (!IsRead(modId))
                        {
                            return false;
                        }
                    }

                    return true;
                }
                catch (Exception e)
                {
                    Debug.LogError($"AllRead 属性异常: {e}");
                    return true;
                }
            }
        }

        public int TotalCount => _configs.Count;
        public bool IsPanelOpen => _isPanelOpen;

        public List<AnnouncementConfig> GetAllConfigsSorted()
        {
            try
            {
                if (_configs == null || _configs.Count == 0)
                    return new List<AnnouncementConfig>();

                return _configs.Values
                    .Where(config => config != null)
                    .OrderBy(config =>
                    {
                        try
                        {
                            return IsRead(config.ModId) ? 1 : 0;
                        }
                        catch (Exception e)
                        {
                            Debug.LogError($"排序时检查已读状态失败: {e.Message}");
                            return 1;
                        }
                    })
                    .ThenBy(config =>
                    {
                        return config?.DisplayName ?? string.Empty;
                    })
                    .ToList();
            }
            catch (Exception e)
            {
                Debug.LogError($"获取排序配置列表失败: {e.Message}");
                return new List<AnnouncementConfig>();
            }
        }

        public AnnouncementConfig GetConfigById(string modId)
        {
            try
            {
                if (string.IsNullOrEmpty(modId) || _configs == null || !_configs.ContainsKey(modId))
                    return null;

                return _configs[modId];
            }
            catch (Exception e)
            {
                Debug.LogError($"GetConfigById异常: {e}");
                return null;
            }
        }

        public List<AnnouncementConfig> GetPopupConfigs()
        {
            try
            {
                var popupConfigs = new List<AnnouncementConfig>();

                if (_configs == null) return popupConfigs;

                var permanentUpdates = GetPermanentUpdateConfigs();
                popupConfigs.AddRange(permanentUpdates);

                var unreadConfigs = GetUnreadConfigs();
                foreach (var config in unreadConfigs)
                {
                    if (!popupConfigs.Any(c => c.ModId == config.ModId))
                    {
                        popupConfigs.Add(config);
                    }
                }

                return popupConfigs;
            }
            catch (Exception e)
            {
                Debug.LogError($"GetPopupConfigs 异常: {e}");
                return new List<AnnouncementConfig>();
            }
        }

        private List<AnnouncementConfig> GetPermanentUpdateConfigs()
        {
            var result = new List<AnnouncementConfig>();

            foreach (var kvp in _configs)
            {
                var config = kvp.Value;
                if (config == null) continue;

                if (config.HasPermanentUpdate)
                {
                    result.Add(config);
                }
            }

            return result;
        }

        private List<AnnouncementConfig> GetUnreadConfigs()
        {
            var result = new List<AnnouncementConfig>();

            foreach (var kvp in _configs)
            {
                string modId = kvp.Key;
                var config = kvp.Value;
                if (config == null) continue;

                bool alreadyShown = _popupShownIds.Contains(modId);

                if (!config.HasPermanentUpdate && !IsRead(modId) && !alreadyShown)
                {
                    result.Add(config);
                    _popupShownIds.Add(modId);
                }
            }

            return result;
        }

        private bool ShouldShowPopup(AnnouncementConfig config, AnnouncementState state)
        {
            try
            {
                if (config == null || state == null)
                {
                    return false;
                }

                if (config.HasPermanentUpdate)
                {
                    return true;
                }

                bool isUnread = !state.IsRead(config.ModId);

                if (isUnread)
                {
                    return true;
                }

                return false;
            }
            catch (Exception e)
            {
                Debug.LogError($"ShouldShowPopup 异常: {e}");
                return false;
            }
        }

        public void SelectAnnouncement(string modId, bool autoMarkRead = true)
        {
            try
            {
                if (string.IsNullOrEmpty(modId) || _configs == null || !_configs.ContainsKey(modId))
                {
                    return;
                }

                var config = _configs[modId];
                if (config == null)
                {
                    return;
                }

                if (_configs.ContainsKey(modId))
                {
                    _currentAnnouncementIndex[modId] = 0;
                }

                if (!_configs.ContainsKey(modId)) return;

                _selectedModId = modId;
                OnAnnouncementSelected?.Invoke(modId);

                if (autoMarkRead && !IsRead(modId))
                {
                    MarkAsRead(modId);
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"SelectAnnouncement 异常: {e}");
            }
        }

        public void MarkAsRead(string modId, string version = null)
        {
            try
            {
                if (string.IsNullOrEmpty(modId) || !_configs.ContainsKey(modId)) return;

                var config = _configs[modId];
                if (config == null) return;

                string versionToMark = version ?? config.Version;
                string latestCloudVersion = config.GetLatestCloudVersion();

                if (!string.Equals(config.Version, latestCloudVersion, StringComparison.OrdinalIgnoreCase))
                {
                    _popupShownIds.Remove(modId);
                    return;
                }

                int currentIndex = GetCurrentAnnouncementIndex(modId);
                if (config.ApiAnnouncements != null && config.ApiAnnouncements.Count > currentIndex)
                {
                    var currentAnnouncement = config.ApiAnnouncements[currentIndex];
                    if (!string.IsNullOrEmpty(currentAnnouncement.version))
                    {
                        versionToMark = currentAnnouncement.version;
                    }
                }

                _readVersions[modId] = versionToMark;
                SaveReadStatus();

                _popupShownIds.Remove(modId);

                OnAnnouncementRead?.Invoke(modId);
                OnUnreadStatusChanged?.Invoke();

                OnPopupShouldHide?.Invoke(modId);
            }
            catch (Exception e)
            {
                Debug.LogError($"MarkAsRead 异常: {e}");
            }
        }

        public void OpenPanel()
        {
            if (_isPanelOpen) return;
            _isPanelOpen = true;
            OnPanelStateChanged?.Invoke();
        }

        public void ClosePanel()
        {
            if (!_isPanelOpen) return;
            _isPanelOpen = false;
            OnPanelStateChanged?.Invoke();
        }

        public string GetNextAnnouncement()
        {
            var sorted = GetAllConfigsSorted();
            if (sorted.Count == 0) return null;

            int currentIndex = _selectedModId != null
                ? sorted.FindIndex(c => c.ModId == _selectedModId)
                : -1;

            return sorted[(currentIndex + 1) % sorted.Count].ModId;
        }

        public string GetPrevVersion()
        {
            if (_selectedModId == null || !_configs.ContainsKey(_selectedModId)) return null;

            var config = _configs[_selectedModId];
            if (config.ApiAnnouncements == null || config.ApiAnnouncements.Count <= 1) return null;

            int currentIndex = _currentAnnouncementIndex.ContainsKey(_selectedModId) ?
                _currentAnnouncementIndex[_selectedModId] : 0;

            if (currentIndex < config.ApiAnnouncements.Count - 1)
            {
                _currentAnnouncementIndex[_selectedModId] = currentIndex + 1;
                return _selectedModId;
            }
            return null;
        }

        public string GetNextVersion()
        {
            if (_selectedModId == null || !_configs.ContainsKey(_selectedModId)) return null;

            var config = _configs[_selectedModId];
            if (config.ApiAnnouncements == null || config.ApiAnnouncements.Count <= 1) return null;

            int currentIndex = _currentAnnouncementIndex.ContainsKey(_selectedModId) ?
                _currentAnnouncementIndex[_selectedModId] : 0;

            if (currentIndex > 0)
            {
                _currentAnnouncementIndex[_selectedModId] = currentIndex - 1;
                return _selectedModId;
            }
            return null;
        }

        public string GetCurrentAnnouncementTitle()
        {
            if (_selectedModId == null || !_configs.ContainsKey(_selectedModId))
                return _configs.ContainsKey(_selectedModId) ? _configs[_selectedModId].DisplayName : "";

            var config = _configs[_selectedModId];
            int currentIndex = GetCurrentAnnouncementIndex();

            if (config.ApiAnnouncements != null && config.ApiAnnouncements.Count > currentIndex)
            {
                var announcement = config.ApiAnnouncements[currentIndex];
                return !string.IsNullOrEmpty(announcement.title) ? announcement.title : config.DisplayName;
            }

            return config.DisplayName;
        }

        public int GetCurrentAnnouncementIndex(string modId = null)
        {
            modId = modId ?? _selectedModId;
            if (modId == null || !_currentAnnouncementIndex.ContainsKey(modId)) return 0;
            return _currentAnnouncementIndex[modId];
        }

        public int GetTotalAnnouncements(string modId = null)
        {
            modId = modId ?? _selectedModId;
            if (modId == null || !_configs.ContainsKey(modId)) return 0;
            return _configs[modId].ApiAnnouncements?.Count ?? 0;
        }

        public string GetCurrentAnnouncementVersion()
        {
            if (_selectedModId == null || !_configs.ContainsKey(_selectedModId))
                return _configs.ContainsKey(_selectedModId) ? _configs[_selectedModId].Version : "1.0.0";

            var config = _configs[_selectedModId];
            int currentIndex = GetCurrentAnnouncementIndex();

            if (config.ApiAnnouncements != null && config.ApiAnnouncements.Count > currentIndex)
            {
                var announcement = config.ApiAnnouncements[currentIndex];
                return !string.IsNullOrEmpty(announcement.version) ? announcement.version : config.Version;
            }

            return config.Version;
        }

        public string GetPrevAnnouncement()
        {
            var sorted = GetAllConfigsSorted();
            if (sorted.Count == 0) return null;

            int currentIndex = _selectedModId != null
                ? sorted.FindIndex(c => c.ModId == _selectedModId)
                : -1;

            int prevIndex = currentIndex - 1;
            if (prevIndex < 0) prevIndex = sorted.Count - 1;

            return sorted[prevIndex].ModId;
        }

        public bool IsRead(string modId)
        {
            try
            {
                if (string.IsNullOrEmpty(modId) || !_configs.ContainsKey(modId))
                {
                    return false;
                }

                var config = _configs[modId];
                if (config == null)
                {
                    return false;
                }

                if (config.HasPermanentUpdate)
                {
                    return false;
                }

                if (!_readVersions.ContainsKey(modId))
                    return false;

                string readVersion = _readVersions[modId];
                string currentVersion = GetCurrentAnnouncementVersionForReading(modId);

                return string.Equals(readVersion, currentVersion, StringComparison.OrdinalIgnoreCase);
            }
            catch (Exception e)
            {
                Debug.LogError($"IsRead 异常: {e}");
                return false;
            }
        }

        private string GetCurrentAnnouncementVersionForReading(string modId)
        {
            var config = _configs[modId];
            if (config == null) return config?.Version ?? "1.0.0";

            int currentIndex = GetCurrentAnnouncementIndex(modId);

            if (config.ApiAnnouncements != null && config.ApiAnnouncements.Count > currentIndex)
            {
                var announcement = config.ApiAnnouncements[currentIndex];
                if (!string.IsNullOrEmpty(announcement.version))
                {
                    return announcement.version;
                }
            }

            return config.Version;
        }

        public bool ContainsMod(string modId)
        {
            try
            {
                return !string.IsNullOrEmpty(modId) && _configs != null && _configs.ContainsKey(modId);
            }
            catch (Exception e)
            {
                Debug.LogError($"ContainsMod 异常: {e}");
                return false;
            }
        }

        private void SaveReadStatus()
        {
            try
            {
                List<string> savedKeys = new List<string>();

                foreach (var kvp in _readVersions)
                {
                    string modId = kvp.Key;
                    string version = kvp.Value;

                    if (!string.IsNullOrEmpty(modId) && !string.IsNullOrEmpty(version))
                    {
                        string key = $"Announcement_Read_{modId}";
                        PlayerPrefs.SetString(key, version);
                        savedKeys.Add(key);
                    }
                }

                PlayerPrefs.SetString("Announcement_ReadKeys", string.Join(";", savedKeys));
                PlayerPrefs.Save();
            }
            catch (Exception e)
            {
                Debug.LogError($"保存已读状态失败: {e}");
            }
        }

        private void LoadReadStatus()
        {
            try
            {
                _readVersions.Clear();

                string readKeysJson = PlayerPrefs.GetString("Announcement_ReadKeys", "");
                if (!string.IsNullOrEmpty(readKeysJson))
                {
                    string[] readKeys = readKeysJson.Split(';');

                    foreach (string key in readKeys)
                    {
                        if (string.IsNullOrEmpty(key)) continue;

                        string version = PlayerPrefs.GetString(key, "");
                        if (!string.IsNullOrEmpty(version))
                        {
                            string modId = key.Replace("Announcement_Read_", "");

                            if (_configs.ContainsKey(modId))
                            {
                                _readVersions[modId] = version;
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"加载已读状态失败: {e}");
                _readVersions.Clear();
            }
        }

        public void CleanMod(string modId)
        {
            try
            {
                if (string.IsNullOrEmpty(modId) || !_configs.ContainsKey(modId)) return;

                _configs.Remove(modId);
                _readVersions.Remove(modId);
                _popupShownIds.Remove(modId);

                string key = $"Announcement_Read_{modId}";
                PlayerPrefs.DeleteKey(key);
                PlayerPrefs.Save();

                if (_selectedModId == modId) _selectedModId = null;
            }
            catch (Exception e)
            {
                Debug.LogError($"CleanMod 异常: {e}");
            }
        }

        public void CleanAll()
        {
            foreach (var modId in _configs.Keys)
            {
                string key = $"Announcement_Read_{modId}";
                PlayerPrefs.DeleteKey(key);
            }
            PlayerPrefs.Save();

            _configs.Clear();
            _readModIds.Clear();
            _popupShownIds.Clear();
            _selectedModId = null;
        }

        public void Clear()
        {
            _readModIds.Clear();
            _popupShownIds.Clear();
            _selectedModId = null;
            _isPanelOpen = false;
        }
    }
}