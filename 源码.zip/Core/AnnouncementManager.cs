﻿using AnnouncementCore.Data;
using AnnouncementCore.UI;
using AnnouncementCore.UI.Components;
using Duckov.Modding;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;
using AnnouncementCore.Utility;
using UnityEngine.Networking;

namespace AnnouncementCore.Core
{
    [Serializable]
    public class AnnouncementManager : MonoBehaviour
    {
        private const string MANAGER_NAME = "AnnouncementCore_Manager";

        private static AnnouncementManager _instance;
        private static bool _isInitialized = false;

        private readonly Dictionary<string, AnnouncementConfig> _configs = new Dictionary<string, AnnouncementConfig>();
        private AnnouncementState _state;
        private UIManager _uiManager;

        private List<ApiModListItem> _apiModList = new List<ApiModListItem>();
        private DateTime _lastModListFetchTime = DateTime.MinValue;
        private const int MOD_LIST_CACHE_DURATION_MINUTES = 30;
        private bool _isFetchingModList = false;
        private bool _isInitializing = false;

        private float _refreshTimer = 0f;
        private const float REFRESH_INTERVAL = 600f;
        private float _updateCheckTimer = 0f;
        private const float UPDATE_CHECK_INTERVAL = 600f;
        private bool _hasAutoShownUpdates = false;

        public static void WakeUp()
        {
            try
            {
                if (_isInitialized && _instance != null)
                {
                    return;
                }

                if (_instance == null)
                {
                    var existingManager = GameObject.Find(MANAGER_NAME);
                    if (existingManager != null)
                    {
                        _instance = existingManager.GetComponent<AnnouncementManager>();
                    }
                    else
                    {
                        CreateManager();
                    }
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"AnnouncementCore唤醒失败: {e}");
            }
        }

        private static void CreateManager()
        {
            try
            {
                var managerObj = new GameObject(MANAGER_NAME);
                DontDestroyOnLoad(managerObj);
                _instance = managerObj.AddComponent<AnnouncementManager>();
            }
            catch (Exception e)
            {
                Debug.LogError($"创建管理器失败: {e}");
            }
        }

        private void Awake()
        {
            if (_instance != null && _instance != this)
            {
                Destroy(gameObject);
                return;
            }

            _instance = this;
            DontDestroyOnLoad(gameObject);
        }

        private async void Start()
        {
            try
            {
                SubscribeToEvents();
                await InitializeAsync();
            }
            catch (Exception e)
            {
                Debug.LogError($"AnnouncementManager启动失败: {e}");
            }
        }

        public async Task InitializeAsync(bool force = false)
        {
            if (_isInitialized && !force)
            {
                return;
            }

            if (_isInitializing)
            {
                return;
            }

            _isInitializing = true;

            try
            {
                bool apiSuccess = await FetchModListFromApiAsync();

                if (!apiSuccess)
                {
                }

                ScanActiveModsForAnnouncements();

                if (_configs.Count == 0)
                {
                    _isInitialized = true;
                    return;
                }

                _state = new AnnouncementState(_configs);

                _isInitialized = true;

                _ = FetchAllModAnnouncementsAsync();

                CheckAndSetupUI();
            }
            catch (Exception e)
            {
                Debug.LogError($"AnnouncementManager初始化失败: {e}");
                _isInitialized = false;
            }
            finally
            {
                _isInitializing = false;
            }
        }

        private void SubscribeToEvents()
        {
            ModManager.OnModActivated += OnModActivated;
            MainMenu.OnMainMenuAwake += OnMainMenuAwake;
            MainMenu.OnMainMenuDestroy += OnMainMenuDestroy;
        }

        private void UnsubscribeFromEvents()
        {
            ModManager.OnModActivated -= OnModActivated;
            MainMenu.OnMainMenuAwake -= OnMainMenuAwake;
            MainMenu.OnMainMenuDestroy -= OnMainMenuDestroy;
        }

        public void Initialize(bool force = false)
        {
            _ = InitializeAsync(force);
        }

        private async Task InitializeWithModListAsync()
        {
            if (_isInitializing) return;

            _isInitializing = true;

            try
            {
                bool success = await FetchModListFromApiAsync();

                if (!success || _apiModList.Count == 0)
                {
                }

                ScanActiveModsForAnnouncements();

                if (_configs.Count == 0)
                {
                    _isInitialized = true;
                    return;
                }

                _state = new AnnouncementState(_configs);

                _isInitialized = true;

                await FetchAllModAnnouncementsAsync();

                CheckAndSetupUI();
            }
            catch (Exception e)
            {
                Debug.LogError($"AnnouncementCore异步初始化失败: {e}");
                _isInitialized = false;
            }
            finally
            {
                _isInitializing = false;
            }
        }

        private void ScanActiveModsForAnnouncements()
        {
            try
            {
                _configs.Clear();

                if (_apiModList.Count == 0)
                {
                    return;
                }

                List<string> modFolders = new List<string>();

                string gameModsPath = Path.Combine(Directory.GetCurrentDirectory(), "Duckov_Data", "Mods");
                if (Directory.Exists(gameModsPath))
                {
                    string[] dirs = Directory.GetDirectories(gameModsPath);
                    modFolders.AddRange(dirs);
                }

                string workshopPath = @"D:\steam\steamapps\workshop\content\3167020";
                if (Directory.Exists(workshopPath))
                {
                    string[] dirs = Directory.GetDirectories(workshopPath);
                    modFolders.AddRange(dirs);
                }

                int scannedCount = 0;
                int enabledCount = 0;

                foreach (var modDir in modFolders)
                {
                    scannedCount++;

                    try
                    {
                        var config = AnnouncementConfig.LoadFromFolder(modDir);

                        if (config == null || string.IsNullOrEmpty(config.ModId))
                        {
                            continue;
                        }

                        bool isEnabledInApi = _apiModList.Any(mod =>
                            mod != null && !string.IsNullOrEmpty(mod.id) && mod.id == config.ModId);

                        if (isEnabledInApi)
                        {
                            var apiModInfo = _apiModList.FirstOrDefault(mod =>
                                mod != null && mod.id == config.ModId);

                            if (apiModInfo != null && !string.IsNullOrEmpty(apiModInfo.name))
                            {
                                config.DisplayName = apiModInfo.name;
                            }

                            if (string.IsNullOrEmpty(config.DisplayName))
                            {
                                config.DisplayName = config.ModId;
                            }

                            if (string.IsNullOrEmpty(config.Version))
                            {
                                config.Version = "1.0.0";
                            }

                            _configs[config.ModId] = config;
                            enabledCount++;
                        }
                    }
                    catch (Exception e)
                    {
                        Debug.LogError($"扫描 Mod 目录 {modDir} 失败: {e.Message}");
                    }
                }

                CleanInvalidConfigs();
            }
            catch (Exception e)
            {
                Debug.LogError($"扫描 Mods 失败: {e}");
                _configs.Clear();
            }
        }

        private void CleanInvalidConfigs()
        {
            try
            {
                var invalidKeys = new List<string>();

                foreach (var kvp in _configs)
                {
                    if (string.IsNullOrEmpty(kvp.Key) || kvp.Value == null)
                    {
                        invalidKeys.Add(kvp.Key);
                    }
                }

                foreach (var key in invalidKeys)
                {
                    _configs.Remove(key);
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"清理无效配置失败: {e}");
            }
        }

        private async Task<bool> FetchModListFromApiAsync()
        {
            if (_isFetchingModList)
            {
                return false;
            }

            if (_lastModListFetchTime != DateTime.MinValue &&
                (DateTime.Now - _lastModListFetchTime).TotalMinutes < MOD_LIST_CACHE_DURATION_MINUTES)
            {
                return true;
            }

            _isFetchingModList = true;

            try
            {
                string url = "https://duckov.guducat.cc/api/mod/list";

                using (UnityWebRequest webRequest = UnityWebRequest.Get(url))
                {
                    webRequest.timeout = 15;
                    var operation = webRequest.SendWebRequest();

                    var cancellationToken = new System.Threading.CancellationTokenSource(TimeSpan.FromSeconds(20));

                    while (!operation.isDone && !cancellationToken.Token.IsCancellationRequested)
                    {
                        await Task.Delay(100);
                    }

                    if (cancellationToken.Token.IsCancellationRequested)
                    {
                        return false;
                    }

                    if (webRequest.result == UnityWebRequest.Result.Success)
                    {
                        string responseText = webRequest.downloadHandler.text;

                        if (TryParseModListJson(responseText, out var modList))
                        {
                            _apiModList = modList;
                            _lastModListFetchTime = DateTime.Now;
                            return true;
                        }
                        else
                        {
                            TryParseJsonManually(responseText);
                        }
                    }
                    else
                    {
                        Debug.LogWarning($"Mod 列表 API 请求失败: {webRequest.error}, URL: {url}");
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"获取 Mod 列表异常: {ex.Message}\nStack Trace: {ex.StackTrace}");
            }
            finally
            {
                _isFetchingModList = false;
            }

            return false;
        }

        private bool TryParseModListJson(string json, out List<ApiModListItem> modList)
        {
            modList = new List<ApiModListItem>();

            try
            {
                string cleanJson = json.Replace("\n", "").Replace("\r", "").Replace("\t", "").Replace(" ", "");

                if (!cleanJson.Contains("\"success\":true"))
                {
                    return false;
                }

                int dataStart = cleanJson.IndexOf("\"data\":[");
                if (dataStart < 0)
                {
                    return false;
                }

                dataStart += 8;
                int dataEnd = cleanJson.IndexOf("]", dataStart);
                if (dataEnd < 0)
                {
                    return false;
                }

                string dataArray = cleanJson.Substring(dataStart, dataEnd - dataStart);

                if (string.IsNullOrWhiteSpace(dataArray) || dataArray == "}")
                {
                    return true;
                }

                var items = dataArray.Split(new[] { "},{" }, StringSplitOptions.RemoveEmptyEntries);

                foreach (var item in items)
                {
                    string cleanItem = item.Trim('{', '}', ' ', '\r', '\n', '\t');

                    if (string.IsNullOrWhiteSpace(cleanItem))
                        continue;

                    string id = ExtractJsonValue(cleanItem, "id");
                    string name = ExtractJsonValue(cleanItem, "name");

                    if (!string.IsNullOrEmpty(id))
                    {
                        modList.Add(new ApiModListItem
                        {
                            id = id,
                            name = string.IsNullOrEmpty(name) ? id : name
                        });
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private string ExtractJsonValue(string jsonObject, string key)
        {
            try
            {
                string searchString = $"\"{key}\":\"";
                int start = jsonObject.IndexOf(searchString);
                if (start < 0)
                {
                    searchString = $"\"{key}\":";
                    start = jsonObject.IndexOf(searchString);
                    if (start < 0) return null;

                    start += searchString.Length;
                    int end = jsonObject.IndexOf(",", start);
                    if (end < 0) end = jsonObject.IndexOf("}", start);
                    if (end < 0) return null;

                    string value = jsonObject.Substring(start, end - start).Trim();
                    value = value.Trim('\"');
                    return value;
                }

                start += searchString.Length;
                int endQuote = jsonObject.IndexOf("\"", start);
                if (endQuote < 0) return null;

                return jsonObject.Substring(start, endQuote - start);
            }
            catch
            {
                return null;
            }
        }

        private void TryParseJsonManually(string json)
        {
            try
            {
                if (json.Contains("\"success\":true") && json.Contains("\"data\":"))
                {
                    int dataStart = json.IndexOf("\"data\":") + 7;
                    int dataEnd = json.LastIndexOf("]") + 1;

                    if (dataStart > 7 && dataEnd > dataStart)
                    {
                        string dataArray = json.Substring(dataStart, dataEnd - dataStart);
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        private async Task FetchAllModAnnouncementsAsync()
        {
            if (_configs.Count == 0) return;

            foreach (var config in _configs.Values)
            {
                try
                {
                    await config.FetchAnnouncementsFromApiAsync();
                }
                catch (Exception e)
                {
                    Debug.LogError($"获取 Mod {config.ModId} 公告失败: {e.Message}");
                }
            }

            CheckForVersionUpdates();
        }

        private void CheckForVersionUpdates()
        {
            try
            {
                if (_uiManager == null)
                {
                    return;
                }

                bool hasUpdates = false;
                int updateCount = 0;

                foreach (var config in _configs.Values)
                {
                    if (config.HasNewVersionAvailable)
                    {
                        hasUpdates = true;
                        updateCount++;
                    }
                }

                if (hasUpdates)
                {
                    _uiManager.CheckAndShowUpdatePopup();
                }
                else
                {
                    _uiManager?.CheckAndShowUpdatePopup();
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"检查版本更新失败: {e}");
            }
        }

        private void Update()
        {
            if (!_isInitialized) return;

            _refreshTimer += Time.deltaTime;
            if (_refreshTimer >= REFRESH_INTERVAL)
            {
                _refreshTimer = 0f;
                _ = RefreshAllAnnouncementsAsync();
            }

            _updateCheckTimer += Time.deltaTime;
            if (_updateCheckTimer >= UPDATE_CHECK_INTERVAL)
            {
                _updateCheckTimer = 0f;

                if (_uiManager != null && !_hasAutoShownUpdates)
                {
                    CheckForVersionUpdates();
                }
            }
        }

        private async Task RefreshAllAnnouncementsAsync()
        {
            await FetchModListFromApiAsync();

            await FetchAllModAnnouncementsAsync();

            if (_uiManager != null && _state != null)
            {
                _state = new AnnouncementState(_configs);
                SetupUIManager();
            }
        }

        public async Task<bool> RegisterModAnnouncementAsync(string modFolderPath)
        {
            try
            {
                if (_apiModList.Count == 0)
                {
                    await FetchModListFromApiAsync();
                }

                var config = AnnouncementConfig.LoadFromFolder(modFolderPath);
                if (config == null || string.IsNullOrEmpty(config.ModId))
                {
                    return false;
                }

                bool isEnabledInApi = _apiModList.Any(mod => mod.id == config.ModId);
                if (!isEnabledInApi)
                {
                    return false;
                }

                var apiModInfo = _apiModList.FirstOrDefault(mod => mod.id == config.ModId);
                if (apiModInfo != null && !string.IsNullOrEmpty(apiModInfo.name))
                {
                    config.DisplayName = apiModInfo.name;
                }

                await config.FetchAnnouncementsFromApiAsync();

                if (_configs.ContainsKey(config.ModId))
                {
                    _configs[config.ModId] = config;
                }
                else
                {
                    _configs[config.ModId] = config;
                }

                if (_state != null)
                {
                    _state = new AnnouncementState(_configs);
                }

                if (_uiManager != null)
                {
                    SetupUIManager();
                }

                return true;
            }
            catch (Exception e)
            {
                Debug.LogError($"AnnouncementCore: 注册Mod公告失败: {e.Message}");
                return false;
            }
        }

        public bool RegisterModAnnouncement(string modFolderPath)
        {
            _ = RegisterModAnnouncementAsync(modFolderPath);
            return true;
        }

        private async void OnModActivated(ModInfo modInfo, Duckov.Modding.ModBehaviour modBehaviour)
        {
            try
            {
                if (_isInitialized)
                {
                    bool registered = await RegisterModAnnouncementAsync(modInfo.path);

                    if (registered)
                    {
                        CheckForVersionUpdates();

                        if (_uiManager != null)
                        {
                            SetupUIManager();
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"处理Mod激活事件失败: {e}");
            }
        }

        private void OnMainMenuAwake()
        {
            try
            {
                if (_isInitialized && _configs.Count > 0)
                {
                    SetupUIManager();
                }
                else if (_isInitialized && _configs.Count == 0)
                {
                }
                else
                {
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"处理主菜单唤醒事件失败: {e}");
            }
        }

        private void CheckAndSetupUI()
        {
            if (_isInitialized && _configs.Count > 0)
            {
                GameObject mainMenuObject = GameObject.Find("MainMenu(Clone)") ?? GameObject.Find("MainMenu");
                if (mainMenuObject != null && mainMenuObject.activeInHierarchy)
                {
                    SetupUIManager();
                }
                else
                {
                }
            }
        }

        private void SetupUIManager()
        {
            if (_state == null) return;

            if (_uiManager != null)
            {
                _uiManager.Cleanup();
                Destroy(_uiManager);
                _uiManager = null;
            }

            _uiManager = gameObject.AddComponent<UIManager>();

            Transform uiRoot = FindUIRoot();
            if (uiRoot == null)
            {
                uiRoot = CreateUIRoot();
            }

            _uiManager.Initialize(_state, uiRoot);
        }

        private Transform FindUIRoot()
        {
            try
            {
                GameObject existingCanvas = GameObject.Find("AnnouncementCanvas");
                if (existingCanvas != null)
                {
                    Canvas canvas = existingCanvas.GetComponent<Canvas>();

                    if (!canvas.gameObject.activeSelf)
                    {
                        canvas.gameObject.SetActive(true);
                    }

                    return existingCanvas.transform;
                }

                return CreateAnnouncementCanvas();
            }
            catch (Exception e)
            {
                Debug.LogError($"查找UI根对象异常: {e}");
                return CreateAnnouncementCanvas();
            }
        }

        private Transform CreateAnnouncementCanvas()
        {
            try
            {
                GameObject canvasObj = new GameObject("AnnouncementCanvas");
                Canvas canvas = canvasObj.AddComponent<Canvas>();
                canvas.renderMode = RenderMode.ScreenSpaceOverlay;
                canvas.sortingOrder = 10001;

                CanvasScaler scaler = canvasObj.AddComponent<CanvasScaler>();
                scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
                scaler.referenceResolution = new Vector2(1920, 1080);
                scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
                scaler.matchWidthOrHeight = 0.5f;

                canvasObj.AddComponent<GraphicRaycaster>();

                DontDestroyOnLoad(canvasObj);

                return canvasObj.transform;
            }
            catch (Exception e)
            {
                Debug.LogError($"创建Canvas异常: {e}");
                return null;
            }
        }

        private Transform CreateUIRoot()
        {
            try
            {
                GameObject canvasObj = new GameObject("AnnouncementCanvas_Debug");
                Canvas canvas = canvasObj.AddComponent<Canvas>();
                canvas.renderMode = RenderMode.ScreenSpaceOverlay;
                canvas.sortingOrder = 1000;

                CanvasScaler scaler = canvasObj.AddComponent<CanvasScaler>();
                scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
                scaler.referenceResolution = new Vector2(1920, 1080);
                scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
                scaler.matchWidthOrHeight = 0.5f;

                canvasObj.AddComponent<GraphicRaycaster>();

                Image bg = canvasObj.AddComponent<Image>();
                bg.color = new Color(0f, 0f, 0f, 0.3f);

                return canvasObj.transform;
            }
            catch (Exception e)
            {
                Debug.LogError($"创建Canvas异常: {e}");
                return null;
            }
        }

        private void OnMainMenuDestroy()
        {
            try
            {
                if (_uiManager != null)
                {
                    _uiManager.HideMainPanelOnly();
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"处理主菜单销毁事件失败: {e}");
            }
        }

        public static void ManualWakeUp()
        {
            WakeUp();
        }

        public static bool IsAwake()
        {
            return _isInitialized && _instance != null;
        }

        public static void Reinitialize()
        {
            if (_instance != null)
            {
                _instance.Initialize(true);
            }
            else
            {
                WakeUp();
            }
        }

        public static void CleanupMod(string modId)
        {
            if (!_isInitialized || _instance == null)
            {
                return;
            }

            if (string.IsNullOrEmpty(modId))
            {
                Debug.LogError("ModId不能为空");
                return;
            }

            try
            {
                _instance._state?.CleanMod(modId);

                _instance._configs.Remove(modId);

                string popupShownKey = $"Announcement_PopupShown_{modId}";
                string hiddenPopupKey = $"Announcement_HiddenPopup_{modId}";
                PlayerPrefs.DeleteKey(popupShownKey);
                PlayerPrefs.DeleteKey(hiddenPopupKey);
                PlayerPrefs.Save();

                if (_instance._uiManager != null)
                {
                    _instance.SetupUIManager();
                }
            }
            catch (Exception e)
            {
            }
        }

        public static void CleanupAll()
        {
            if (!_isInitialized || _instance == null)
            {
                Debug.LogWarning("AnnouncementCore: 未初始化，无法清理");
                return;
            }

            try
            {
                if (_instance._uiManager != null)
                {
                    _instance._uiManager.Cleanup();
                    _instance._uiManager = null;
                }

                _instance._state?.CleanAll();

                _instance._configs.Clear();
            }
            catch (Exception e)
            {
            }
        }

        public static void Rescan()
        {
            if (!_isInitialized || _instance == null)
            {
                Debug.LogWarning("AnnouncementCore: 未初始化，无法重新扫描");
                return;
            }

            _instance.ScanActiveModsForAnnouncements();
            _instance._state = new AnnouncementState(_instance._configs);

            if (_instance._uiManager != null)
            {
                _instance.SetupUIManager();
            }
        }
    }
}