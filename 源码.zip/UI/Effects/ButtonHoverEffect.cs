﻿using AnnouncementCore.Utility;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace AnnouncementCore.UI.Effects
{
    public class ButtonHoverEffect : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
    {
        public Image ButtonImage;
        public Button ButtonComponent;
        public TextMeshProUGUI ButtonText;
        [SerializeField] private float _hoverScale = 1.1f;
        [SerializeField] private float _animationDuration = 0.3f;
        [SerializeField] private bool _useTextHoverColor = false;
        [SerializeField] private Color _textHoverColor = new Color(1f, 0.95f, 0.9f, 1f);
        private Vector3 _originalScale;
        private Color _originalImageColor;
        private Color _originalTextColor;
        private Coroutine _currentAnimation;

        private void Awake()
        {
            if (ButtonImage == null) ButtonImage = GetComponent<Image>();
            if (ButtonComponent == null) ButtonComponent = GetComponent<Button>();
            if (ButtonText == null && ButtonComponent != null)
                ButtonText = ButtonComponent.GetComponentInChildren<TextMeshProUGUI>();
            if (ButtonImage != null) _originalImageColor = ButtonImage.color;
            _originalScale = transform.localScale;
            if (ButtonText != null) _originalTextColor = ButtonText.color;
        }

        public void OnPointerEnter(PointerEventData eventData)
        {
            if (ButtonComponent != null && !ButtonComponent.interactable) return;
            AudioUtility.PlayHoverSound();
            if (_currentAnimation != null) StopCoroutine(_currentAnimation);
            _currentAnimation = StartCoroutine(HoverAnimation(true));
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            if (ButtonComponent != null && !ButtonComponent.interactable) return;
            if (_currentAnimation != null) StopCoroutine(_currentAnimation);
            _currentAnimation = StartCoroutine(HoverAnimation(false));
        }

        private System.Collections.IEnumerator HoverAnimation(bool isHovering)
        {
            Vector3 targetScale = isHovering ? _originalScale * _hoverScale : _originalScale;
            Color targetTextColor = isHovering && _useTextHoverColor && ButtonText != null
                ? _textHoverColor : _originalTextColor;
            float elapsedTime = 0f;
            Vector3 startScale = transform.localScale;
            Color startTextColor = ButtonText != null ? ButtonText.color : _originalTextColor;
            while (elapsedTime < _animationDuration)
            {
                elapsedTime += Time.unscaledDeltaTime;
                float t = elapsedTime / _animationDuration;
                float progress = 1 - Mathf.Pow(1 - t, 3);
                transform.localScale = Vector3.Lerp(startScale, targetScale, progress);
                if (ButtonText != null)
                    ButtonText.color = Color.Lerp(startTextColor, targetTextColor, progress);
                yield return null;
            }
            transform.localScale = targetScale;
            if (ButtonText != null) ButtonText.color = targetTextColor;
            _currentAnimation = null;
        }

        public void ConfigureForPopupButton()
        {
            _hoverScale = 1.1f;
            _useTextHoverColor = true;
            _textHoverColor = new Color(1f, 0.9f, 0.8f, 1f);
            _animationDuration = 0.3f;
        }

        public void ConfigureForSidebarItem()
        {
            _hoverScale = 1.05f;
            _useTextHoverColor = true;
            _textHoverColor = new Color(1f, 1f, 0.9f, 1f);
            _animationDuration = 0.3f;
        }

        public void ConfigureForNotificationButton()
        {
            _hoverScale = 1.1f;
            _useTextHoverColor = false;
            _animationDuration = 0.3f;
        }

        private void OnDestroy()
        {
            if (transform != null) transform.localScale = _originalScale;
            if (ButtonImage != null) ButtonImage.color = _originalImageColor;
            if (ButtonText != null) ButtonText.color = _originalTextColor;
            if (_currentAnimation != null) StopCoroutine(_currentAnimation);
        }
    }
}