﻿using AnnouncementCore.Utility;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace AnnouncementCore.UI.Effects
{
    public class ConsolidatedHoverEffect : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
    {
        [SerializeField] private Image _buttonImage;
        [SerializeField] private Button _buttonComponent;
        [SerializeField] private TextMeshProUGUI _buttonText;
        [SerializeField] private TextMeshProUGUI _additionalText1;
        [SerializeField] private TextMeshProUGUI _additionalText2;

        [SerializeField] private float _hoverScale = 1.05f;
        [SerializeField] private float _hoverAlpha = 0.85f;
        [SerializeField] private float _animationDuration = 0.2f;

        [SerializeField] private bool _useHoverColor = false;
        [SerializeField] private Color _hoverColor = new Color(0.3f, 0.3f, 0.4f, 1f);
        [SerializeField] private bool _useTextHoverColor = false;
        [SerializeField] private Color _textHoverColor = new Color(1f, 0.95f, 0.9f, 1f);
        [SerializeField] private bool _affectAdditionalTexts = true;

        [SerializeField] private EffectType _effectType = EffectType.Generic;

        public enum EffectType
        {
            Generic,
            CloseButton,
            SidebarItem,
            NotificationButton,
            PopupButton
        }

        private Vector3 _originalScale;
        private Color _originalImageColor;
        private Color _originalTextColor;
        private Color _originalAdditionalText1Color;
        private Color _originalAdditionalText2Color;
        private Coroutine _currentAnimation;

        private void Awake()
        {
            CacheOriginalState();
            ApplyPresetConfiguration();
            ValidateComponents();
        }

        private void OnDestroy()
        {
            RestoreOriginalState();
            StopAnimation();
        }

        public void SetEffectType(EffectType type)
        {
            _effectType = type;
            ApplyPresetConfiguration();
        }

        public void TriggerHover(bool isHovering)
        {
            if (_currentAnimation != null)
            {
                StopCoroutine(_currentAnimation);
            }
            _currentAnimation = StartCoroutine(HoverAnimation(isHovering));
        }

        public void OnPointerEnter(PointerEventData eventData)
        {
            if (_buttonComponent != null && !_buttonComponent.interactable) return;

            AudioUtility.PlayHoverSound();
            TriggerHover(true);
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            if (_buttonComponent != null && !_buttonComponent.interactable) return;

            TriggerHover(false);
        }

        private void ApplyPresetConfiguration()
        {
            switch (_effectType)
            {
                case EffectType.CloseButton:
                    ConfigureAsCloseButton();
                    break;
                case EffectType.SidebarItem:
                    ConfigureAsSidebarItem();
                    break;
                case EffectType.NotificationButton:
                    ConfigureAsNotificationButton();
                    break;
                case EffectType.PopupButton:
                    ConfigureAsPopupButton();
                    break;
            }
        }

        public void ConfigureAsCloseButton()
        {
            _hoverScale = 1.08f;
            _hoverAlpha = 0.85f;
            _useHoverColor = false;
            _useTextHoverColor = true;
            _textHoverColor = new Color(1f, 0.95f, 0.9f, 1f);
            _animationDuration = 0.2f;
            _affectAdditionalTexts = false;
        }

        public void ConfigureAsSidebarItem()
        {
            _hoverScale = 1.05f;
            _hoverAlpha = 0.9f;
            _useHoverColor = true;
            _hoverColor = new Color(0.3f, 0.3f, 0.4f, 1f);
            _useTextHoverColor = true;
            _textHoverColor = new Color(1f, 1f, 0.9f, 1f);
            _animationDuration = 0.2f;
            _affectAdditionalTexts = true;
        }

        public void ConfigureAsNotificationButton()
        {
            _hoverScale = 1.1f;
            _hoverAlpha = 1f;
            _useHoverColor = false;
            _useTextHoverColor = false;
            _animationDuration = 0.2f;
            _affectAdditionalTexts = false;
        }

        public void ConfigureAsPopupButton()
        {
            _hoverScale = 1.1f;
            _hoverAlpha = 0.8f;
            _useHoverColor = false;
            _useTextHoverColor = true;
            _textHoverColor = new Color(1f, 0.9f, 0.8f, 1f);
            _animationDuration = 0.3f;
            _affectAdditionalTexts = false;
        }

        private void CacheOriginalState()
        {
            if (_buttonImage == null)
                _buttonImage = GetComponent<Image>();

            if (_buttonComponent == null)
                _buttonComponent = GetComponent<Button>();

            if (_buttonText == null && _buttonComponent != null)
            {
                _buttonText = _buttonComponent.GetComponentInChildren<TextMeshProUGUI>();
            }

            if (_additionalText1 == null)
            {
                _additionalText1 = transform.Find("ModName")?.GetComponent<TextMeshProUGUI>();
            }

            if (_additionalText2 == null)
            {
                _additionalText2 = transform.Find("ModVersion")?.GetComponent<TextMeshProUGUI>();
            }

            if (_buttonImage != null)
                _originalImageColor = _buttonImage.color;

            _originalScale = transform.localScale;

            if (_buttonText != null)
                _originalTextColor = _buttonText.color;

            if (_additionalText1 != null)
                _originalAdditionalText1Color = _additionalText1.color;

            if (_additionalText2 != null)
                _originalAdditionalText2Color = _additionalText2.color;
        }

        private void RestoreOriginalState()
        {
            if (transform != null)
                transform.localScale = _originalScale;

            if (_buttonImage != null)
                _buttonImage.color = _originalImageColor;

            if (_buttonText != null)
                _buttonText.color = _originalTextColor;

            if (_additionalText1 != null)
                _additionalText1.color = _originalAdditionalText1Color;

            if (_additionalText2 != null)
                _additionalText2.color = _originalAdditionalText2Color;
        }

        private void ValidateComponents()
        {
            if (_buttonImage == null)
            {
            }

            if (_buttonComponent == null)
            {
            }
        }

        private System.Collections.IEnumerator HoverAnimation(bool isHovering)
        {
            Vector3 targetScale = isHovering ? _originalScale * _hoverScale : _originalScale;
            Color targetImageColor = GetTargetImageColor(isHovering);
            Color targetTextColor = GetTargetTextColor(isHovering);
            Color targetAdditionalText1Color = GetTargetAdditionalTextColor(_additionalText1, isHovering);
            Color targetAdditionalText2Color = GetTargetAdditionalTextColor(_additionalText2, isHovering);

            float elapsedTime = 0f;
            Vector3 startScale = transform.localScale;
            Color startImageColor = _buttonImage != null ? _buttonImage.color : _originalImageColor;
            Color startTextColor = _buttonText != null ? _buttonText.color : _originalTextColor;
            Color startAdditionalText1Color = _additionalText1 != null ? _additionalText1.color : _originalAdditionalText1Color;
            Color startAdditionalText2Color = _additionalText2 != null ? _additionalText2.color : _originalAdditionalText2Color;

            while (elapsedTime < _animationDuration)
            {
                if (transform == null || _buttonImage == null) yield break;

                elapsedTime += Time.unscaledDeltaTime;
                float t = elapsedTime / _animationDuration;
                float progress = SmoothEaseOut(t);

                ApplyTransform(progress, startScale, targetScale,
                    startImageColor, targetImageColor,
                    startTextColor, targetTextColor,
                    startAdditionalText1Color, targetAdditionalText1Color,
                    startAdditionalText2Color, targetAdditionalText2Color);

                yield return null;
            }

            ApplyFinalState(targetScale, targetImageColor, targetTextColor,
                targetAdditionalText1Color, targetAdditionalText2Color);

            _currentAnimation = null;
        }

        private Color GetTargetImageColor(bool isHovering)
        {
            if (!isHovering) return _originalImageColor;

            if (_useHoverColor && _buttonImage != null)
                return Color.Lerp(_originalImageColor, _hoverColor, 0.4f);

            return new Color(_originalImageColor.r, _originalImageColor.g,
                           _originalImageColor.b, _hoverAlpha);
        }

        private Color GetTargetTextColor(bool isHovering)
        {
            if (!isHovering) return _originalTextColor;
            return _useTextHoverColor && _buttonText != null ? _textHoverColor : _originalTextColor;
        }

        private Color GetTargetAdditionalTextColor(TextMeshProUGUI text, bool isHovering)
        {
            if (!isHovering || !_affectAdditionalTexts || text == null)
                return text != null ? text.color : Color.white;

            return _textHoverColor;
        }

        private void ApplyTransform(float progress, Vector3 startScale, Vector3 targetScale,
            Color startImageColor, Color targetImageColor,
            Color startTextColor, Color targetTextColor,
            Color startAdditionalText1Color, Color targetAdditionalText1Color,
            Color startAdditionalText2Color, Color targetAdditionalText2Color)
        {
            transform.localScale = Vector3.Lerp(startScale, targetScale, progress);

            if (_buttonImage != null)
                _buttonImage.color = Color.Lerp(startImageColor, targetImageColor, progress);

            if (_buttonText != null)
                _buttonText.color = Color.Lerp(startTextColor, targetTextColor, progress);

            if (_additionalText1 != null)
                _additionalText1.color = Color.Lerp(startAdditionalText1Color, targetAdditionalText1Color, progress);

            if (_additionalText2 != null)
                _additionalText2.color = Color.Lerp(startAdditionalText2Color, targetAdditionalText2Color, progress);
        }

        private void ApplyFinalState(Vector3 targetScale, Color targetImageColor,
            Color targetTextColor, Color targetAdditionalText1Color, Color targetAdditionalText2Color)
        {
            if (transform != null)
                transform.localScale = targetScale;

            if (_buttonImage != null)
                _buttonImage.color = targetImageColor;

            if (_buttonText != null)
                _buttonText.color = targetTextColor;

            if (_additionalText1 != null)
                _additionalText1.color = targetAdditionalText1Color;

            if (_additionalText2 != null)
                _additionalText2.color = targetAdditionalText2Color;
        }

        private void StopAnimation()
        {
            if (_currentAnimation != null)
            {
                StopCoroutine(_currentAnimation);
                _currentAnimation = null;
            }
        }

        private float SmoothEaseOut(float t) => 1 - Mathf.Pow(1 - t, 3);

        private float ElasticEaseOut(float t)
        {
            if (t >= 1) return 1;
            float p = 0.3f;
            float s = p / 4f;
            return Mathf.Pow(2, -10 * t) * Mathf.Sin((t - s) * (2 * Mathf.PI) / p) + 1;
        }

        public Image ButtonImage
        {
            get => _buttonImage;
            set => _buttonImage = value;
        }

        public Button ButtonComponent
        {
            get => _buttonComponent;
            set => _buttonComponent = value;
        }

        public TextMeshProUGUI ButtonText
        {
            get => _buttonText;
            set => _buttonText = value;
        }

        public EffectType CurrentEffectType => _effectType;
    }
}