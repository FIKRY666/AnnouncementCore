﻿using AnnouncementCore.Data;
using AnnouncementCore.UI.Components;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace AnnouncementCore.UI
{
    public class UIManager : MonoBehaviour
    {
        private AnnouncementState _state;
        private UIAnimator _animator;

        private NotificationButton _notificationButton;
        private MainPanel _mainPanel;
        private List<UpdateNotificationPopup> _updatePopups = new List<UpdateNotificationPopup>();
        private SummaryNotificationPanel _summaryPanel;

        private Transform _uiRoot;
        private bool _isInitialized = false;
        private bool _popupsVisible = true;

        public void Initialize(AnnouncementState state, Transform uiRoot)
        {
            try
            {
                if (uiRoot == null)
                {
                    Debug.LogError("UIManager: uiRoot为null");
                    return;
                }

                var canvas = uiRoot.GetComponent<Canvas>();
                if (canvas == null)
                {
                    Debug.LogError("UIManager: uiRoot没有Canvas组件");
                    return;
                }

                if (state == null)
                {
                    Debug.LogError("UIManager: AnnouncementState为null");
                    return;
                }

                List<AnnouncementConfig> allConfigs;
                try
                {
                    allConfigs = state.GetAllConfigsSorted();
                }
                catch (Exception e)
                {
                    Debug.LogError($"获取配置列表失败: {e.Message}");
                    return;
                }

                if (allConfigs.Count == 0)
                {
                    return;
                }

                _state = state;
                _uiRoot = uiRoot;

                _animator = new UIAnimator(this);

                CreateNotificationButton();
                CreateMainPanel();
                CreateSummaryPanel();

                SubscribeToEvents();

                StartCoroutine(DelayedInitialization());
            }
            catch (Exception e)
            {
                Debug.LogError($"UIManager 初始化失败: {e}");
                _isInitialized = false;
            }
        }

        private IEnumerator DelayedInitialization()
        {
            yield return null;

            if (_notificationButton != null && _notificationButton.IsInitialized &&
                _mainPanel != null && _mainPanel.IsInitialized)
            {
                _isInitialized = true;
                UpdateNotificationButton();
                CheckAndShowUpdatePopup();
            }
        }

        private void CreateNotificationButton()
        {
            try
            {
                _notificationButton = gameObject.AddComponent<NotificationButton>();
                _notificationButton.Initialize(_uiRoot, OnNotificationButtonClicked);
            }
            catch (Exception e)
            {
                _notificationButton = null;
            }
        }

        private void CreateMainPanel()
        {
            try
            {
                _mainPanel = gameObject.AddComponent<MainPanel>();
                _mainPanel.Initialize(_uiRoot, _state, _animator);
                _mainPanel.SetCallbacks(
                    onPrevClicked: OnPrevButtonClicked,
                    onNextClicked: OnNextButtonClicked,
                    onFeedbackClicked: OnFeedbackButtonClicked,
                    onCloseClicked: OnCloseButtonClicked
                );
            }
            catch (Exception e)
            {
                _mainPanel = null;
            }
        }

        private void CreateSummaryPanel()
        {
            try
            {
                _summaryPanel = gameObject.AddComponent<SummaryNotificationPanel>();
                _summaryPanel.Initialize(_state, _uiRoot, OnPopupsVisibilityChanged);
                _summaryPanel.Show();
            }
            catch (Exception e)
            {
                _summaryPanel = null;
            }
        }

        private void OnPopupsVisibilityChanged(bool areVisible)
        {
            _popupsVisible = areVisible;

            try
            {
                if (areVisible)
                {
                    foreach (var popup in _updatePopups)
                    {
                        if (popup != null && popup.ModId != null && _state != null)
                        {
                            var config = _state.GetConfigById(popup.ModId);
                            if (config != null && ShouldPopupBeVisible(config, popup.ModId))
                            {
                                popup.Show();
                            }
                            else
                            {
                                popup.Cleanup();
                            }
                        }
                    }

                    _updatePopups.RemoveAll(p => p == null);
                    UpdateNotificationPopup.RearrangeAllPopups();
                }
                else
                {
                    foreach (var popup in _updatePopups)
                    {
                        if (popup != null && popup.ModId != null && _state != null)
                        {
                            var config = _state.GetConfigById(popup.ModId);
                            if (config != null && !config.HasPermanentUpdate)
                            {
                                _state.MarkPopupAsHidden(popup.ModId);
                            }
                            popup.Hide();
                        }
                    }
                }
            }
            catch (Exception e)
            {
            }
        }

        private void SubscribeToEvents()
        {
            AnnouncementState.OnUnreadStatusChanged += UpdateNotificationButton;
            AnnouncementState.OnAnnouncementSelected += OnAnnouncementSelected;
            AnnouncementState.OnPanelStateChanged += OnPanelStateChanged;
            AnnouncementState.OnAnnouncementRead += OnAnnouncementRead;
            AnnouncementState.OnPopupShouldHide += OnPopupShouldHide;
            SceneManager.sceneLoaded += OnSceneLoaded;
        }

        private void UnsubscribeFromEvents()
        {
            AnnouncementState.OnUnreadStatusChanged -= UpdateNotificationButton;
            AnnouncementState.OnAnnouncementSelected -= OnAnnouncementSelected;
            AnnouncementState.OnPanelStateChanged -= OnPanelStateChanged;
            AnnouncementState.OnAnnouncementRead -= OnAnnouncementRead;
            AnnouncementState.OnPopupShouldHide -= OnPopupShouldHide;
            SceneManager.sceneLoaded -= OnSceneLoaded;
        }

        private void OnNotificationButtonClicked()
        {
            if (!_isInitialized || _state == null) return;

            try
            {
                if (_state.IsPanelOpen)
                {
                    _mainPanel?.Hide();
                    _state.ClosePanel();
                }
                else
                {
                    var sorted = _state.GetAllConfigsSorted();
                    if (sorted.Count > 0)
                    {
                        var firstUnread = sorted.Find(c => c != null && !_state.IsRead(c.ModId));
                        if (firstUnread != null)
                        {
                            _state.SelectAnnouncement(firstUnread.ModId);
                        }
                        else
                        {
                            var firstValid = sorted.Find(c => c != null);
                            if (firstValid != null)
                            {
                                _state.SelectAnnouncement(firstValid.ModId);
                            }
                        }
                    }

                    _mainPanel?.Show();
                    _state.OpenPanel();
                }
            }
            catch (Exception e)
            {
            }
        }

        private void OnAnnouncementSelected(string modId)
        {
            if (!_isInitialized || _mainPanel == null) return;
            _mainPanel.UpdateContent(modId);
        }

        private void OnPanelStateChanged()
        {
            if (!_isInitialized) return;
            UpdateNotificationButton();
        }

        private void OnAnnouncementRead(string modId)
        {
            _summaryPanel?.UpdateContent();
        }

        private void OnPopupShouldHide(string modId)
        {
            _summaryPanel?.UpdateContent();
        }

        private void OnPrevButtonClicked()
        {
            if (!_isInitialized || _state == null) return;

            try
            {
                string result = _state.GetPrevVersion();
                if (result != null)
                {
                    if (_mainPanel != null)
                    {
                        _mainPanel.UpdateContent(result);
                    }
                }
            }
            catch (Exception e)
            {
            }
        }

        private void OnNextButtonClicked()
        {
            if (!_isInitialized || _state == null) return;

            try
            {
                string result = _state.GetNextVersion();
                if (result != null)
                {
                    if (_mainPanel != null)
                    {
                        _mainPanel.UpdateContent(result);
                    }
                }
            }
            catch (Exception e)
            {
            }
        }

        private void OnFeedbackButtonClicked()
        {
            if (!_isInitialized) return;

            try
            {
                if (_state?.SelectedConfig != null)
                {
                    Application.OpenURL($"https://qm.qq.com/q/WwTcbfW266");
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"处理反馈按钮点击失败: {e}");
            }
        }

        private void OnCloseButtonClicked()
        {
            if (!_isInitialized || _mainPanel == null || _state == null) return;

            try
            {
                _mainPanel.Hide();
                _state.ClosePanel();
            }
            catch (Exception e)
            {
                Debug.LogError($"处理关闭按钮点击失败: {e}");
            }
        }

        public void RefreshAnnouncements()
        {
            if (!_isInitialized || _state == null)
            {
                Debug.LogWarning("UIManager: 未初始化，无法刷新");
                return;
            }

            StartCoroutine(RefreshAnnouncementsCoroutine());
        }

        private IEnumerator RefreshAnnouncementsCoroutine()
        {
            var announcementManager = UnityEngine.Object.FindObjectOfType<AnnouncementCore.Core.AnnouncementManager>();
            if (announcementManager == null)
            {
                Debug.LogError("UIManager: 未找到AnnouncementManager");
                yield break;
            }

            var initializeTask = announcementManager.InitializeAsync(true);
            while (!initializeTask.IsCompleted && !initializeTask.IsFaulted && !initializeTask.IsCanceled)
            {
                yield return null;
            }

            if (initializeTask.IsFaulted)
            {
                Debug.LogError($"初始化任务失败: {initializeTask.Exception?.Message}");
                yield break;
            }

            if (_mainPanel != null && _state != null)
            {
                _mainPanel.RefreshSidebarList();

                if (_state.SelectedConfig != null)
                {
                    _mainPanel.UpdateContent(_state.SelectedModId);
                }

                UpdateNotificationButton();
            }

            CheckAndShowUpdatePopup();
        }

        private void UpdateNotificationButton()
        {
            if (!_isInitialized || _notificationButton == null || !_notificationButton.IsInitialized || _state == null)
                return;

            try
            {
                int unreadCount = _state.UnreadCount;

                if (_state.AllRead)
                {
                    _notificationButton.HideButton();
                }
                else
                {
                    _notificationButton.ShowButton();
                    _notificationButton.UpdateUnreadIndicator(unreadCount);
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"更新通知按钮失败: {e}");
            }
        }

        public void CheckAndShowUpdatePopup()
        {
            if (!_isInitialized || _state == null)
            {
                return;
            }

            try
            {
                var permanentUpdates = new List<AnnouncementConfig>();
                var unreadUpdates = new List<AnnouncementConfig>();
                var configs = _state.GetAllConfigsSorted();

                foreach (var config in configs)
                {
                    if (config.HasPermanentUpdate && !_state.IsRead(config.ModId))
                    {
                        permanentUpdates.Add(config);
                    }
                    else if (!config.HasPermanentUpdate && !_state.IsRead(config.ModId))
                    {
                        unreadUpdates.Add(config);
                    }
                }

                var allUpdates = new List<AnnouncementConfig>();
                allUpdates.AddRange(permanentUpdates);
                allUpdates.AddRange(unreadUpdates);

                if (allUpdates.Count > 0)
                {
                    CreateUpdateNotificationPopups(allUpdates);
                    _summaryPanel?.UpdateContent();
                    UpdateNotificationButton();
                }
                else
                {
                    CleanupUpdatePopups();
                    _summaryPanel?.UpdateContent();
                }
            }
            catch (Exception e)
            {
            }
        }

        private bool ShouldPopupBeVisible(AnnouncementConfig config, string modId)
        {
            try
            {
                if (config == null || _state == null) return false;

                if (_state.IsRead(modId))
                {
                    return false;
                }

                if (config.HasPermanentUpdate)
                {
                    return true;
                }

                bool isHidden = _state.IsPopupHidden(modId);

                if (!isHidden)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception e)
            {
                return false;
            }
        }

        private bool CreateUpdateNotificationPopups(List<AnnouncementConfig> updateConfigs)
        {
            try
            {
                CleanupUpdatePopups();

                var sortedConfigs = updateConfigs
                    .Where(config => ShouldPopupBeVisible(config, config.ModId))
                    .OrderBy(c => c.HasPermanentUpdate ? 0 : 1)
                    .ToList();

                for (int i = 0; i < sortedConfigs.Count; i++)
                {
                    var config = sortedConfigs[i];

                    if (!ShouldPopupBeVisible(config, config.ModId))
                    {
                        continue;
                    }

                    var popup = gameObject.AddComponent<UpdateNotificationPopup>();
                    popup.Initialize(config, _state, _uiRoot, _animator, i);
                    _updatePopups.Add(popup);

                    if (_popupsVisible)
                    {
                        popup.Show();
                    }
                    else
                    {
                        popup.Hide();
                    }
                }

                return true;
            }
            catch (Exception e)
            {
                CleanupUpdatePopups();
                return false;
            }
        }

        private void CleanupUpdatePopups()
        {
            try
            {
                foreach (var popup in _updatePopups)
                {
                    if (popup != null) popup.Cleanup();
                }
                _updatePopups.Clear();
                UpdateNotificationPopup.CleanupAll();
            }
            catch (Exception e)
            {
            }
        }

        public void OpenAnnouncementFromPopup(string modId)
        {
            if (!_isInitialized || _state == null) return;

            try
            {
                _state.SelectAnnouncement(modId);

                if (_mainPanel != null && !_state.IsPanelOpen)
                {
                    _mainPanel.Show();
                    _state.OpenPanel();
                }
            }
            catch (Exception e)
            {
            }
        }

        private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            try
            {
                UpdateNotificationPopup.RearrangeAllPopups();
            }
            catch (Exception e)
            {
            }
        }

        public void HideMainPanelOnly()
        {
            try
            {
                _mainPanel?.Hide();
            }
            catch (Exception e)
            {
            }
        }

        public void Cleanup()
        {
            try
            {
                UnsubscribeFromEvents();

                _notificationButton?.Cleanup();
                _mainPanel?.Cleanup();
                CleanupUpdatePopups();
                _summaryPanel?.Cleanup();

                _notificationButton = null;
                _mainPanel = null;
                _updatePopups.Clear();
                _summaryPanel = null;
                _state = null;
                _animator = null;
                _uiRoot = null;
                _isInitialized = false;
                _popupsVisible = true;
            }
            catch (Exception e)
            {
            }
        }
    }
}