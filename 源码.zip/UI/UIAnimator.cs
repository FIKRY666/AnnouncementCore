﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace AnnouncementCore.UI
{
    public class UIAnimator
    {
        private readonly MonoBehaviour _owner;
        private Coroutine _buttonAnimationCoroutine;

        public UIAnimator(MonoBehaviour owner)
        {
            if (owner == null)
            {
                throw new ArgumentNullException(nameof(owner));
            }

            _owner = owner;
        }

        public void StartButtonRotation(Transform buttonTransform, bool shouldAnimate)
        {
            StopButtonAnimation();

            if (buttonTransform == null)
            {
                return;
            }

            if (!shouldAnimate)
            {
                buttonTransform.localRotation = Quaternion.identity;
                return;
            }

            _buttonAnimationCoroutine = _owner.StartCoroutine(ButtonRotationAnimation(buttonTransform));
        }

        public IEnumerator ScrollViewElasticAnimation(ScrollRect scrollRect, float targetNormalizedPos, float duration = 0.5f)
        {
            if (scrollRect == null) yield break;

            float elapsedTime = 0f;
            float startPos = scrollRect.verticalNormalizedPosition;

            while (elapsedTime < duration)
            {
                if (scrollRect == null) yield break;

                elapsedTime += Time.unscaledDeltaTime;
                float t = elapsedTime / duration;

                float progress = ElasticEaseOut(t);
                scrollRect.verticalNormalizedPosition = Mathf.Lerp(startPos, targetNormalizedPos, progress);

                yield return null;
            }

            if (scrollRect != null)
            {
                scrollRect.verticalNormalizedPosition = targetNormalizedPos;
            }
        }

        public void StopButtonAnimation()
        {
            if (_buttonAnimationCoroutine != null)
            {
                _owner.StopCoroutine(_buttonAnimationCoroutine);
                _buttonAnimationCoroutine = null;
            }
        }

        private IEnumerator ButtonRotationAnimation(Transform buttonTransform)
        {
            float elapsedTime = 0f;
            float duration = 0.2f;
            float maxAngle = 6f;

            while (true)
            {
                if (buttonTransform == null)
                {
                    yield break;
                }

                elapsedTime = 0f;

                while (elapsedTime < duration * 0.2f)
                {
                    if (buttonTransform == null) yield break;

                    elapsedTime += Time.unscaledDeltaTime;
                    float t = elapsedTime / (duration * 0.2f);

                    float angle = -maxAngle * ElasticEaseOut(t);
                    buttonTransform.localRotation = Quaternion.Euler(0, 0, angle);

                    yield return null;
                }

                yield return new WaitForSecondsRealtime(0.03f);

                elapsedTime = 0f;
                if (buttonTransform == null) yield break;
                Quaternion startRot = buttonTransform.localRotation;

                while (elapsedTime < duration * 0.2f)
                {
                    if (buttonTransform == null) yield break;

                    elapsedTime += Time.unscaledDeltaTime;
                    float t = elapsedTime / (duration * 0.2f);

                    buttonTransform.localRotation = Quaternion.Slerp(startRot, Quaternion.identity, t);
                    yield return null;
                }

                elapsedTime = 0f;
                while (elapsedTime < duration * 0.2f)
                {
                    if (buttonTransform == null) yield break;

                    elapsedTime += Time.unscaledDeltaTime;
                    float t = elapsedTime / (duration * 0.2f);

                    float angle = maxAngle * ElasticEaseOut(t);
                    buttonTransform.localRotation = Quaternion.Euler(0, 0, angle);

                    yield return null;
                }

                elapsedTime = 0f;
                if (buttonTransform == null) yield break;
                startRot = buttonTransform.localRotation;

                while (elapsedTime < duration * 0.2f)
                {
                    if (buttonTransform == null) yield break;

                    elapsedTime += Time.unscaledDeltaTime;
                    float t = elapsedTime / (duration * 0.2f);

                    buttonTransform.localRotation = Quaternion.Slerp(startRot, Quaternion.identity, t);
                    yield return null;
                }

                yield return new WaitForSecondsRealtime(0.4f);
            }
        }

        public IEnumerator PanelShowAnimation(Transform panelTransform, CanvasGroup canvasGroup, Action onComplete = null)
        {
            if (panelTransform == null || canvasGroup == null)
            {
                onComplete?.Invoke();
                yield break;
            }

            float elapsedTime = 0f;
            float duration = 0.25f;

            panelTransform.localScale = new Vector3(0.7f, 0.7f, 0.7f);
            canvasGroup.alpha = 0f;
            panelTransform.gameObject.SetActive(true);

            while (elapsedTime < duration)
            {
                if (panelTransform == null || canvasGroup == null)
                {
                    break;
                }

                elapsedTime += Time.unscaledDeltaTime;
                float t = elapsedTime / duration;

                float scale = 0.9f + (1.0f - 0.95f) * BackEaseOut(t);
                float alpha = QuadEaseOut(t);

                panelTransform.localScale = new Vector3(scale, scale, scale);
                canvasGroup.alpha = alpha;
                yield return null;
            }

            if (panelTransform != null && canvasGroup != null)
            {
                panelTransform.localScale = Vector3.one;
                canvasGroup.alpha = 1f;
            }

            onComplete?.Invoke();
        }

        public IEnumerator PanelHideAnimation(Transform panelTransform, CanvasGroup canvasGroup, Action onComplete = null)
        {
            if (panelTransform == null || canvasGroup == null)
            {
                onComplete?.Invoke();
                yield break;
            }

            float elapsedTime = 0f;
            float duration = 0.05f;

            Vector3 startScale = panelTransform.localScale;
            float startAlpha = canvasGroup.alpha;

            while (elapsedTime < duration)
            {
                if (panelTransform == null || canvasGroup == null)
                {
                    break;
                }

                elapsedTime += Time.unscaledDeltaTime;
                float t = elapsedTime / duration;

                float scale = Mathf.Lerp(startScale.x, 0.95f, QuadEaseOut(t));
                float alpha = Mathf.Lerp(startAlpha, 0f, QuadEaseOut(t));

                panelTransform.localScale = new Vector3(scale, scale, scale);
                canvasGroup.alpha = alpha;
                yield return null;
            }

            if (panelTransform != null && canvasGroup != null)
            {
                panelTransform.localScale = new Vector3(0.85f, 0.85f, 0.85f);
                canvasGroup.alpha = 0f;
                panelTransform.gameObject.SetActive(false);
            }

            onComplete?.Invoke();
        }

        public IEnumerator ButtonBounceAnimation(Transform buttonTransform, float intensity = 0.12f, float duration = 0.25f)
        {
            if (buttonTransform == null) yield break;

            float elapsedTime = 0f;
            Vector3 originalScale = buttonTransform.localScale;

            while (elapsedTime < duration)
            {
                if (buttonTransform == null) yield break;

                elapsedTime += Time.unscaledDeltaTime;
                float t = elapsedTime / duration;

                float bounce = ElasticEaseOut(t) * intensity;
                buttonTransform.localScale = originalScale * (1f + bounce);
                yield return null;
            }

            if (buttonTransform != null)
            {
                buttonTransform.localScale = originalScale;
            }
        }

        public IEnumerator PanelElasticShowAnimation(Transform panelTransform, CanvasGroup canvasGroup, Action onComplete = null)
        {
            if (panelTransform == null || canvasGroup == null)
            {
                onComplete?.Invoke();
                yield break;
            }

            float elapsedTime = 0f;
            float duration = 0.25f;

            panelTransform.localScale = new Vector3(0.95f, 0.95f, 0.95f);
            canvasGroup.alpha = 0f;
            panelTransform.gameObject.SetActive(true);

            while (elapsedTime < duration)
            {
                if (panelTransform == null || canvasGroup == null)
                {
                    break;
                }

                elapsedTime += Time.unscaledDeltaTime;
                float t = elapsedTime / duration;

                float scale = Mathf.Lerp(0.95f, 1.0f, QuadEaseOut(t));
                float alpha = QuadEaseOut(t);

                panelTransform.localScale = Vector3.one * scale;
                canvasGroup.alpha = alpha;
                yield return null;
            }

            if (panelTransform != null && canvasGroup != null)
            {
                panelTransform.localScale = Vector3.one;
                canvasGroup.alpha = 1f;
            }

            onComplete?.Invoke();
        }

        private float ElasticEaseOut(float t)
        {
            if (t >= 1) return 1;

            float p = 0.3f;
            float s = p / 4f;

            return Mathf.Pow(2, -10 * t) * Mathf.Sin((t - s) * (2 * Mathf.PI) / p) + 1;
        }

        private float BackEaseOut(float t)
        {
            float c1 = 1.70158f;
            float c3 = c1 + 1;

            return 1 + c3 * Mathf.Pow(t - 1, 3) + c1 * Mathf.Pow(t - 1, 2);
        }

        private float QuadEaseOut(float t)
        {
            return 1 - (1 - t) * (1 - t);
        }

        public void Cleanup()
        {
            StopButtonAnimation();
        }
    }
}