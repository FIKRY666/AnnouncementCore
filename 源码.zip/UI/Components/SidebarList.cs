﻿using AnnouncementCore.Data;
using AnnouncementCore.Utility;
using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace AnnouncementCore.UI.Components
{
    public class SidebarList : MonoBehaviour
    {
        private ScrollRect _scrollRect;
        private RectTransform _content;
        private AnnouncementState _state;

        private Dictionary<string, SidebarItem> _items = new Dictionary<string, SidebarItem>();
        private Action<string> _onItemClick;

        public void Initialize(AnnouncementState state, Action<string> onItemClick)
        {
            _state = state;
            _onItemClick = onItemClick;

            CreateScrollView();

            AnnouncementState.OnAnnouncementSelected += OnAnnouncementSelected;
            AnnouncementState.OnAnnouncementRead += OnAnnouncementRead;
        }

        private void CreateScrollView()
        {
            gameObject.AddComponent<RectTransform>();
            _scrollRect = gameObject.AddComponent<ScrollRect>();
            _scrollRect.horizontal = false;
            _scrollRect.vertical = true;
            _scrollRect.movementType = ScrollRect.MovementType.Clamped;

            GameObject viewport = new GameObject("Viewport", typeof(RectTransform), typeof(Mask), typeof(Image));
            Image image = viewport.GetComponent<Image>();
            image.sprite = ResourceLoader.LoadSprite("sidebar_bg");
            viewport.transform.SetParent(transform, false);
            RectTransform viewportRect = viewport.GetComponent<RectTransform>();
            viewportRect.anchorMin = Vector2.zero;
            viewportRect.anchorMax = Vector2.one;
            viewportRect.sizeDelta = Vector2.zero;

            GameObject content = new GameObject("Content", typeof(RectTransform), typeof(VerticalLayoutGroup), typeof(ContentSizeFitter));
            content.transform.SetParent(viewport.transform, false);
            _content = content.GetComponent<RectTransform>();
            _content.anchorMin = new Vector2(0, 1);
            _content.anchorMax = new Vector2(1, 1);
            _content.pivot = new Vector2(0.5f, 1);
            _content.sizeDelta = new Vector2(0, 0);

            VerticalLayoutGroup layout = content.GetComponent<VerticalLayoutGroup>();
            layout.padding = new RectOffset(10, 10, 10, 10);
            layout.spacing = 8;
            layout.childControlHeight = false;
            layout.childForceExpandHeight = false;

            ContentSizeFitter fitter = content.GetComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            _scrollRect.viewport = viewportRect;
            _scrollRect.content = _content;
        }

        public void Refresh(List<AnnouncementConfig> configs)
        {
            foreach (var item in _items.Values)
            {
                Destroy(item.gameObject);
            }
            _items.Clear();

            foreach (var config in configs)
            {
                CreateItem(config);
            }

            LayoutRebuilder.ForceRebuildLayoutImmediate(_content);
        }

        private void CreateItem(AnnouncementConfig config)
        {
            GameObject itemObj = new GameObject($"SidebarItem_{config.ModId}", typeof(RectTransform));
            itemObj.transform.SetParent(_content, false);

            RectTransform rect = itemObj.GetComponent<RectTransform>();
            rect.sizeDelta = new Vector2(200, 68);

            LayoutElement layoutElement = itemObj.AddComponent<LayoutElement>();
            layoutElement.preferredHeight = 68;
            layoutElement.minHeight = 68;

            Image background = itemObj.AddComponent<Image>();
            background.type = Image.Type.Sliced;

            Button button = itemObj.AddComponent<Button>();

            SidebarItem sidebarItem = itemObj.AddComponent<SidebarItem>();
            sidebarItem.Background = background;
            sidebarItem.Button = button;

            CreateItemComponents(itemObj, sidebarItem);

            sidebarItem.Initialize(config, _state, _onItemClick);
            _items[config.ModId] = sidebarItem;
        }

        private void CreateItemComponents(GameObject parent, SidebarItem sidebarItem)
        {
            GameObject nameObj = new GameObject("ModName", typeof(RectTransform), typeof(TextMeshProUGUI));
            nameObj.transform.SetParent(parent.transform, false);
            RectTransform nameRect = nameObj.GetComponent<RectTransform>();
            nameRect.anchorMin = new Vector2(0.05f, 0.5f);
            nameRect.anchorMax = new Vector2(0.95f, 0.9f);
            nameRect.offsetMin = Vector2.zero;
            nameRect.offsetMax = Vector2.zero;
            sidebarItem.NameText = nameObj.GetComponent<TextMeshProUGUI>();
            sidebarItem.NameText.fontSize = 13;
            sidebarItem.NameText.enableWordWrapping = true;

            GameObject versionObj = new GameObject("ModVersion", typeof(RectTransform), typeof(TextMeshProUGUI));
            versionObj.transform.SetParent(parent.transform, false);
            RectTransform versionRect = versionObj.GetComponent<RectTransform>();
            versionRect.anchorMin = new Vector2(0.05f, 0.1f);
            versionRect.anchorMax = new Vector2(0.95f, 0.5f);
            versionRect.offsetMin = Vector2.zero;
            versionRect.offsetMax = Vector2.zero;
            sidebarItem.VersionText = versionObj.GetComponent<TextMeshProUGUI>();
            sidebarItem.VersionText.fontSize = 13;

            GameObject badgeObj = new GameObject("UnreadBadge", typeof(RectTransform), typeof(Image));
            badgeObj.transform.SetParent(parent.transform, false);
            RectTransform badgeRect = badgeObj.GetComponent<RectTransform>();
            badgeRect.anchorMin = new Vector2(1, 1);
            badgeRect.anchorMax = new Vector2(1, 1);
            badgeRect.pivot = new Vector2(1, 1);
            badgeRect.anchoredPosition = new Vector2(-15, -15);
            badgeRect.sizeDelta = new Vector2(8, 8);
            badgeObj.GetComponent<Image>().color = new Color(1f, 0.9176471f, 0.5803922f, 1f);
            sidebarItem.UnreadBadge = badgeObj;
        }

        private void OnAnnouncementSelected(string modId)
        {
            foreach (var kvp in _items)
            {
                kvp.Value.SetSelected(kvp.Key == modId);
            }
        }

        private void OnAnnouncementRead(string modId)
        {
            if (_items.TryGetValue(modId, out var item))
            {
                item.UpdateReadStatus();
            }
        }

        public void Cleanup()
        {
            AnnouncementState.OnAnnouncementSelected -= OnAnnouncementSelected;
            AnnouncementState.OnAnnouncementRead -= OnAnnouncementRead;

            foreach (var item in _items.Values)
            {
                Destroy(item.gameObject);
            }
            _items.Clear();
        }
    }
}