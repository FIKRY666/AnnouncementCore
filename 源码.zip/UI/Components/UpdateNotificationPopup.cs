﻿using AnnouncementCore.Data;
using AnnouncementCore.UI.Effects;
using AnnouncementCore.Utility;
using Steamworks;
using System;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace AnnouncementCore.UI.Components
{
    public class UpdateNotificationPopup : MonoBehaviour
    {
        private const float POPUP_WIDTH = 375f;
        private const float POPUP_HEIGHT = 130f;
        private const float POPUP_SPACING = 10f;
        private const float BASE_Y_POSITION = -100f;

        private AnnouncementConfig _config;
        private AnnouncementState _state;
        private UIAnimator _animator;
        private Transform _uiRoot;
        private GameObject _popupObject;
        private CanvasGroup _canvasGroup;

        private bool _isInitialized = false;
        private bool _isVisible = false;
        private int _popupIndex = 0;
        public string ModId => _config?.ModId;
        public bool IsPermanentUpdate => _config?.HasPermanentUpdate ?? false;

        private static List<UpdateNotificationPopup> _allPopups = new List<UpdateNotificationPopup>();

        private enum PopupType
        {
            PermanentUpdate,
            UnreadAnnouncement
        }
        private PopupType _popupType;

        public void Initialize(AnnouncementConfig config, AnnouncementState state,
            Transform uiRoot, UIAnimator animator, int index = 0)
        {
            try
            {
                _popupType = config.HasPermanentUpdate ? PopupType.PermanentUpdate : PopupType.UnreadAnnouncement;

                if (!state.ShouldShowPopup(config.ModId))
                {
                    Destroy(gameObject);
                    return;
                }

                _config = config;
                _state = state;
                _uiRoot = uiRoot;
                _animator = animator;
                _popupIndex = index;

                CreatePopup();
                _isInitialized = true;
                _allPopups.Add(this);

                AnnouncementState.OnAnnouncementRead += OnAnnouncementRead;
                AnnouncementState.OnPopupShouldHide += OnPopupShouldHide;
            }
            catch (Exception e)
            {
                Debug.LogError($"UpdateNotificationPopup初始化失败: {e}");
            }
        }

        private void OnAnnouncementRead(string modId)
        {
            try
            {
                if (_config == null || _config.ModId != modId) return;

                if (_popupType == PopupType.UnreadAnnouncement)
                {
                    HideWithAnimation();
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"处理已读事件失败: {e}");
            }
        }

        private void OnPopupShouldHide(string modId)
        {
            try
            {
                if (_config == null || _config.ModId != modId) return;

                if (_popupType == PopupType.UnreadAnnouncement)
                {
                    _state?.MarkPopupAsHidden(modId);
                    HideWithAnimation();
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"处理弹窗隐藏事件失败: {e}");
            }
        }

        private void HideWithAnimation()
        {
            if (!_isInitialized || _popupObject == null) return;

            try
            {
                _canvasGroup.interactable = false;
                _canvasGroup.blocksRaycasts = false;
                _isVisible = false;

                if (_animator != null)
                {
                    StartCoroutine(_animator.PanelHideAnimation(
                        _popupObject.transform,
                        _canvasGroup,
                        () => OnHideComplete()
                    ));
                }
                else
                {
                    StartCoroutine(SimpleHideAnimation());
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"隐藏弹窗失败: {e}");
            }
        }

        private System.Collections.IEnumerator SimpleHideAnimation()
        {
            float elapsedTime = 0f;
            float duration = 0.2f;
            float startAlpha = _canvasGroup.alpha;

            while (elapsedTime < duration)
            {
                if (_popupObject == null) yield break;

                elapsedTime += Time.deltaTime;
                float t = elapsedTime / duration;
                _canvasGroup.alpha = Mathf.Lerp(startAlpha, 0f, 1 - (1 - t) * (1 - t));
                yield return null;
            }

            OnHideComplete();
        }

        private void CreatePopup()
        {
            try
            {
                CreatePopupContainer();
                CreatePopupBackground();
                CreateCenterContainer();
                CreateUIElements();

                _popupObject.SetActive(false);
            }
            catch (Exception e)
            {
                Debug.LogError($"创建弹窗失败: {e}");
                CleanupTempObjects();
            }
        }

        private void CreatePopupContainer()
        {
            _popupObject = new GameObject($"UpdatePopup_{_config.ModId}");
            _popupObject.transform.SetParent(_uiRoot, false);

            var rect = _popupObject.AddComponent<RectTransform>();
            rect.anchorMin = new Vector2(1, 1);
            rect.anchorMax = new Vector2(1, 1);
            rect.pivot = new Vector2(1, 1);
            float baseY = BASE_Y_POSITION - 80;
            float yPosition = baseY - (_popupIndex * (POPUP_HEIGHT + POPUP_SPACING));

            rect.anchoredPosition = new Vector2(-20, yPosition);
            rect.sizeDelta = new Vector2(POPUP_WIDTH, POPUP_HEIGHT);

            _canvasGroup = _popupObject.AddComponent<CanvasGroup>();
            _canvasGroup.alpha = 0f;
            _canvasGroup.interactable = false;
            _canvasGroup.blocksRaycasts = false;
        }

        private void CreatePopupBackground()
        {
            var bg = _popupObject.AddComponent<Image>();
            bg.sprite = LoadSprite("update_popup_background");

            if (bg.sprite == null)
            {
                bg.color = new Color(0.15f, 0.15f, 0.2f, 0.95f);
            }
            else
            {
                bg.type = Image.Type.Sliced;
            }
        }

        private void CreateCenterContainer()
        {
            GameObject centerContainer = new GameObject("CenterContainer");
            var rect = centerContainer.AddComponent<RectTransform>();
            rect.SetParent(_popupObject.transform, false);

            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = Vector2.zero;
            rect.sizeDelta = new Vector2(POPUP_WIDTH, POPUP_HEIGHT);
        }

        private void CreateUIElements()
        {
            var centerContainer = _popupObject.transform.Find("CenterContainer");

            CreateTitleText(centerContainer, new Vector2(-62, 15), new Vector2(215, 70));
            CreateVersionText(centerContainer, new Vector2(-53, -35), new Vector2(240, 28));
            CreateAnnouncementButton(centerContainer, new Vector2(135.5f, 31), new Vector2(80, 44));

            if (!string.IsNullOrEmpty(_config.SteamWorkshopId))
            {
                CreateSteamButton(centerContainer, new Vector2(135.5f, -28), new Vector2(80, 54));
            }
        }

        private void CreateTitleText(Transform parent, Vector2 position, Vector2 size)
        {
            GameObject titleObj = new GameObject("Title");
            var rect = titleObj.AddComponent<RectTransform>();
            rect.SetParent(parent, false);

            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = size;

            var text = titleObj.AddComponent<TextMeshProUGUI>();
            text.text = FormatTitleForTwoLines(_config.DisplayName);
            text.fontSize = 20;
            text.fontStyle = FontStyles.Bold;
            text.alignment = TextAlignmentOptions.TopLeft;
            text.color = Color.white;
            text.enableWordWrapping = true;
            text.lineSpacing = -15f;
        }

        private string FormatTitleForTwoLines(string originalTitle)
        {
            if (string.IsNullOrEmpty(originalTitle)) return "";

            string cleanTitle = originalTitle.Trim();

            if (cleanTitle.Length <= 16) return cleanTitle;

            int breakPoint = Math.Min(15, cleanTitle.Length);
            string firstLine = cleanTitle.Substring(0, breakPoint);
            string secondLine = cleanTitle.Substring(breakPoint);

            if (secondLine.Length > 15)
            {
                secondLine = secondLine.Substring(0, 15) + "...";
            }

            return firstLine + "\n" + secondLine;
        }

        private void CreateVersionText(Transform parent, Vector2 position, Vector2 size)
        {
            GameObject versionObj = new GameObject("Version");
            var rect = versionObj.AddComponent<RectTransform>();
            rect.SetParent(parent, false);

            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = size;

            var text = versionObj.AddComponent<TextMeshProUGUI>();

            bool isUnread = !_state.IsRead(_config.ModId);
            string colorHex = isUnread ? "#FFEA94" : "#FFFFFF";

            text.text = $"<color={colorHex}>NEW: {_config.LatestVersion}</color>\n当前: v{_config.Version}";
            text.fontSize = 16;
            text.fontStyle = FontStyles.Bold;
            text.alignment = TextAlignmentOptions.Left;
            text.color = Color.white;
            text.enableWordWrapping = true;
        }

        private void CreateAnnouncementButton(Transform parent, Vector2 position, Vector2 size)
        {
            var button = CreatePopupButton(parent, position, size,
                "AnnouncementButton", "update_popup_announcement_bg",
                new Color(0.2f, 0.4f, 0.8f, 1f));

            button.onClick.AddListener(() => OnAnnouncementButtonClicked());
        }

        private void CreateSteamButton(Transform parent, Vector2 position, Vector2 size)
        {
            var button = CreatePopupButton(parent, position, size,
                "SteamButton", "update_popup_steam_bg",
                new Color(0.1f, 0.5f, 0.2f, 1f));

            button.onClick.AddListener(() => OnSteamButtonClicked());
        }

        private Button CreatePopupButton(Transform parent, Vector2 position, Vector2 size,
            string name, string spriteName, Color fallbackColor)
        {
            GameObject buttonObj = new GameObject(name);
            var rect = buttonObj.AddComponent<RectTransform>();
            rect.SetParent(parent, false);

            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = size;

            var img = buttonObj.AddComponent<Image>();
            img.sprite = LoadSprite(spriteName);
            if (img.sprite == null) img.color = fallbackColor;
            img.type = Image.Type.Sliced;

            var button = buttonObj.AddComponent<Button>();
            button.onClick.AddListener(() => OnPopupButtonClicked(button.transform));

            var hoverEffect = buttonObj.AddComponent<ConsolidatedHoverEffect>();
            hoverEffect.ButtonImage = img;
            hoverEffect.ButtonComponent = button;
            hoverEffect.SetEffectType(ConsolidatedHoverEffect.EffectType.PopupButton);

            return button;
        }

        private void OnPopupButtonClicked(Transform buttonTransform)
        {
            AudioUtility.PlayClickSound();
            StartCoroutine(PlayButtonClickAnimation(buttonTransform));
        }

        private void OnAnnouncementButtonClicked()
        {
            try
            {
                var uiManager = GetComponentInParent<UIManager>();
                if (uiManager != null)
                {
                    uiManager.OpenAnnouncementFromPopup(_config.ModId);
                }
                else
                {
                    _state?.SelectAnnouncement(_config.ModId);
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"处理公告按钮点击失败: {e}");
            }
        }

        private void OnSteamButtonClicked()
        {
            try
            {
                if (string.IsNullOrEmpty(_config.SteamWorkshopUrl)) return;

                if (IsSteamRunning())
                {
                    SteamFriends.ActivateGameOverlayToWebPage(_config.SteamWorkshopUrl);
                }
                else
                {
                    Application.OpenURL(_config.SteamWorkshopUrl);
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"打开Steam页面失败: {e}");

                if (!string.IsNullOrEmpty(_config.SteamWorkshopUrl))
                {
                    Application.OpenURL(_config.SteamWorkshopUrl);
                }
            }
        }

        private System.Collections.IEnumerator PlayButtonClickAnimation(Transform buttonTransform)
        {
            if (buttonTransform == null) yield break;

            float elapsedTime = 0f;
            float duration = 0.2f;
            Vector3 originalScale = buttonTransform.localScale;

            buttonTransform.localScale = originalScale * 0.85f;

            while (elapsedTime < duration)
            {
                if (buttonTransform == null) yield break;

                elapsedTime += Time.deltaTime;
                float t = elapsedTime / duration;
                float scale = Mathf.Lerp(0.85f, 1.0f, Mathf.Pow(2, -10 * t) * Mathf.Sin((t - 0.075f) * (2 * Mathf.PI) / 0.3f) + 1);
                buttonTransform.localScale = originalScale * scale;

                yield return null;
            }

            if (buttonTransform != null)
            {
                buttonTransform.localScale = originalScale;
            }
        }

        public void Show()
        {
            if (!_isInitialized || _popupObject == null) return;

            try
            {
                _popupObject.SetActive(true);
                _canvasGroup.interactable = true;
                _canvasGroup.blocksRaycasts = true;

                if (_animator != null)
                {
                    StartCoroutine(_animator.PanelElasticShowAnimation(
                        _popupObject.transform,
                        _canvasGroup,
                        () => _isVisible = true
                    ));
                }
                else
                {
                    _canvasGroup.alpha = 1f;
                    _isVisible = true;
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"显示弹窗失败: {e}");
            }
        }

        public void Hide()
        {
            if (!_isInitialized || _popupObject == null) return;

            try
            {
                _canvasGroup.interactable = false;
                _canvasGroup.blocksRaycasts = false;
                _isVisible = false;

                if (_animator != null)
                {
                    StartCoroutine(_animator.PanelHideAnimation(
                        _popupObject.transform,
                        _canvasGroup,
                        () => OnHideComplete()
                    ));
                }
                else
                {
                    _canvasGroup.alpha = 0f;
                    OnHideComplete();
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"隐藏弹窗失败: {e}");
            }
        }

        private void OnHideComplete()
        {
            _popupObject.SetActive(false);
            _allPopups.Remove(this);
        }

        public static int GetPopupCount() => _allPopups.Count;

        public static void CleanupAll()
        {
            try
            {
                foreach (var popup in _allPopups.ToArray())
                {
                    popup?.Cleanup();
                }
                _allPopups.Clear();
            }
            catch (Exception e)
            {
                Debug.LogError($"清理所有弹窗失败: {e}");
            }
        }

        public static void RearrangeAllPopups()
        {
            try
            {
                var activePopups = _allPopups
                    .Where(p => p != null && p._popupObject != null && p._popupObject.activeSelf)
                    .ToList();

                activePopups.Sort((a, b) => a._popupIndex.CompareTo(b._popupIndex));

                for (int i = 0; i < activePopups.Count; i++)
                {
                    var popup = activePopups[i];
                    var rect = popup._popupObject.GetComponent<RectTransform>();
                    if (rect == null) continue;

                    float baseY = BASE_Y_POSITION - 80;
                    float yPosition = baseY - (i * (POPUP_HEIGHT + POPUP_SPACING));
                    rect.anchoredPosition = new Vector2(-20, yPosition);

                    popup._popupIndex = i;
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"重新排列弹窗失败: {e}");
            }
        }

        private void OnEnable()
        {
            SceneManager.sceneLoaded += OnSceneLoaded;
        }

        private void OnDisable()
        {
            SceneManager.sceneLoaded -= OnSceneLoaded;
        }

        private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            try
            {
                if (_isVisible && _popupObject != null && _canvasGroup != null)
                {
                    _canvasGroup.interactable = true;
                    _canvasGroup.blocksRaycasts = true;
                    _canvasGroup.alpha = 1f;
                    _popupObject.SetActive(true);
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"处理场景加载事件失败: {e}");
            }
        }

        private bool IsSteamRunning()
        {
            try
            {
                return SteamAPI.IsSteamRunning();
            }
            catch
            {
                return false;
            }
        }

        private Sprite LoadSprite(string spriteName)
        {
            try
            {
                var sprite = ResourceLoader.LoadSprite(spriteName);

                if (sprite == null)
                {
                    switch (spriteName)
                    {
                        case "update_popup_background":
                            sprite = ResourceLoader.LoadSprite("popup_bg");
                            break;
                        case "update_popup_announcement_bg":
                        case "update_popup_steam_bg":
                            sprite = ResourceLoader.LoadSprite("update_popup_btn_bg");
                            break;
                        case "update_popup_btn_bg":
                            sprite = ResourceLoader.LoadSprite("button_bg");
                            break;
                    }
                }

                return sprite;
            }
            catch
            {
                return null;
            }
        }

        private void CleanupTempObjects()
        {
            if (_popupObject != null)
            {
                Destroy(_popupObject);
                _popupObject = null;
            }
        }

        public void Cleanup()
        {
            try
            {
                AnnouncementState.OnAnnouncementRead -= OnAnnouncementRead;
                AnnouncementState.OnPopupShouldHide -= OnPopupShouldHide;

                if (_popupObject != null)
                {
                    Destroy(_popupObject);
                    _popupObject = null;
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"清理弹窗失败: {e}");
            }

            _canvasGroup = null;
            _config = null;
            _state = null;
            _animator = null;
            _uiRoot = null;
            _isInitialized = false;
            _isVisible = false;
        }
    }
}