﻿using AnnouncementCore.Data;
using AnnouncementCore.UI.Effects;
using AnnouncementCore.Utility;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace AnnouncementCore.UI.Components
{
    public class SidebarItem : MonoBehaviour
    {
        public Image Background;
        public Button Button;
        public TextMeshProUGUI NameText;
        public TextMeshProUGUI VersionText;
        public GameObject UnreadBadge;
        public Image BadgeImage;

        private AnnouncementConfig _config;
        private AnnouncementState _state;
        private string _modId;
        private bool _isSelected = false;
        private bool _isUnread = false;

        private Coroutine _badgeAnimationCoroutine;
        private Vector3 _originalBadgeScale;

        private static readonly Color SELECTED_COLOR = new Color(0.2f, 0.2f, 0.3f, 1f);
        private static readonly Color UNREAD_COLOR = new Color(0.3f, 0.3f, 0.4f, 1f);
        private static readonly Color READ_COLOR = new Color(0.1f, 0.1f, 0.15f, 0.8f);
        private static readonly Color UNREAD_TEXT_COLOR = new Color(1f, 0.9176471f, 0.5803922f, 1f);
        private static readonly Color READ_TEXT_COLOR = new Color(0.8f, 0.8f, 0.8f, 1f);

        public void Initialize(AnnouncementConfig config, AnnouncementState state, System.Action<string> onClick)
        {
            _config = config;
            _state = state;
            _modId = config.ModId;
            _isUnread = !state.IsRead(_modId);

            InitializeBadge();
            UpdateUI();

            Button.onClick.AddListener(() =>
            {
                AudioUtility.PlayClickSound();
                StartCoroutine(PlayClickAnimation());
                onClick?.Invoke(_modId);
            });

            var hoverEffect = gameObject.AddComponent<ButtonHoverEffect>();
            hoverEffect.ButtonImage = Background;
            hoverEffect.ButtonComponent = Button;
            hoverEffect.ConfigureForSidebarItem();
        }

        private void InitializeBadge()
        {
            try
            {
                if (UnreadBadge == null) return;

                BadgeImage = UnreadBadge.GetComponent<Image>();
                if (BadgeImage == null)
                {
                    BadgeImage = UnreadBadge.AddComponent<Image>();
                }

                Sprite badgeSprite = LoadSprite("unread_badge");
                if (badgeSprite != null)
                {
                    BadgeImage.sprite = badgeSprite;
                    BadgeImage.type = Image.Type.Simple;
                    BadgeImage.preserveAspect = true;
                }
                else
                {
                    BadgeImage.color = UNREAD_TEXT_COLOR;
                }

                _originalBadgeScale = UnreadBadge.transform.localScale;
                UnreadBadge.SetActive(false);
            }
            catch (System.Exception e)
            {
                Debug.LogError($"初始化角标失败: {e}");
            }
        }

        private System.Collections.IEnumerator PlayClickAnimation()
        {
            float elapsedTime = 0f;
            float duration = 0.2f;
            Vector3 originalScale = transform.localScale;

            transform.localScale = originalScale * 0.85f;

            while (elapsedTime < duration)
            {
                elapsedTime += Time.unscaledDeltaTime;
                float t = elapsedTime / duration;
                float scale = Mathf.Lerp(0.85f, 1.0f, ElasticEaseOut(t));
                transform.localScale = originalScale * scale;
                yield return null;
            }

            transform.localScale = originalScale;
        }

        private float ElasticEaseOut(float t)
        {
            if (t >= 1) return 1;
            float p = 0.3f;
            float s = p / 4f;
            return Mathf.Pow(2, -10 * t) * Mathf.Sin((t - s) * (2 * Mathf.PI) / p) + 1;
        }

        public void SetSelected(bool selected)
        {
            _isSelected = selected;
            UpdateUI();
        }

        public void UpdateReadStatus()
        {
            bool wasUnread = _isUnread;
            _isUnread = !_state.IsRead(_modId);

            if (wasUnread && !_isUnread)
            {
                StopBadgeAnimation();
                HideBadge();
            }

            UpdateUI();
        }

        private void UpdateUI()
        {
            try
            {
                if (_isSelected)
                {
                    Background.sprite = LoadSprite("list_item_selected");
                    if (Background.sprite == null) Background.color = SELECTED_COLOR;
                }
                else if (_isUnread)
                {
                    Background.sprite = LoadSprite("list_item_unread");
                    if (Background.sprite == null) Background.color = UNREAD_COLOR;
                    ShowBadgeAndStartAnimation();
                }
                else
                {
                    Background.sprite = LoadSprite("list_item_normal");
                    if (Background.sprite == null) Background.color = READ_COLOR;
                    HideBadge();
                }

                if (NameText != null)
                {
                    NameText.text = _config.DisplayName;
                    NameText.color = _isUnread ? Color.white : READ_TEXT_COLOR;
                }

                if (VersionText != null)
                {
                    VersionText.text = $"v{_config.Version}";
                    VersionText.color = _isUnread ? UNREAD_TEXT_COLOR : READ_TEXT_COLOR;
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"更新UI失败: {e}");
            }
        }

        private void ShowBadgeAndStartAnimation()
        {
            if (UnreadBadge == null || BadgeImage == null) return;

            try
            {
                UnreadBadge.SetActive(true);

                Sprite badgeSprite = LoadSprite("unread_badge");
                if (badgeSprite != null)
                {
                    BadgeImage.sprite = badgeSprite;
                }

                BadgeImage.color = Color.white;

                if (_badgeAnimationCoroutine == null)
                {
                    _badgeAnimationCoroutine = StartCoroutine(BadgePulseAnimation());
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"显示角标失败: {e}");
            }
        }

        private void HideBadge()
        {
            if (UnreadBadge == null) return;

            try
            {
                UnreadBadge.SetActive(false);
                StopBadgeAnimation();
                UnreadBadge.transform.localScale = _originalBadgeScale;
            }
            catch (System.Exception e)
            {
                Debug.LogError($"隐藏角标失败: {e}");
            }
        }

        private System.Collections.IEnumerator BadgePulseAnimation()
        {
            float animationSpeed = 2.5f;
            float minScale = 0.9f;
            float maxScale = 1.1f;
            float baseScale = 1.0f;

            if (UnreadBadge == null || BadgeImage == null) yield break;

            while (_isUnread && UnreadBadge.activeSelf)
            {
                float pulseValue = Mathf.Sin(Time.unscaledTime * animationSpeed);
                float normalizedPulse = (pulseValue + 1f) / 2f;
                float currentScale = Mathf.Lerp(minScale, maxScale, normalizedPulse) * baseScale;
                UnreadBadge.transform.localScale = new Vector3(currentScale, currentScale, 1f);
                yield return null;
            }

            if (UnreadBadge != null)
            {
                UnreadBadge.transform.localScale = _originalBadgeScale;
                UnreadBadge.transform.localRotation = Quaternion.identity;
            }

            _badgeAnimationCoroutine = null;
        }

        private void StopBadgeAnimation()
        {
            if (_badgeAnimationCoroutine != null)
            {
                StopCoroutine(_badgeAnimationCoroutine);
                _badgeAnimationCoroutine = null;
            }

            if (UnreadBadge != null)
            {
                UnreadBadge.transform.localScale = _originalBadgeScale;
                UnreadBadge.transform.localRotation = Quaternion.identity;
            }
        }

        private Sprite LoadSprite(string spriteName)
        {
            try
            {
                if (string.IsNullOrEmpty(spriteName)) return null;

                Sprite sprite = ResourceLoader.LoadSprite(spriteName);

                if (sprite == null)
                {
                    string alternativeName = spriteName.ToLower().Replace("_", "");
                    sprite = ResourceLoader.LoadSprite(alternativeName);

                    if (sprite == null)
                    {
                        string cleanName = spriteName.Replace("_", "").Replace("-", "");
                        sprite = ResourceLoader.LoadSprite(cleanName);
                    }
                }

                return sprite;
            }
            catch (System.Exception e)
            {
                Debug.LogError($"加载素材图片失败 {spriteName}: {e}");
                return null;
            }
        }

        private void OnDestroy()
        {
            StopBadgeAnimation();

            if (Button != null)
            {
                Button.onClick.RemoveAllListeners();
            }
        }
    }
}