﻿using AnnouncementCore.UI.Effects;
using AnnouncementCore.Utility;
using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace AnnouncementCore.UI.Components
{
    public class NotificationButton : MonoBehaviour
    {
        private GameObject _buttonObject;
        private Image _buttonImage;
        private GameObject _badgeObject;
        private Image _badgeImage;
        private TextMeshProUGUI _badgeText;
        private ConsolidatedHoverEffect _hoverEffect;
        private Button _buttonComponent;

        private bool _isInitialized = false;
        public bool IsInitialized => _isInitialized;

        private int _currentUnreadCount = 0;
        private System.Action _onClickCallback;

        private Coroutine _breathingAnimationCoroutine;
        private Vector3 _originalButtonScale;
        private Vector3 _originalButtonRotation;

        private const float BUTTON_ROTATION_AMPLITUDE = 3f;
        private const float BUTTON_ROTATION_SPEED = 1.5f;
        private const float BUTTON_SCALE_AMPLITUDE = 0.05f;
        private const float BUTTON_SCALE_SPEED = 2f;
        private const float BADGE_SCALE_AMPLITUDE = 0.15f;
        private const float BADGE_SCALE_SPEED = 2.2f;
        private const float BADGE_ROTATION_AMPLITUDE = 2f;
        private const float BADGE_ROTATION_SPEED = 1.8f;
        private const float BUTTON_SCALE_PHASE_OFFSET = 0.3f;
        private const float BADGE_SCALE_PHASE_OFFSET = 0.7f;
        private const float BADGE_ROTATION_PHASE_OFFSET = 0.5f;

        public void HideButton()
        {
            try
            {
                if (_buttonObject != null && _buttonObject.activeSelf)
                {
                    _buttonObject.SetActive(false);
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"隐藏通知按钮失败: {e}");
            }
        }

        public void ShowButton()
        {
            try
            {
                if (_buttonObject != null && !_buttonObject.activeSelf)
                {
                    _buttonObject.SetActive(true);
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"显示通知按钮失败: {e}");
            }
        }

        public void Initialize(Transform parent, System.Action onClick)
        {
            try
            {
                if (parent == null)
                {
                    Debug.LogError("NotificationButton: 父对象为空");
                    return;
                }

                _onClickCallback = onClick;

                CreateButtonObject(parent);
                ConfigureButtonComponents();
                SetupHoverEffect();

                _isInitialized = true;
                _originalButtonScale = _buttonObject.transform.localScale;
                _originalButtonRotation = _buttonObject.transform.localEulerAngles;
            }
            catch (System.Exception e)
            {
                Debug.LogError($"NotificationButton 初始化异常: {e}");
                _isInitialized = false;
            }
        }

        private void CreateButtonObject(Transform parent)
        {
            _buttonObject = new GameObject("NotificationButton");
            _buttonObject.transform.SetParent(parent, false);

            var rect = _buttonObject.AddComponent<RectTransform>();
            rect.anchorMin = new Vector2(1, 1);
            rect.anchorMax = new Vector2(1, 1);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = new Vector2(-60, -60);
            rect.sizeDelta = new Vector2(60, 60);

            _buttonImage = _buttonObject.AddComponent<Image>();
            _buttonImage.sprite = LoadSprite("notification_button");
            if (_buttonImage.sprite == null)
            {
                _buttonImage.color = new Color(0.9f, 0.9f, 0.9f, 0.9f);
            }
            _buttonImage.type = Image.Type.Sliced;
        }

        private void ConfigureButtonComponents()
        {
            _buttonComponent = _buttonObject.AddComponent<Button>();
            _buttonComponent.onClick.AddListener(OnButtonClicked);
        }

        private void SetupHoverEffect()
        {
            _hoverEffect = _buttonObject.AddComponent<ConsolidatedHoverEffect>();
            _hoverEffect.ButtonImage = _buttonImage;
            _hoverEffect.ButtonComponent = _buttonComponent;
            _hoverEffect.SetEffectType(ConsolidatedHoverEffect.EffectType.NotificationButton);
        }

        private void OnButtonClicked()
        {
            AudioUtility.PlayClickSound();

            StartCoroutine(PlayButtonClickAnimation(_buttonObject.transform));

            _onClickCallback?.Invoke();
        }

        private System.Collections.IEnumerator PlayButtonClickAnimation(Transform buttonTransform)
        {
            if (buttonTransform == null) yield break;

            bool wasAnimating = _breathingAnimationCoroutine != null;
            if (wasAnimating)
            {
                StopBreathingAnimation();
            }

            float elapsedTime = 0f;
            float duration = 0.2f;
            Vector3 originalScale = buttonTransform.localScale;

            buttonTransform.localScale = originalScale * 0.85f;

            while (elapsedTime < duration)
            {
                if (buttonTransform == null) yield break;

                elapsedTime += Time.unscaledDeltaTime;
                float t = elapsedTime / duration;

                float scale = Mathf.Lerp(0.85f, 1.0f, ElasticEaseOut(t));
                buttonTransform.localScale = originalScale * scale;

                yield return null;
            }

            if (buttonTransform != null)
            {
                buttonTransform.localScale = originalScale;
            }

            if (wasAnimating && _currentUnreadCount > 0)
            {
                StartBreathingAnimation();
            }
        }

        private float ElasticEaseOut(float t)
        {
            if (t >= 1) return 1;
            float p = 0.3f;
            float s = p / 4f;
            return Mathf.Pow(2, -10 * t) * Mathf.Sin((t - s) * (2 * Mathf.PI) / p) + 1;
        }

        public void UpdateUnreadIndicator(int unreadCount)
        {
            _currentUnreadCount = unreadCount;

            if (unreadCount > 0)
            {
                EnsureUnreadBadgeExists();
                _badgeText.text = unreadCount.ToString();
                _badgeObject.SetActive(true);

                StartBreathingAnimation();
            }
            else
            {
                if (_badgeObject != null)
                {
                    _badgeObject.SetActive(false);
                }
                StopBreathingAnimation();
            }
        }

        private void EnsureUnreadBadgeExists()
        {
            if (_badgeObject != null) return;

            _badgeObject = new GameObject("UnreadBadge");
            RectTransform badgeRect = _badgeObject.AddComponent<RectTransform>();
            badgeRect.SetParent(_buttonObject.transform, false);

            badgeRect.anchorMin = new Vector2(1, 1);
            badgeRect.anchorMax = new Vector2(1, 1);
            badgeRect.pivot = new Vector2(1, 1);
            badgeRect.anchoredPosition = new Vector2(5, -5);
            badgeRect.sizeDelta = new Vector2(22, 22);

            _badgeImage = _badgeObject.AddComponent<Image>();
            _badgeImage.sprite = LoadSprite("notification_badge");
            if (_badgeImage.sprite == null)
            {
                _badgeImage.color = new Color(1f, 0.3f, 0.3f, 1f);
            }
            _badgeImage.type = Image.Type.Simple;
            _badgeImage.preserveAspect = true;

            GameObject textObj = new GameObject("BadgeText");
            RectTransform textRect = textObj.AddComponent<RectTransform>();
            textRect.SetParent(badgeRect, false);

            textRect.anchorMin = Vector2.zero;
            textRect.anchorMax = Vector2.one;
            textRect.pivot = new Vector2(0.5f, 0.5f);
            textRect.offsetMin = Vector2.zero;
            textRect.offsetMax = Vector2.zero;

            _badgeText = textObj.AddComponent<TextMeshProUGUI>();
            _badgeText.text = "1";
            _badgeText.fontSize = 14;
            _badgeText.color = Color.white;
            _badgeText.alignment = TextAlignmentOptions.Center;
            _badgeText.fontStyle = FontStyles.Bold;
            _badgeText.raycastTarget = false;

            _badgeText.verticalAlignment = TMPro.VerticalAlignmentOptions.Middle;
            _badgeText.horizontalAlignment = TMPro.HorizontalAlignmentOptions.Center;

            _badgeObject.SetActive(false);
        }

        private void StartBreathingAnimation()
        {
            StopBreathingAnimation();
            _breathingAnimationCoroutine = StartCoroutine(BreathingAnimation());
        }

        private void StopBreathingAnimation()
        {
            if (_breathingAnimationCoroutine != null)
            {
                StopCoroutine(_breathingAnimationCoroutine);
                _breathingAnimationCoroutine = null;

                ResetAllAnimationStates();
            }
        }

        private void ResetAllAnimationStates()
        {
            if (_buttonObject != null)
            {
                _buttonObject.transform.localScale = _originalButtonScale;
                _buttonObject.transform.localEulerAngles = _originalButtonRotation;
            }

            if (_badgeObject != null)
            {
                _badgeObject.transform.localScale = Vector3.one;
                _badgeObject.transform.localEulerAngles = Vector3.zero;
            }
        }

        private System.Collections.IEnumerator BreathingAnimation()
        {
            float animationTime = 0f;

            while (_currentUnreadCount > 0 && _buttonObject != null)
            {
                animationTime += Time.unscaledDeltaTime;

                float buttonRotation = Mathf.Sin(animationTime * BUTTON_ROTATION_SPEED) * BUTTON_ROTATION_AMPLITUDE;
                _buttonObject.transform.localEulerAngles = _originalButtonRotation + new Vector3(0, 0, buttonRotation);

                float buttonScaleModifier = Mathf.Sin(animationTime * BUTTON_SCALE_SPEED + BUTTON_SCALE_PHASE_OFFSET) * BUTTON_SCALE_AMPLITUDE;
                _buttonObject.transform.localScale = _originalButtonScale * (1f + buttonScaleModifier);

                if (_badgeObject != null && _badgeObject.activeSelf)
                {
                    float badgeScaleModifier = Mathf.Sin(animationTime * BADGE_SCALE_SPEED + BADGE_SCALE_PHASE_OFFSET) * BADGE_SCALE_AMPLITUDE;
                    _badgeObject.transform.localScale = Vector3.one * (1f + badgeScaleModifier);

                    float badgeRotation = Mathf.Sin(animationTime * BADGE_ROTATION_SPEED + BADGE_ROTATION_PHASE_OFFSET) * BADGE_ROTATION_AMPLITUDE;
                    _badgeObject.transform.localEulerAngles = new Vector3(0, 0, badgeRotation);
                }

                yield return null;
            }

            ResetAllAnimationStates();
        }

        private Sprite LoadSprite(string spriteName)
        {
            try
            {
                return ResourceLoader.LoadSprite(spriteName);
            }
            catch
            {
                return null;
            }
        }

        public void Cleanup()
        {
            try
            {
                StopBreathingAnimation();

                if (_buttonObject != null)
                {
                    Destroy(_buttonObject);
                    _buttonObject = null;
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"NotificationButton清理异常: {e}");
            }

            _buttonImage = null;
            _badgeImage = null;
            _badgeText = null;
            _badgeObject = null;
            _hoverEffect = null;
            _buttonComponent = null;
            _isInitialized = false;
        }
    }
}