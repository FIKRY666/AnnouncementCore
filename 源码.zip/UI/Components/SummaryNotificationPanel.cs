﻿using AnnouncementCore.Data;
using AnnouncementCore.UI.Effects;
using AnnouncementCore.Utility;
using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace AnnouncementCore.UI.Components
{
    public class SummaryNotificationPanel : MonoBehaviour
    {
        private const float PANEL_WIDTH = 230f;
        private const float PANEL_HEIGHT = 70f;
        private const float RIGHT_MARGIN = 20f;
        private const float TOP_MARGIN = -100f;

        private GameObject _panelObject;
        private RectTransform _panelRect;
        private CanvasGroup _canvasGroup;
        private AnnouncementState _state;

        private TextMeshProUGUI _titleText;
        private TextMeshProUGUI _contentText;
        private Button _toggleButton;
        private Image _toggleButtonImage;
        private bool _arePopupsVisible = true;
        private Action<bool> _onVisibilityChanged;

        public void Initialize(AnnouncementState state, Transform uiRoot, Action<bool> onVisibilityChanged)
        {
            try
            {
                _state = state;
                _onVisibilityChanged = onVisibilityChanged;

                CreatePanel(uiRoot);
                CreateUIElements();

                UpdateContent();
                UpdateButtonIcon();
            }
            catch (Exception e)
            {
                Debug.LogError($"SummaryNotificationPanel 初始化失败: {e}");
            }
        }

        private void CreatePanel(Transform uiRoot)
        {
            _panelObject = new GameObject("SummaryNotificationPanel");
            _panelObject.transform.SetParent(uiRoot, false);

            _panelRect = _panelObject.AddComponent<RectTransform>();
            _panelRect.anchorMin = new Vector2(1, 1);
            _panelRect.anchorMax = new Vector2(1, 1);
            _panelRect.pivot = new Vector2(1, 1);
            _panelRect.anchoredPosition = new Vector2(-RIGHT_MARGIN, TOP_MARGIN);
            _panelRect.sizeDelta = new Vector2(PANEL_WIDTH, PANEL_HEIGHT);

            _canvasGroup = _panelObject.AddComponent<CanvasGroup>();
            _canvasGroup.alpha = 1f;
            _canvasGroup.interactable = true;
            _canvasGroup.blocksRaycasts = true;

            Image bg = _panelObject.AddComponent<Image>();
            bg.sprite = LoadSprite("update_panel_bg");
            if (bg.sprite == null)
            {
                bg.color = new Color(0.15f, 0.15f, 0.2f, 0.95f);
            }
            bg.type = Image.Type.Sliced;
        }

        private void CreateUIElements()
        {
            CreateTitleText();
            CreateContentText();
            CreateToggleButton();
        }

        private void CreateTitleText()
        {
            GameObject titleObj = new GameObject("Title");
            RectTransform titleRect = titleObj.AddComponent<RectTransform>();
            titleRect.SetParent(_panelRect, false);

            titleRect.anchorMin = new Vector2(0, 1);
            titleRect.anchorMax = new Vector2(0, 1);
            titleRect.pivot = new Vector2(0, 1);
            titleRect.anchoredPosition = new Vector2(17, -7);
            titleRect.sizeDelta = new Vector2(100, 25);

            _titleText = titleObj.AddComponent<TextMeshProUGUI>();
            _titleText.text = "更新通知";
            _titleText.fontSize = 19;
            _titleText.color = Color.white;
            _titleText.fontStyle = FontStyles.Bold;
            _titleText.alignment = TextAlignmentOptions.Left;
        }

        private void CreateContentText()
        {
            GameObject contentObj = new GameObject("Content");
            RectTransform contentRect = contentObj.AddComponent<RectTransform>();
            contentRect.SetParent(_panelRect, false);

            contentRect.anchorMin = new Vector2(0, 1);
            contentRect.anchorMax = new Vector2(0, 1);
            contentRect.pivot = new Vector2(0, 1);
            contentRect.anchoredPosition = new Vector2(17, -40);
            contentRect.sizeDelta = new Vector2(130, 25);

            _contentText = contentObj.AddComponent<TextMeshProUGUI>();
            _contentText.text = "";
            _contentText.fontSize = 16;
            _contentText.color = new Color(1f, 0.92f, 0.58f, 1f);
            _contentText.alignment = TextAlignmentOptions.Left;
        }

        private void CreateToggleButton()
        {
            GameObject buttonObj = new GameObject("ToggleButton");
            RectTransform buttonRect = buttonObj.AddComponent<RectTransform>();
            buttonRect.SetParent(_panelRect, false);

            buttonRect.anchorMin = new Vector2(1, 1);
            buttonRect.anchorMax = new Vector2(1, 1);
            buttonRect.pivot = new Vector2(1, 1);
            buttonRect.anchoredPosition = new Vector2(-10, -10);
            buttonRect.sizeDelta = new Vector2(50, 22);

            _toggleButtonImage = buttonObj.AddComponent<Image>();
            _toggleButtonImage.sprite = LoadSprite("panel_collapse");
            if (_toggleButtonImage.sprite == null)
            {
                _toggleButtonImage.color = new Color(0.2f, 0.6f, 0.9f, 1f);
            }
            _toggleButtonImage.type = Image.Type.Sliced;

            _toggleButton = buttonObj.AddComponent<Button>();
            _toggleButton.onClick.AddListener(OnToggleButtonClicked);

            var hoverEffect = buttonObj.AddComponent<ConsolidatedHoverEffect>();
            hoverEffect.ButtonImage = _toggleButtonImage;
            hoverEffect.ButtonComponent = _toggleButton;
            hoverEffect.SetEffectType(ConsolidatedHoverEffect.EffectType.PopupButton);
        }

        private void OnToggleButtonClicked()
        {
            AudioUtility.PlayClickSound();

            _arePopupsVisible = !_arePopupsVisible;

            UpdateButtonIcon();

            _onVisibilityChanged?.Invoke(_arePopupsVisible);

            StartCoroutine(PlayButtonClickAnimation(_toggleButtonImage.transform));
        }

        private System.Collections.IEnumerator PlayButtonClickAnimation(Transform buttonTransform)
        {
            if (buttonTransform == null) yield break;

            float elapsedTime = 0f;
            float duration = 0.2f;
            Vector3 originalScale = buttonTransform.localScale;

            buttonTransform.localScale = originalScale * 0.85f;

            while (elapsedTime < duration)
            {
                elapsedTime += Time.deltaTime;
                float t = elapsedTime / duration;
                float scale = Mathf.Lerp(0.85f, 1.0f, ElasticEaseOut(t));
                buttonTransform.localScale = originalScale * scale;
                yield return null;
            }

            buttonTransform.localScale = originalScale;
        }

        private float ElasticEaseOut(float t)
        {
            if (t >= 1) return 1;
            float p = 0.3f;
            float s = p / 4f;
            return Mathf.Pow(2, -10 * t) * Mathf.Sin((t - s) * (2 * Mathf.PI) / p) + 1;
        }

        public void UpdateContent()
        {
            try
            {
                if (_state == null) return;

                if (_state.AllRead)
                {
                    Hide();
                    return;
                }
                else
                {
                    Show();
                }

                var allConfigs = _state.GetAllConfigsSorted();
                int totalCount = allConfigs.Count;
                int permanentCount = 0;
                int unreadCount = 0;

                foreach (var config in allConfigs)
                {
                    if (config.HasPermanentUpdate)
                    {
                        permanentCount++;
                    }
                    else if (!_state.IsRead(config.ModId))
                    {
                        unreadCount++;
                    }
                }

                if (totalCount == 0)
                {
                    _contentText.text = "暂无更新";
                    _contentText.color = new Color(0.7f, 0.7f, 0.7f, 1f);
                }
                else
                {
                    string content = "";
                    if (permanentCount > 0)
                    {
                        content += $"版本更新:{permanentCount}   ";
                        if (unreadCount > 0) content += " ";
                    }
                    if (unreadCount > 0)
                    {
                        content += $"未读公告:{unreadCount}";
                    }
                    _contentText.text = content;
                    _contentText.color = new Color(1f, 0.92f, 0.58f, 1f);

                    if (_toggleButtonImage != null)
                    {
                        _toggleButton.interactable = true;
                        UpdateButtonIcon();
                    }
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"更新摘要面板内容失败: {e}");
            }
        }

        private void UpdateButtonIcon()
        {
            if (_toggleButtonImage == null) return;

            string spriteName = _arePopupsVisible ? "panel_collapse" : "panel_expand";

            Sprite sprite = LoadSprite(spriteName);
            if (sprite != null)
            {
                _toggleButtonImage.sprite = sprite;
            }
            else
            {
                _toggleButtonImage.color = _arePopupsVisible ?
                    new Color(0.9f, 0.3f, 0.3f, 1f) :
                    new Color(0.3f, 0.9f, 0.3f, 1f);
            }
        }

        public void Show()
        {
            if (_panelObject == null) return;

            _panelObject.SetActive(true);
            _canvasGroup.alpha = 1f;
        }

        public void Hide()
        {
            if (_panelObject == null) return;

            _canvasGroup.alpha = 0f;
            _panelObject.SetActive(false);
        }

        private Sprite LoadSprite(string spriteName)
        {
            try
            {
                var sprite = ResourceLoader.LoadSprite(spriteName);

                if (sprite == null)
                {
                    switch (spriteName)
                    {
                        case "summary_panel_bg":
                            sprite = ResourceLoader.LoadSprite("update_panel_bg");
                            break;
                        case "summary_hide":
                            sprite = ResourceLoader.LoadSprite("panel_collapse");
                            break;
                        case "summary_show":
                            sprite = ResourceLoader.LoadSprite("panel_expand");
                            break;
                    }
                }

                if (sprite == null && spriteName == "summary_panel_bg")
                {
                    sprite = ResourceLoader.LoadSprite("panel_empty");
                }

                return sprite;
            }
            catch
            {
                return null;
            }
        }

        public void Cleanup()
        {
            try
            {
                if (_panelObject != null)
                {
                    Destroy(_panelObject);
                    _panelObject = null;
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"SummaryNotificationPanel 清理失败: {e}");
            }

            _titleText = null;
            _contentText = null;
            _toggleButton = null;
            _toggleButtonImage = null;
            _state = null;
            _onVisibilityChanged = null;
        }
    }
}