﻿using AnnouncementCore.Data;
using AnnouncementCore.Utility;
using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace AnnouncementCore.UI.Components
{
    public class ContentArea : MonoBehaviour
    {
        private ScrollRect _scrollRect;
        private TextMeshProUGUI _contentText;
        private TextMeshProUGUI _infoText;
        private GameObject _scrollArea;

        private bool _isInitialized = false;

        public void Initialize()
        {
            try
            {
                CreateInfoSection();
                CreateContentScrollArea();
                FixRaycastTargets();

                SetupLinkClickHandler();

                _isInitialized = true;
            }
            catch (Exception e)
            {
                Debug.LogError($"ContentArea 初始化异常: {e}");
            }
        }

        private void SetupLinkClickHandler()
        {
            if (_contentText != null)
            {
                AddLinkClickEventViaEventTrigger();
            }
        }

        private void AddLinkClickEventViaEventTrigger()
        {
            try
            {
                EventTrigger trigger = _contentText.gameObject.AddComponent<EventTrigger>();
                _contentText.raycastTarget = true;

                EventTrigger.Entry entry = new EventTrigger.Entry();
                entry.eventID = EventTriggerType.PointerClick;
                entry.callback.AddListener((data) => OnTextClicked((PointerEventData)data));
                trigger.triggers.Add(entry);
            }
            catch (Exception e)
            {
                Debug.LogError($"添加链接点击事件失败: {e}");
            }
        }

        private void OnTextClicked(PointerEventData eventData)
        {
            try
            {
                int linkIndex = TMP_TextUtilities.FindIntersectingLink(_contentText, eventData.position, null);

                if (linkIndex != -1)
                {
                    TMP_LinkInfo linkInfo = _contentText.textInfo.linkInfo[linkIndex];
                    string linkID = linkInfo.GetLinkID();

                    if (IsValidUrl(linkID))
                    {
                        Application.OpenURL(linkID);
                    }
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"处理文本点击失败: {e}");
            }
        }

        private bool IsValidUrl(string url)
        {
            if (string.IsNullOrEmpty(url))
                return false;

            return url.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ||
                   url.StartsWith("https://", StringComparison.OrdinalIgnoreCase) ||
                   url.StartsWith("mailto:", StringComparison.OrdinalIgnoreCase) ||
                   url.StartsWith("tel:", StringComparison.OrdinalIgnoreCase);
        }

        private void CreateInfoSection()
        {
            try
            {
                GameObject infoObj = new GameObject("InfoSection");
                RectTransform infoRect = infoObj.AddComponent<RectTransform>();
                infoRect.SetParent(transform, false);

                infoRect.anchorMin = new Vector2(0, 1);
                infoRect.anchorMax = new Vector2(1, 1);
                infoRect.pivot = new Vector2(0.5f, 1);
                infoRect.anchoredPosition = Vector2.zero;
                infoRect.anchoredPosition = new Vector2(0, -40);
                infoRect.sizeDelta = new Vector2(-20, 80);

                Image infoBg = infoObj.AddComponent<Image>();
                infoBg.sprite = ResourceLoader.LoadSprite("info_bg");
                if (infoBg.sprite == null)
                {
                    infoBg.color = new Color(0.1f, 0.1f, 0.15f, 0.7f);
                }
                infoBg.type = Image.Type.Sliced;
                infoBg.raycastTarget = true;

                GameObject textObj = new GameObject("InfoText");
                RectTransform textRect = textObj.AddComponent<RectTransform>();
                textRect.SetParent(infoRect, false);

                textRect.anchorMin = Vector2.zero;
                textRect.anchorMax = Vector2.one;
                textRect.pivot = new Vector2(0.5f, 0.5f);
                textRect.offsetMin = new Vector2(10, 5);
                textRect.offsetMax = new Vector2(-10, -5);

                _infoText = textObj.AddComponent<TextMeshProUGUI>();
                _infoText.fontSize = 14;
                _infoText.color = Color.white;
                _infoText.alignment = TMPro.TextAlignmentOptions.Left;
                _infoText.fontStyle = FontStyles.Bold;
                _infoText.enableWordWrapping = true;
                _infoText.raycastTarget = false;
            }
            catch (Exception e)
            {
                Debug.LogError($"创建信息区异常: {e}");
            }
        }

        private void CreateContentScrollArea()
        {
            try
            {
                _scrollArea = new GameObject("ContentScrollArea");
                RectTransform scrollRectTransform = _scrollArea.AddComponent<RectTransform>();
                scrollRectTransform.SetParent(transform, false);

                scrollRectTransform.anchorMin = new Vector2(0, 0);
                scrollRectTransform.anchorMax = new Vector2(1, 1);
                scrollRectTransform.pivot = new Vector2(0.5f, 0.5f);
                scrollRectTransform.offsetMin = new Vector2(10, 10);
                scrollRectTransform.offsetMax = new Vector2(-10, -150);

                _scrollRect = _scrollArea.AddComponent<ScrollRect>();
                _scrollRect.horizontal = false;
                _scrollRect.vertical = true;
                _scrollRect.movementType = ScrollRect.MovementType.Elastic;
                _scrollRect.scrollSensitivity = 1f;
                _scrollRect.inertia = true;
                _scrollRect.decelerationRate = 0.135f;
                _scrollRect.elasticity = 0.1f;

                GameObject viewport = new GameObject("Viewport");
                RectTransform viewportRect = viewport.AddComponent<RectTransform>();
                viewportRect.SetParent(scrollRectTransform, false);
                viewportRect.anchorMin = Vector2.zero;
                viewportRect.anchorMax = Vector2.one;
                viewportRect.pivot = new Vector2(0.5f, 0.5f);
                viewportRect.offsetMin = Vector2.zero;
                viewportRect.offsetMax = Vector2.zero;

                Mask viewportMask = viewport.AddComponent<Mask>();
                viewportMask.showMaskGraphic = false;

                Image viewportImage = viewport.AddComponent<Image>();
                viewportImage.color = new Color(0f, 0f, 0f, 0f);
                viewportImage.raycastTarget = true;
                viewportImage.enabled = true;

                GameObject content = new GameObject("Content");
                RectTransform contentRect = content.AddComponent<RectTransform>();
                contentRect.SetParent(viewportRect, false);
                contentRect.anchorMin = new Vector2(0, 1);
                contentRect.anchorMax = new Vector2(1, 1);
                contentRect.pivot = new Vector2(0.5f, 1);
                contentRect.anchoredPosition = Vector2.zero;
                contentRect.sizeDelta = new Vector2(0, 100);

                _scrollRect.viewport = viewportRect;
                _scrollRect.content = contentRect;

                ContentSizeFitter contentFitter = content.AddComponent<ContentSizeFitter>();
                contentFitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
                contentFitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;

                LayoutElement contentLayout = content.AddComponent<LayoutElement>();
                contentLayout.minHeight = 100;
                contentLayout.preferredHeight = -1;

                VerticalLayoutGroup contentLayoutGroup = content.AddComponent<VerticalLayoutGroup>();
                contentLayoutGroup.padding = new RectOffset(0, 0, 0, 0);
                contentLayoutGroup.spacing = 0;
                contentLayoutGroup.childAlignment = TextAnchor.UpperLeft;
                contentLayoutGroup.childControlHeight = false;
                contentLayoutGroup.childControlWidth = true;
                contentLayoutGroup.childForceExpandHeight = false;
                contentLayoutGroup.childForceExpandWidth = true;

                GameObject textObj = new GameObject("Text");
                RectTransform textRect = textObj.AddComponent<RectTransform>();
                textRect.SetParent(contentRect, false);
                textRect.anchorMin = new Vector2(0, 1);
                textRect.anchorMax = new Vector2(1, 1);
                textRect.pivot = new Vector2(0.5f, 1);
                textRect.anchoredPosition = Vector2.zero;
                textRect.sizeDelta = new Vector2(-20f, 0);

                _contentText = textObj.AddComponent<TextMeshProUGUI>();
                _contentText.text = "正在加载内容...";
                _contentText.alignment = TMPro.TextAlignmentOptions.TopLeft;
                _contentText.color = new Color(0.9f, 0.92f, 0.95f, 1f);
                _contentText.fontSize = 18f;
                _contentText.richText = true;
                _contentText.overflowMode = TMPro.TextOverflowModes.Overflow;
                _contentText.enableWordWrapping = true;
                _contentText.margin = new Vector4(15f, 10f, 15f, 10f);
                _contentText.raycastTarget = false;

                LayoutElement textLayout = textObj.AddComponent<LayoutElement>();
                textLayout.minHeight = 50;
                textLayout.preferredHeight = -1;

                _scrollArea.transform.SetAsLastSibling();

                _scrollRect.verticalNormalizedPosition = 1f;

                AddScrollAreaDebugComponents();
            }
            catch (Exception e)
            {
                Debug.LogError($"创建内容滚动区域异常: {e}");
            }
        }

        private void AddScrollAreaDebugComponents()
        {
            try
            {
                EventTrigger trigger = _scrollArea.AddComponent<EventTrigger>();

                EventTrigger.Entry clickEntry = new EventTrigger.Entry();
                clickEntry.eventID = EventTriggerType.PointerClick;
                trigger.triggers.Add(clickEntry);

                EventTrigger.Entry dragEntry = new EventTrigger.Entry();
                dragEntry.eventID = EventTriggerType.BeginDrag;
                trigger.triggers.Add(dragEntry);
            }
            catch (Exception e)
            {
                Debug.LogError($"添加滚动区域调试组件异常: {e}");
            }
        }

        private void FixRaycastTargets()
        {
            try
            {
                if (_scrollArea == null) return;

                Image[] allImages = _scrollArea.GetComponentsInChildren<Image>(true);

                foreach (Image img in allImages)
                {
                    string objName = img.gameObject.name;

                    if (objName.Contains("Viewport") ||
                        objName.Contains("Background") ||
                        objName.Contains("ContentScrollArea"))
                    {
                        if (!img.raycastTarget)
                        {
                            img.raycastTarget = true;
                        }
                    }
                    else if (objName.Contains("Text") || objName.Contains("Info"))
                    {
                        if (img.raycastTarget)
                        {
                            img.raycastTarget = false;
                        }
                    }
                }

                TextMeshProUGUI[] allTexts = _scrollArea.GetComponentsInChildren<TextMeshProUGUI>(true);
                foreach (TextMeshProUGUI text in allTexts)
                {
                    if (text.raycastTarget)
                    {
                        text.raycastTarget = false;
                    }
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"修复raycastTarget异常: {e}");
            }
        }

        public void UpdateContent(AnnouncementConfig config, int currentAnnouncementIndex = 0)
        {
            try
            {
                if (!_isInitialized) return;

                UpdateInfoSection(config, currentAnnouncementIndex);

                string displayContent = GetDisplayContentFromApiOrLocal(config, currentAnnouncementIndex);
                _contentText.text = displayContent;

                _contentText.ForceMeshUpdate();

                _scrollRect.verticalNormalizedPosition = 1f;

                StartCoroutine(ImmediateLayoutUpdate(_scrollRect, _contentText));
            }
            catch (Exception e)
            {
                Debug.LogError($"更新内容异常: {e}");
            }
        }

        private void UpdateInfoSection(AnnouncementConfig config, int currentIndex = 0)
        {
            try
            {
                string infoText = "";

                if (config.ApiAnnouncements != null && config.ApiAnnouncements.Count > currentIndex)
                {
                    var currentAnnouncement = config.ApiAnnouncements[currentIndex];

                    if (!string.IsNullOrEmpty(currentAnnouncement.title))
                    {
                        infoText += $"<size=18><b>{currentAnnouncement.title}</b></size>\n\n";
                    }

                    if (!string.IsNullOrEmpty(currentAnnouncement.author))
                    {
                        infoText += $"<size=16><b>作者:</b> {currentAnnouncement.author}</size>\n";
                    }

                    if (!string.IsNullOrEmpty(currentAnnouncement.version))
                    {
                        infoText += $"<size=16><b>版本:</b>v{currentAnnouncement.version} (v{config.Version})</size>\n";
                    }
                }

                if (!string.IsNullOrEmpty(config.SteamWorkshopId))
                {
                    infoText += $"<size=16><b>创意工坊ID:</b> {config.SteamWorkshopId}</size>";
                }

                _infoText.text = infoText;
            }
            catch (Exception e)
            {
                Debug.LogError($"更新信息区异常: {e}");
            }
        }

        private string GetDisplayContentFromApiOrLocal(AnnouncementConfig config, int announcementIndex = 0)
        {
            try
            {
                if (config.ApiAnnouncements != null && config.ApiAnnouncements.Count > 0)
                {
                    int safeIndex = Mathf.Clamp(announcementIndex, 0, config.ApiAnnouncements.Count - 1);
                    var announcement = config.ApiAnnouncements[safeIndex];

                    if (!string.IsNullOrEmpty(announcement.content_html))
                    {
                        string converted = HtmlToTmpConverter.ConvertApiExample(announcement.content_html);
                        return converted;
                    }
                }

                return "暂无更新内容";
            }
            catch (Exception e)
            {
                Debug.LogError($"获取显示内容异常: {e}");
                return "内容加载失败";
            }
        }

        private IEnumerator ImmediateLayoutUpdate(ScrollRect scrollRect, TextMeshProUGUI text)
        {
            yield return null;

            try
            {
                if (scrollRect == null || scrollRect.content == null) yield break;

                text.ForceMeshUpdate();

                LayoutRebuilder.ForceRebuildLayoutImmediate(scrollRect.content);

                Canvas.ForceUpdateCanvases();

                float textHeight = text.preferredHeight;
                float padding = 40f;

                if (textHeight > 0)
                {
                    LayoutElement layoutElement = scrollRect.content.GetComponent<LayoutElement>();
                    if (layoutElement != null)
                    {
                        layoutElement.minHeight = textHeight + padding;
                    }

                    scrollRect.content.sizeDelta = new Vector2(
                        scrollRect.content.sizeDelta.x,
                        textHeight + padding
                    );
                }

                float contentHeight = scrollRect.content.rect.height;
                float viewportHeight = scrollRect.viewport.rect.height;

                if (contentHeight > viewportHeight)
                {
                    scrollRect.vertical = true;
                }
                else
                {
                    scrollRect.vertical = false;
                }

                Image viewportImage = scrollRect.viewport.GetComponent<Image>();
                if (viewportImage != null)
                {
                    viewportImage.color = new Color(0.1f, 0.3f, 0.6f, 0.05f);
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"立即布局更新异常: {e}");
            }
        }

        public void Cleanup()
        {
            try
            {
                if (_contentText != null)
                {
                    EventTrigger trigger = _contentText.GetComponent<EventTrigger>();
                    if (trigger != null)
                    {
                        Destroy(trigger);
                    }
                    _contentText.raycastTarget = false;
                }

                if (_scrollArea != null)
                {
                    Destroy(_scrollArea);
                }
            }
            catch (Exception) { }

            _scrollRect = null;
            _contentText = null;
            _infoText = null;
            _scrollArea = null;
            _isInitialized = false;
        }
    }
}