﻿using AnnouncementCore.Data;
using AnnouncementCore.UI.Components;
using AnnouncementCore.Utility;
using AnnouncementCore.UI.Effects;
using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace AnnouncementCore.UI.Components
{
    public class MainPanel : MonoBehaviour
    {
        private AnnouncementState _state;
        private UIAnimator _animator;
        private GameObject _panelObject;
        private CanvasGroup _canvasGroup;

        private SidebarList _sidebarList;
        private ContentArea _contentArea;
        private BottomNavigation _bottomNavigation;

        private Action _onPrevClicked;
        private Action _onNextClicked;
        private Action _onFeedbackClicked;
        private Action _onCloseClicked;

        private const float TITLE_BASE_Y = 280f;
        private const float CONTENT_OFFSET_X = -20f;
        private const float CONTENT_OFFSET_Y = -5f;

        private bool _isInitialized = false;
        public bool IsInitialized => _isInitialized;

        public void Initialize(Transform parent, AnnouncementState state, UIAnimator animator)
        {
            try
            {
                _state = state;
                _animator = animator;

                CreatePanel(parent);
                CreateSubComponents();

                _isInitialized = true;
            }
            catch (System.Exception e)
            {
                Debug.LogError($"MainPanel 初始化异常: {e}");
                _isInitialized = false;
            }
        }

        private void CreatePanel(Transform parent)
        {
            try
            {
                _panelObject = new GameObject("MainPanel");
                _panelObject.transform.SetParent(parent, false);

                RectTransform rect = _panelObject.AddComponent<RectTransform>();
                rect.anchorMin = Vector2.zero;
                rect.anchorMax = Vector2.one;
                rect.offsetMin = Vector2.zero;
                rect.offsetMax = Vector2.zero;

                _canvasGroup = _panelObject.AddComponent<CanvasGroup>();
                _canvasGroup.alpha = 0f;

                GameObject contentContainer = CreateContentContainer();
                CreateBackground(contentContainer.transform);
                CreateHeader(contentContainer.transform);
                CreateSidebarArea(contentContainer.transform);
                CreateContentArea(contentContainer.transform);
                CreateBottomArea(contentContainer.transform);

                _panelObject.SetActive(false);
            }
            catch (System.Exception e)
            {
                Debug.LogError($"创建面板异常: {e}");
            }
        }

        private GameObject CreateContentContainer()
        {
            GameObject container = new GameObject("ContentContainer");
            container.transform.SetParent(_panelObject.transform, false);

            RectTransform rect = container.AddComponent<RectTransform>();
            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = Vector2.zero;
            rect.sizeDelta = new Vector2(800, 650);

            return container;
        }

        private void CreateBackground(Transform parent)
        {
            GameObject bg = new GameObject("Background", typeof(RectTransform), typeof(Image));
            bg.transform.SetParent(parent, false);

            RectTransform rect = bg.GetComponent<RectTransform>();
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;

            Image image = bg.GetComponent<Image>();
            image.sprite = LoadSprite("panel_background");
            if (image.sprite == null)
            {
                image.color = new Color(0.05f, 0.05f, 0.08f, 0.85f);
            }
            else
            {
                image.type = Image.Type.Sliced;
            }
        }

        private void CreateHeader(Transform parent)
        {
            CreateTextElement(parent, "LeftTitle", new Vector2(-280, TITLE_BASE_Y), new Vector2(120, 30), "更新公告", 20);

            GameObject mainTitleContainer = new GameObject("MainTitleContainer");
            mainTitleContainer.transform.SetParent(parent, false);
            RectTransform mainRect = mainTitleContainer.AddComponent<RectTransform>();
            mainRect.anchorMin = new Vector2(0.5f, 0.5f);
            mainRect.anchorMax = new Vector2(0.5f, 0.5f);
            mainRect.pivot = new Vector2(0.5f, 0.5f);
            mainRect.anchoredPosition = new Vector2(0, TITLE_BASE_Y);
            mainRect.sizeDelta = new Vector2(400, 30);

            CreateTextElement(mainTitleContainer.transform, "MainTitle", new Vector2(100, 0), new Vector2(400, 30), "", 20);

            GameObject rightContainer = new GameObject("RightContainer");
            rightContainer.transform.SetParent(parent, false);
            RectTransform rightRect = rightContainer.AddComponent<RectTransform>();
            rightRect.anchorMin = new Vector2(0.5f, 0.5f);
            rightRect.anchorMax = new Vector2(0.5f, 0.5f);
            rightRect.pivot = new Vector2(0.5f, 0.5f);
            rightRect.anchoredPosition = new Vector2(100, TITLE_BASE_Y);
            rightRect.sizeDelta = new Vector2(270, 30);

            CreateVersionText(rightContainer.transform);

            CreateCloseButton(parent);

            CreateAnnouncementIndex(parent);
        }

        private void CreateVersionText(Transform parent)
        {
            GameObject versionObj = new GameObject("Version", typeof(RectTransform), typeof(TextMeshProUGUI));
            versionObj.transform.SetParent(parent, false);

            RectTransform rect = versionObj.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(1, 0.5f);
            rect.anchorMax = new Vector2(1, 0.5f);
            rect.pivot = new Vector2(1, 0.5f);
            rect.anchoredPosition = new Vector2(80, 0);
            rect.sizeDelta = new Vector2(80, 30);

            TextMeshProUGUI textComp = versionObj.GetComponent<TextMeshProUGUI>();
            textComp.text = "v1.0.0";
            textComp.fontSize = 20;
            textComp.color = Color.white;
            textComp.alignment = TMPro.TextAlignmentOptions.Right;
            textComp.fontStyle = FontStyles.Bold;
        }

        private void CreateAnnouncementIndex(Transform parent)
        {
            GameObject indexObj = new GameObject("AnnouncementIndex");
            indexObj.transform.SetParent(parent, false);

            RectTransform rect = indexObj.AddComponent<RectTransform>();
            rect.anchoredPosition = new Vector2(350, TITLE_BASE_Y - 70);
            rect.sizeDelta = new Vector2(60, 20);

            TextMeshProUGUI textComp = indexObj.AddComponent<TextMeshProUGUI>();
            textComp.text = "1/1";
            textComp.fontSize = 16;
            textComp.color = new Color(0.90f, 0.90f, 0.90f, 1f);
            textComp.alignment = TMPro.TextAlignmentOptions.Center;
        }

        private void CreateCloseButton(Transform parent)
        {
            GameObject btn = CreateButton(parent, "Close_Button", new Vector2(350, TITLE_BASE_Y), new Vector2(30, 30));
            Image image = btn.GetComponent<Image>();
            image.sprite = ResourceLoader.LoadSprite("close_button");
            if (image.sprite == null)
            {
                image.color = new Color(0.97f, 0.33f, 0.4f, 1f);
            }
            else
            {
                image.type = Image.Type.Sliced;
            }
            Button button = btn.GetComponent<Button>();
            button.onClick.AddListener(() =>
            {
                AudioUtility.PlayClickSound();
                _onCloseClicked?.Invoke();
            });

            var hoverEffect = btn.AddComponent<ButtonHoverEffect>();
            hoverEffect.ButtonImage = btn.GetComponent<Image>();
            hoverEffect.ButtonComponent = button;
            hoverEffect.ConfigureForPopupButton();
        }

        private void CreateSidebarArea(Transform parent)
        {
            try
            {
                GameObject sidebarBg = new GameObject("SidebarBackground");

                sidebarBg.transform.SetParent(parent, false);

                RectTransform rect = sidebarBg.AddComponent<RectTransform>();
                rect.anchorMin = new Vector2(0, 0);
                rect.anchorMax = new Vector2(0, 0);
                rect.pivot = new Vector2(0, 0);
                rect.anchoredPosition = new Vector2(35 + CONTENT_OFFSET_X, 20 + CONTENT_OFFSET_Y);
                rect.sizeDelta = new Vector2(240, 546);

                _sidebarList = sidebarBg.AddComponent<SidebarList>();

                if (_state != null)
                {
                    _sidebarList.Initialize(_state, OnSidebarItemClicked);
                }
            }
            catch (System.Exception e)
            {
            }
        }

        private void CreateContentArea(Transform parent)
        {
            GameObject contentBg = new GameObject("ContentBackground", typeof(RectTransform), typeof(Image));
            contentBg.transform.SetParent(parent, false);

            RectTransform rect = contentBg.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0, 0);
            rect.anchorMax = new Vector2(0, 0);
            rect.pivot = new Vector2(0, 0);
            rect.anchoredPosition = new Vector2(290 + CONTENT_OFFSET_X, 20 + CONTENT_OFFSET_Y);
            rect.sizeDelta = new Vector2(513, 546);

            Image image = contentBg.GetComponent<Image>();
            image.sprite = LoadSprite("content_bg");
            if (image.sprite == null)
            {
                image.color = new Color(0.1f, 0.1f, 0.15f, 0.8f);
            }
            image.type = Image.Type.Sliced;

            _contentArea = contentBg.AddComponent<ContentArea>();
            _contentArea.Initialize();
        }

        private void CreateBottomArea(Transform parent)
        {
            _bottomNavigation = parent.gameObject.AddComponent<BottomNavigation>();
            _bottomNavigation.Initialize(
                onRefresh: RefreshPanel,
                onPrev: () => _onPrevClicked?.Invoke(),
                onNext: () => _onNextClicked?.Invoke(),
                onFeedback: () => _onFeedbackClicked?.Invoke(),
                state: _state
            );
        }

        private void CreateSubComponents()
        {
            RefreshPanel();
        }

        private void OnSidebarItemClicked(string modId)
        {
            _state.SelectAnnouncement(modId);
        }

        private GameObject CreateTextElement(Transform parent, string name, Vector2 position, Vector2 size, string text, int fontSize = 16, TMPro.TextAlignmentOptions alignment = TMPro.TextAlignmentOptions.Left)
        {
            GameObject obj = new GameObject(name, typeof(RectTransform), typeof(TextMeshProUGUI));
            obj.transform.SetParent(parent, false);

            RectTransform rect = obj.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = size;

            TextMeshProUGUI textComp = obj.GetComponent<TextMeshProUGUI>();
            textComp.text = text;
            textComp.fontSize = fontSize;
            textComp.color = Color.white;
            textComp.alignment = alignment;
            textComp.fontStyle = FontStyles.Bold;

            return obj;
        }

        private GameObject CreateButton(Transform parent, string name, Vector2 position, Vector2 size)
        {
            GameObject obj = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
            obj.transform.SetParent(parent, false);

            RectTransform rect = obj.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = size;

            Image image = obj.GetComponent<Image>();
            image.sprite = LoadSprite(name.ToLower());
            if (image.sprite == null)
            {
                if (name.Contains("Close"))
                {
                    image.sprite = ResourceLoader.LoadSprite("close_button");
                    if (image.sprite == null)
                        image.color = new Color(0.97f, 0.33f, 0.4f, 1f);
                }
                else if (name.Contains("Prev") || name.Contains("Next")) image.color = new Color(0.13f, 0.63f, 0.76f, 1f);
                else if (name.Contains("Feedback")) image.color = new Color(0.43f, 0.77f, 0.29f, 1f);
                else image.color = new Color(0.2f, 0.6f, 0.9f, 1f);
            }
            image.type = Image.Type.Sliced;

            return obj;
        }

        private Sprite LoadSprite(string spriteName)
        {
            try
            {
                return ResourceLoader.LoadSprite(spriteName);
            }
            catch
            {
                return null;
            }
        }

        public void SetCallbacks(Action onPrevClicked, Action onNextClicked, Action onFeedbackClicked, Action onCloseClicked)
        {
            _onPrevClicked = onPrevClicked;
            _onNextClicked = onNextClicked;
            _onFeedbackClicked = onFeedbackClicked;
            _onCloseClicked = onCloseClicked;
        }

        public void Show()
        {
            if (!_isInitialized) return;

            try
            {
                _panelObject.SetActive(true);
                _canvasGroup.alpha = 0f;

                StartCoroutine(DelayedShowAnimation());
            }
            catch (System.Exception e)
            {
            }
        }

        private IEnumerator DelayedShowAnimation()
        {
            yield return null;

            if (_animator != null)
            {
                StartCoroutine(_animator.PanelElasticShowAnimation(
                    _panelObject.transform,
                    _canvasGroup,
                    () =>
                    {
                        RefreshPanel();
                        Canvas.ForceUpdateCanvases();
                    }
                ));
            }
            else
            {
                _canvasGroup.alpha = 1f;
                RefreshPanel();
            }
        }

        public void Hide()
        {
            if (!_isInitialized) return;

            try
            {
                if (_animator != null)
                {
                    StartCoroutine(_animator.PanelHideAnimation(
                        _panelObject.transform,
                        _canvasGroup,
                        () => _panelObject.SetActive(false)
                    ));
                }
                else
                {
                    _canvasGroup.alpha = 0f;
                    _panelObject.SetActive(false);
                }
            }
            catch (System.Exception e)
            {
            }
        }

        public void UpdateContent(string modId, bool animate = false)
        {
            if (!_isInitialized) return;

            try
            {
                var config = _state.SelectedConfig;
                if (config == null) return;

                UpdateTextElement("MainTitleContainer/MainTitle", config.DisplayName, TMPro.TextAlignmentOptions.Left);

                string versionToShow = GetCurrentAnnouncementVersion(config);
                UpdateTextElement("RightContainer/Version", $"v{versionToShow}", TMPro.TextAlignmentOptions.Right);

                UpdateAnnouncementIndex();

                if (_contentArea != null && _panelObject.activeSelf)
                {
                    int currentIndex = _state.GetCurrentAnnouncementIndex();
                    _contentArea.UpdateContent(config, currentIndex);
                }
            }
            catch (System.Exception e)
            {
            }
        }

        private string GetCurrentAnnouncementVersion(AnnouncementConfig config)
        {
            if (config == null) return "1.0.0";

            if (_state != null)
            {
                int currentIndex = _state.GetCurrentAnnouncementIndex();
                if (config.ApiAnnouncements != null && config.ApiAnnouncements.Count > currentIndex)
                {
                    var announcement = config.ApiAnnouncements[currentIndex];
                    if (!string.IsNullOrEmpty(announcement.version))
                    {
                        return announcement.version;
                    }
                }
            }

            return config.Version;
        }

        private void UpdateAnnouncementIndex()
        {
            try
            {
                Transform indexElement = _panelObject.transform.Find("ContentContainer/AnnouncementIndex");
                if (indexElement != null)
                {
                    TextMeshProUGUI textComp = indexElement.GetComponent<TextMeshProUGUI>();
                    if (textComp != null && _state != null)
                    {
                        int current = _state.GetCurrentAnnouncementIndex() + 1;
                        int total = _state.GetTotalAnnouncements();
                        textComp.text = $"{current}/{total}";
                    }
                }
            }
            catch (System.Exception e)
            {
            }
        }

        public void RefreshSidebarList()
        {
            if (!_isInitialized || _state == null) return;

            var configs = _state.GetAllConfigsSorted();
            _sidebarList?.Refresh(configs);
        }

        public void RefreshPanel()
        {
            RefreshSidebarList();

            if (_state?.SelectedConfig != null)
            {
                UpdateContent(_state.SelectedModId);
            }
        }

        private void UpdateTextElement(string path, string text, TMPro.TextAlignmentOptions? alignment = null)
        {
            try
            {
                Transform element = _panelObject.transform.Find($"ContentContainer/{path}");
                if (element != null)
                {
                    TextMeshProUGUI textComp = element.GetComponent<TextMeshProUGUI>();
                    if (textComp != null)
                    {
                        textComp.text = text;
                        if (alignment.HasValue)
                        {
                            textComp.alignment = alignment.Value;
                        }
                    }
                }
            }
            catch (System.Exception e)
            {
            }
        }

        public void Cleanup()
        {
            try
            {
                _sidebarList?.Cleanup();
                _contentArea?.Cleanup();
                _bottomNavigation?.Cleanup();

                if (_panelObject != null)
                {
                    Destroy(_panelObject);
                }
            }
            catch (System.Exception) { }

            _panelObject = null;
            _canvasGroup = null;
            _state = null;
            _animator = null;
            _isInitialized = false;
        }
    }
}