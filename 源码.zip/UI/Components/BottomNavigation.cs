﻿using AnnouncementCore.UI.Effects;
using AnnouncementCore.Utility;
using Steamworks;
using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace AnnouncementCore.UI.Components
{
    public class BottomNavigation : MonoBehaviour
    {
        private Transform _parentTransform;

        private Action _onRefresh;
        private Action _onPrev;
        private Action _onNext;
        private Action _onFeedback;

        private const float BUTTON_SPACING = 49f;
        private const float BUTTON_Y = -270f;
        private const float BUTTON_BASE_Y = 65f;
        private const float NAVIGATION_OFFSET_Y = -200f;
        private AnnouncementState _state;

        public void Initialize(Transform parent = null, Action onRefresh = null, Action onPrev = null,
                             Action onNext = null, Action onFeedback = null,
                             AnnouncementState state = null)
        {
            _parentTransform = parent ?? transform;
            _onRefresh = onRefresh;
            _onPrev = onPrev;
            _onNext = onNext;
            _onFeedback = onFeedback;
            _state = state;

            CreateNavigationButtons();
        }

        private void CreateNavigationButtons()
        {
            CreateButton("RefreshButton", new Vector2(-345, BUTTON_Y), new Vector2(40, 40),
                "refresh_button", new Color(0.2f, 0.6f, 0.9f, 1f), _onRefresh);

            CreateNavigationButton("PrevButton", new Vector2(78, BUTTON_Y), "prev_button", true, _onPrev);

            CreateNavigationButton("NextButton", new Vector2(123, BUTTON_Y), "next_button", false, _onNext);

            CreateButton("FeedbackButton", new Vector2(183, BUTTON_Y), new Vector2(70, 40),
                "feedback_button", new Color(0.43f, 0.77f, 0.29f, 1f), OnFeedbackButtonClicked);

            CreateSteamWorkshopButton();
        }

        private void OnFeedbackButtonClicked()
        {
            try
            {
                AudioUtility.PlayClickSound();

                if (_state == null)
                {
                    return;
                }

                var selectedConfig = _state.SelectedConfig;
                if (selectedConfig == null)
                {
                    return;
                }

                string feedbackUrl = selectedConfig.FeedbackUrl;
                if (string.IsNullOrEmpty(feedbackUrl))
                {
                    return;
                }

                Application.OpenURL(feedbackUrl);
            }
            catch (Exception e)
            {
                Debug.LogError($"打开反馈链接失败: {e}");
            }
        }

        private void CreateButton(string name, Vector2 position, Vector2 size,
                        string spriteName, Color fallbackColor, Action onClick,
                        bool isEnabled = true)
        {
            GameObject btn = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
            btn.transform.SetParent(_parentTransform, false);

            RectTransform rect = btn.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = size;

            Image image = btn.GetComponent<Image>();
            image.sprite = ResourceLoader.LoadSprite(spriteName);

            if (!isEnabled)
            {
                if (image.sprite == null)
                {
                    Color grayColor = fallbackColor;
                    float grayscale = (grayColor.r * 0.299f + grayColor.g * 0.587f + grayColor.b * 0.114f);
                    image.color = new Color(grayscale, grayscale, grayscale, grayColor.a * 0.7f);
                }
                else
                {
                    image.color = new Color(0.5f, 0.5f, 0.5f, 0.7f);
                }
            }
            else
            {
                image.color = Color.white;
                if (image.sprite == null) image.color = fallbackColor;
            }

            image.type = Image.Type.Sliced;

            Button button = btn.GetComponent<Button>();
            button.interactable = isEnabled;

            if (isEnabled && onClick != null)
            {
                button.onClick.AddListener(() =>
                {
                    AudioUtility.PlayClickSound();
                    StartCoroutine(PlayButtonClickAnimation(rect));
                    onClick?.Invoke();
                });
            }

            if (isEnabled)
            {
                var hoverEffect = btn.AddComponent<ButtonHoverEffect>();
                hoverEffect.ButtonImage = image;
                hoverEffect.ButtonComponent = button;
                hoverEffect.ConfigureForPopupButton();
            }

            btn.transform.SetAsLastSibling();
        }

        private void CreateNavigationButton(string name, Vector2 position, string spriteName,
                                          bool isLeft, Action onClick)
        {
            GameObject btn = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
            btn.transform.SetParent(_parentTransform, false);

            RectTransform rect = btn.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = new Vector2(40, 40);

            Image image = btn.GetComponent<Image>();
            image.sprite = ResourceLoader.LoadSprite(spriteName);
            if (image.sprite == null) image.color = new Color(0.13f, 0.63f, 0.76f, 1f);
            image.type = Image.Type.Sliced;

            Button button = btn.GetComponent<Button>();
            button.onClick.AddListener(() =>
            {
                AudioUtility.PlayClickSound();
                StartCoroutine(PlayButtonClickAnimation(rect));
                onClick?.Invoke();
            });

            CreateArrowIcon(btn.transform, isLeft);

            var hoverEffect = btn.AddComponent<ButtonHoverEffect>();
            hoverEffect.ButtonImage = image;
            hoverEffect.ButtonComponent = button;
            hoverEffect.ConfigureForPopupButton();

            btn.transform.SetAsLastSibling();
        }

        private void CreateArrowIcon(Transform parent, bool isLeft)
        {
            GameObject arrow = new GameObject("Arrow", typeof(RectTransform), typeof(Image));
            arrow.transform.SetParent(parent, false);

            RectTransform rect = arrow.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = Vector2.zero;
            rect.sizeDelta = new Vector2(18, 18);

            Image image = arrow.GetComponent<Image>();
            image.sprite = ResourceLoader.LoadSprite(isLeft ? "left_arrow" : "right_arrow");
            if (image.sprite == null) image.color = new Color(0.85f, 0.85f, 0.85f, 1f);

            if (!isLeft) rect.localRotation = Quaternion.Euler(0, 0, 180);
        }

        private void CreateSteamWorkshopButton()
        {
            GameObject btn = new GameObject("SteamWorkshopButton", typeof(RectTransform), typeof(Image), typeof(Button));
            btn.transform.SetParent(_parentTransform, false);

            RectTransform rect = btn.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = new Vector2(290, BUTTON_Y);
            rect.sizeDelta = new Vector2(135, 40);

            Image image = btn.GetComponent<Image>();
            image.sprite = ResourceLoader.LoadSprite("update_popup_steam_bg2");
            if (image.sprite == null) image.color = new Color(0.1f, 0.5f, 0.2f, 1f);
            image.type = Image.Type.Sliced;

            Button button = btn.GetComponent<Button>();
            button.onClick.AddListener(() =>
            {
                AudioUtility.PlayClickSound();
                StartCoroutine(PlayButtonClickAnimation(rect));
                OpenSteamWorkshop();
            });

            var hoverEffect = btn.AddComponent<ButtonHoverEffect>();
            hoverEffect.ButtonImage = image;
            hoverEffect.ButtonComponent = button;
            hoverEffect.ConfigureForPopupButton();

            btn.transform.SetAsLastSibling();
        }

        private void OpenSteamWorkshop()
        {
            try
            {
                if (_state == null)
                {
                    return;
                }

                var selectedConfig = _state.SelectedConfig;
                if (selectedConfig == null)
                {
                    return;
                }

                string steamUrl = selectedConfig.SteamWorkshopUrl;
                if (string.IsNullOrEmpty(steamUrl))
                {
                    return;
                }

                if (IsSteamRunning())
                {
                    SteamFriends.ActivateGameOverlayToWebPage(steamUrl);
                }
                else
                {
                    Application.OpenURL(steamUrl);
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"打开Steam创意工坊失败: {e}");
            }
        }

        private bool IsSteamRunning()
        {
            try
            {
                return SteamAPI.IsSteamRunning();
            }
            catch
            {
                return false;
            }
        }

        private IEnumerator PlayButtonClickAnimation(RectTransform buttonRect)
        {
            if (buttonRect == null) yield break;

            float elapsedTime = 0f;
            float duration = 0.2f;
            Vector3 originalScale = buttonRect.localScale;

            buttonRect.localScale = originalScale * 0.85f;

            while (elapsedTime < duration)
            {
                elapsedTime += Time.unscaledDeltaTime;
                float t = elapsedTime / duration;
                float scale = Mathf.Lerp(0.85f, 1.0f, ElasticEaseOut(t));
                buttonRect.localScale = originalScale * scale;
                yield return null;
            }

            buttonRect.localScale = originalScale;
        }

        private float ElasticEaseOut(float t)
        {
            if (t >= 1) return 1;
            float p = 0.3f;
            float s = p / 4f;
            return Mathf.Pow(2, -10 * t) * Mathf.Sin((t - s) * (2 * Mathf.PI) / p) + 1;
        }

        public void Cleanup()
        {
            foreach (Transform child in transform)
            {
                Destroy(child.gameObject);
            }
        }
    }
}